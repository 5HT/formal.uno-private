using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;
using System.Xml;
using System.Xml.Schema;
using ASAPTypes;

namespace ASAPClient
{
	/// <summary>
	/// Summary description for _default.
	/// </summary>
	public class _default : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.TextBox TextBox1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (IsPostBack)
			{
				Request r = new Request();
				r.ReceiverKey = TextBox1.Text;
				r.SenderKey = ConfigurationSettings.AppSettings["hostURL"] + "/ASAPClient/ObserverService.asmx";
				r.ResponseRequired = YesNoIfError.Yes;
				r.RequestID = "id";

				AsapFactoryBinding f = new AsapFactoryBinding();
				f.Url = TextBox1.Text;
				f.RequestValue = r;

				try
				{
					factoryPropertiesType fp = f.GetProperties(new GetPropertiesRq());
					Session["Factory"] = fp;
					Session["ContextSchema"] = CompileSchema(fp.ContextDataSchema, "ContextData");
					Session["ResultSchema"] = CompileSchema(fp.ResultDataSchema, "ResultData");
				}
				catch (Exception excpt)
				{
					Label1.Text = excpt.Message;
					Label1.Visible = true;
					return;
				}

				Server.Transfer("factory.aspx");
			}
			else
			{
				TextBox1.Text = ConfigurationSettings.AppSettings["hostURL"] + "/ASAPServer/FactoryService.asmx";
			}
		}

		private Object CompileSchema(schemaType st, string name)
		{
			XmlReader reader = new XmlNodeReader(st.Any);
			XmlSchema schema = XmlSchema.Read(reader, null);

			//XmlSchemaElement element = new XmlSchemaElement();
			//schema.Items.Add(element);
			//element.Name = name;
			//element.SchemaTypeName = new XmlQualifiedName(name, schema.TargetNamespace);
			
			schema.Compile(null);
			return schema;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
