package au.edu.qut.yawl.elements;

import au.edu.qut.yawl.elements.data.YParameter;
import au.edu.qut.yawl.util.YVerificationMessage;

import java.util.*;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 25/09/2003
 * Time: 15:45:13
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YAWLServiceGateway extends YDecomposition implements YVerifiable{
    private Map _yawlServices = new HashMap();

    public YAWLServiceGateway(String id, YSpecification specification){
        super(id, specification);
    }


    public List verify(){
        List messages = new Vector();
        messages.addAll(super.verify());
        Collection yawlServices = _yawlServices.values();
        for (Iterator iterator = yawlServices.iterator(); iterator.hasNext();) {
            YAWLServiceReference yawlService = (YAWLServiceReference) iterator.next();
            List verificationResult = yawlService.verify();
            for (int i = 0; i < verificationResult.size(); i++) {
                YVerificationMessage message = (YVerificationMessage) verificationResult.get(i);
                message.setSource(this);
            }
            messages.addAll(verificationResult);
        }
        return messages;
    }


    public String toXML(){
        StringBuffer xml = new StringBuffer();
        //just do the decomposition facts (not the surrounding element) - to keep life simple
        xml.append(super.toXML());

        Collection yawlServices = _yawlServices.values();
        for (Iterator iterator = yawlServices.iterator(); iterator.hasNext();) {
            YAWLServiceReference service = (YAWLServiceReference) iterator.next();
            xml.append(service.toXML());
        }
        return xml.toString();
    }


    public String applyOutputExpressions(String outputData) {

        return null;
    }


    public YAWLServiceReference getYawlService(String yawlServiceID){
        return (YAWLServiceReference) _yawlServices.get(yawlServiceID);
    }

    public YAWLServiceReference getYawlService(){
        if(_yawlServices.values().size() > 0){
            return (YAWLServiceReference) _yawlServices.values().iterator().next();
        }
        return null;
    }


    public void setYawlService(YAWLServiceReference yawlService){
        if(yawlService != null){
            _yawlServices.put(yawlService.getURI(), yawlService);
        }
    }
}
