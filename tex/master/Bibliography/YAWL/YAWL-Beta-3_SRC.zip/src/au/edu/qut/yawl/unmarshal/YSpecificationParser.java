package au.edu.qut.yawl.unmarshal;

import au.edu.qut.yawl.elements.YDecomposition;
import au.edu.qut.yawl.elements.YTask;
import au.edu.qut.yawl.elements.YNet;
import au.edu.qut.yawl.elements.YSpecification;
import au.edu.qut.yawl.exceptions.YSchemaBuildingException;
import au.edu.qut.yawl.exceptions.YSyntaxException;
import au.edu.qut.yawl.schema.XMLToolsForYAWL;
import org.jdom.Attribute;
import org.jdom.Element;
import org.jdom.Namespace;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


/**
 * Parses, or builds, specification objects from XML doclets.
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.

 */
class YSpecificationParser {
    private YSpecification _specification;
    private YDecompositionParser[] _decompositionParser;
    private Map _decompAndTypeMap = new HashMap();
    private Namespace _yawlNS;
    private String _version;


    /**
     * build a specification object from part of an XML document
     * @param specificationElem the specification part of an XMl document
     * @param version the version of the XML representation (i.e. beta2 or beta3).
     * @throws YSyntaxException
     * @throws YSchemaBuildingException
     */
    public YSpecificationParser(Element specificationElem, String version) throws YSyntaxException, YSchemaBuildingException {
        _version = version;
        _yawlNS = specificationElem.getNamespace();

        parseSpecification(specificationElem);
        linkDecompositions();
    }


    private void parseSpecification(Element specificationElem) throws YSyntaxException, YSchemaBuildingException {
        List decompositionElems = specificationElem.getChildren("decomposition", _yawlNS);
        for (int i = 0; i < decompositionElems.size(); i++) {
            Element decompositionElem = (Element) decompositionElems.get(i);
            Namespace xsiNameSpc = decompositionElem.getNamespace("xsi");
            String decompID = decompositionElem.getAttributeValue("id");//, _yawlNS);
            Attribute type = decompositionElem.getAttribute("type", xsiNameSpc);
            if(type != null){
                //todo  fix it so when you load a spec with an empty decompostion JDOM doesn't
                //todo  throw a null pointer exception.
                String decompType = type.getValue();
                _decompAndTypeMap.put(decompID, decompType);
            }
        }
        String uriString = specificationElem.getAttributeValue("uri");
        _specification = new YSpecification(uriString);
        String name = specificationElem.getChildText("name", _yawlNS);
        String documentation = specificationElem.getChildText("documentation", _yawlNS);

        Namespace schema4SchemaNS = Namespace.getNamespace(XMLToolsForYAWL.getSchema4SchemaNameSpace());
        Element schemElem = specificationElem.getChild("schema", schema4SchemaNS);
        if(null != schemElem){
            XMLOutputter outputter = new XMLOutputter(Format.getCompactFormat());
            _specification.setSchema(outputter.outputString(schemElem));
        }
        _specification.setName(name);
        _specification.setDocumentation(documentation);

        //If is version beta2 we loop through the decompositions
        //in a slightly different way.  Rather than be tricky i think it is easier to just copy the
        //code with minor changes.
        if(isBeta2Version()){
            _decompositionParser = new YDecompositionParser[decompositionElems.size() + 1];
            Element rootNetElem = specificationElem.getChild("rootNet", _yawlNS);
            _decompositionParser[0] = new YDecompositionParser(rootNetElem, this, _version);
            YNet rootNet = (YNet) _decompositionParser[0].getDecomposition();
            _specification.setRootNet(rootNet);

            for (int i = 1; i <= decompositionElems.size(); i++) {
                Element decompositionElem = (Element) decompositionElems.get(i -1);
                _decompositionParser[i] = new YDecompositionParser(decompositionElem, this, _version);
                YDecomposition decomposition = _decompositionParser[i].getDecomposition();
                _specification.setDecomposition(decomposition);
            }
        } else //must be beta3 or greater
        {
            _decompositionParser = new YDecompositionParser[decompositionElems.size()];
            for (int i = 0; i < decompositionElems.size(); i++) {
                Element decompositionElem = (Element) decompositionElems.get(i);
                _decompositionParser[i] = new YDecompositionParser(decompositionElem, this, _version);
                YDecomposition decomposition = _decompositionParser[i].getDecomposition();
                _specification.setDecomposition(decomposition);
            }
        }
        addSchema(specificationElem);
    }


    /**
     * @return whether this is a a beta 2 specification version or not.
     */
    private boolean isBeta2Version() {
        return "beta2".equals(_version);
    }



    /**
     * adds the XML schema library to the specification.
     * @param specificationElem
     */
    private void addSchema(Element specificationElem) throws YSyntaxException {

        Element schemaElem = specificationElem.getChild("schema");
        if(schemaElem != null){
            XMLOutputter xmlo = new XMLOutputter(Format.getCompactFormat());
            String schemaStr = xmlo.outputString(schemaElem);
            try {
                _specification.setSchema(schemaStr);
            } catch (YSchemaBuildingException e) {
                YSyntaxException f = new YSyntaxException(e.getMessage());
                f.setStackTrace(e.getStackTrace());
                throw f;
            }
        }
    }


    private void linkDecompositions() {
        for (int i = 0; i < _decompositionParser.length; i++) {
            Map decomposesToIDs = _decompositionParser[i].getDecomposesToIDs();
            Iterator compTasksIter = decomposesToIDs.keySet().iterator();
            while (compTasksIter.hasNext()) {
                YTask task = (YTask) compTasksIter.next();
                String decompID = (String) decomposesToIDs.get(task);
                YDecomposition implementation = _specification.getDecomposition(decompID);
                task.setDecompositionPrototype(implementation);
            }
        }
    }


    /**
     * Method getSpecification.
     * @return YSpecification
     */
    public YSpecification getSpecification() {
        return _specification;
    }

    public String getDecompositionType(String decomposesToID) {
        String decoType = null;
        decoType =  (String) _decompAndTypeMap.get(decomposesToID);
        return decoType;
    }


}

/*
    / **
     * @deprecated
     * @return
     * /
    private YNet getRootNet()
    {
        List allContainers = new Vector();
        List implementationContainers = new Vector();
        for(int i = 0; i < _decompositionParser.length; i++)
        {
            YNet container = _decompositionParser[i].getNet();
            allContainers.add(container);
            Map decomposesToIDs = _decompositionParser[i].getDecomposesToIDs();
            Iterator compTasksIter = decomposesToIDs.keySet().iterator();
            while(compTasksIter.hasNext())
            {
                YCompositeTask compTask = (YCompositeTask) compTasksIter.next();
                YNet implementation = (YNet) _decompositionMap.get(decomposesToIDs.get(compTask));
                implementationContainers.add(implementation);
            }
        }
        allContainers.removeAll(implementationContainers);
        return (YNet) allContainers.get(0);
    }*/
