package au.edu.qut.yawl.swingWorklist;

import au.edu.qut.yawl.elements.data.YParameter;
import au.edu.qut.yawl.engine.gui.YEngineGUI;
import au.edu.qut.yawl.worklist.model.Marshaller;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 15/05/2003
 * Time: 15:00:22
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YWorklistGUI extends JFrame implements ActionListener, ListSelectionListener {
    private YWorklistModel _worklistModel;
    private JTable _availableTable;
    private JTable _activeTable;
    private JButton _applyButton;
    private String _applyCommand = "Apply for Task";
    private JButton _completeButton;
    private String _completionCommand = "Register Completion";
    private JButton _newInstanceButton;
    private String _newInstanceCommand = "Create new Instance";
    private JButton _cancelTaskButton;
    private String _suspendTaskCommand = "Suspend Task";
    private JButton _viewDataButton;
    private String _viewDataCommand = "View/edit data";
    private JButton _updateListsButton;
    private String _updateListsCommand = " Update Lists ";
    private int _rowSelected = -1;
    private String _userName;
    private String _newInstanceData;


    public YWorklistGUI(String userName, YWorklistModel worklistModel) {
        super(userName + "'s Worklist");
        _worklistModel = worklistModel;
        _userName = userName;
        Container c = this.getContentPane();
        c.setBackground(YEngineGUI._apiColour);
        JPanel worklistsPanel = new JPanel(new GridLayout(2, 1));
        c.setLayout(new BorderLayout());
        _applyButton = new JButton(_applyCommand);
        _applyButton.setBackground(new Color(204, 255, 0));
        _applyButton.setPreferredSize(new Dimension(160, 30));
        _applyButton.addActionListener(this);
        _completeButton = new JButton(_completionCommand);
        _completeButton.setBackground(new Color(255, 100, 100));
        _completeButton.addActionListener(this);
        _newInstanceButton = new JButton(_newInstanceCommand);
        _newInstanceButton.addActionListener(this);
        _cancelTaskButton = new JButton(_suspendTaskCommand);
        _cancelTaskButton.addActionListener(this);
        _viewDataButton = new JButton(_viewDataCommand);
        _viewDataButton.setBackground(new Color(150, 150, 255));
        _viewDataButton.addActionListener(this);
        //do available work panel
        YWorkListPanel availablePanel =
                new YWorkListPanel(
                        _worklistModel.getAvaliableModel(),
                        "Scheduled Tasks",
                        new Dimension(300, 75),
                        _applyButton,
                        null,
                        null,
                        null);
        _availableTable = availablePanel.getMyTable();
        worklistsPanel.add(availablePanel);
        //do active tasks panel
        YWorkListPanel activePanel =
                new YWorkListPanel(
                        _worklistModel.getActiveTasksModel(),
                        _userName + "'s Active Tasks",
                        new Dimension(300, 75),
                        _completeButton,
                        _cancelTaskButton,
                        _newInstanceButton,
                        _viewDataButton);
        _activeTable = activePanel.getMyTable();
        worklistsPanel.add(activePanel);
        //do bottom panel
        JPanel bottomPanel = new JPanel(new BorderLayout());
        _updateListsButton = new JButton(_updateListsCommand);
        bottomPanel.add(_updateListsButton, BorderLayout.EAST);
        bottomPanel.setBackground(YEngineGUI._apiColour);
        bottomPanel.setBorder(
                BorderFactory.createEmptyBorder(10, 10, 10, 18));
        _updateListsButton.addActionListener(this);
        c.add(worklistsPanel, BorderLayout.CENTER);
        c.add(bottomPanel, BorderLayout.SOUTH);
        //do typical JFrame setup
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
            }
        });
        final TopPopupMenu topPopup = new TopPopupMenu(this);
        _availableTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int rowSelected = _availableTable.rowAtPoint(e.getPoint());
                    applyForWorkItem(rowSelected);
                    _worklistModel.refreshLists(_userName);
                }
                //right click
                else {
                    maybeShowPopup(e);
                }
            }

            public void mouseReleased(MouseEvent e) {
                maybeShowPopup(e);
            }

            private void maybeShowPopup(MouseEvent e) {
                if (e.isPopupTrigger() && e.getButton() != MouseEvent.BUTTON1) {
                    _rowSelected = _availableTable.rowAtPoint(e.getPoint());
                    topPopup.show(e.getComponent(), e.getX(), e.getY());
                }
            }
        });
        final WorkListPopupMenu popupMenu = new WorkListPopupMenu(this);
        //       getContentPane().add(_popupMenu);
        _activeTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int rowSelected = _activeTable.rowAtPoint(e.getPoint());
                    createApplicationXPage(rowSelected);
                }
                //right click
                else
                    maybeShowPopup(e);
            }

            public void mouseReleased(MouseEvent e) {
                maybeShowPopup(e);
            }

            private void maybeShowPopup(MouseEvent e) {
                if (e.isPopupTrigger() && e.getButton() != MouseEvent.BUTTON1) {
                    _rowSelected = _activeTable.rowAtPoint(e.getPoint());
                    popupMenu.setVisibityOfMenuItems(_rowSelected);
                    popupMenu.show(e.getComponent(), e.getX(), e.getY());
                }
            }
        });
        ListSelectionModel rowSM = _activeTable.getSelectionModel();
        rowSM.addListSelectionListener(this);

        URL iconURL = YEngineGUI.class.getResource("YAWLIcon.jpg");
        setIconImage(Toolkit.getDefaultToolkit().createImage(iconURL));
        setSize(720, 600);
        setLocation(150, 50);
        show();
        repaint();
        _worklistModel.refreshLists(_userName);
    }

    private void createApplicationXPage(int rowSelected) {
        Object[] data = _worklistModel.getActiveTableData(
                (String) _activeTable.getValueAt(rowSelected, 0),
                (String) _activeTable.getValueAt(rowSelected, 1));
        new YApplicationXForm(YWorklistGUI.this, data, _worklistModel);
    }


    /**
     * Invoked when an action occurs.
     */
    public void actionPerformed(final ActionEvent e) {
        String command = e.getActionCommand();
        int rowSel = _availableTable.getSelectedRow();
        if (command == _applyCommand) {
            if (rowSel == -1) {
                rowSel = _rowSelected;
            }
            applyForWorkItem(rowSel);
            _worklistModel.refreshLists(_userName);
        } else {
            rowSel = _activeTable.getSelectedRow();
            if (rowSel == -1) {
                rowSel = _rowSelected;
            }
            if (command == _completionCommand) {
                if (rowSel >= 0) {
                    String caseID = (String) _activeTable.getValueAt(rowSel, 0);
                    String taskID = (String) _activeTable.getValueAt(rowSel, 1);
                    completeWorkItem(caseID, taskID);
                    _worklistModel.refreshLists(_userName);
                }
            } else if (command == _newInstanceCommand) {
                if (rowSel >= 0) {
                    String caseID = (String) _activeTable.getValueAt(rowSel, 0);
                    String taskID = (String) _activeTable.getValueAt(rowSel, 1);
                    //two messages sent upwards, one must complete before the next starts
                    YParameter param = _worklistModel.getMIUniqueParam(taskID);
                    String miUniqueParamStr = Marshaller.presentParam(param);
                    new MIUniqueInputDialog(this, miUniqueParamStr);
                    _worklistModel.createNewInstance(caseID, taskID, _newInstanceData);
                    //this will be a synchronous call to a WebSevice on the Engine
                    _newInstanceButton.setEnabled(
                            _worklistModel.allowsDynamicInstanceCreation(caseID, taskID));
                    _worklistModel.refreshLists(_userName);
                }
            } else if (command == _suspendTaskCommand) {
                if (rowSel >= 0) {
                    String caseID = (String) _activeTable.getValueAt(rowSel, 0);
                    String taskID = (String) _activeTable.getValueAt(rowSel, 1);
                    _worklistModel.rollBackActiveTask(caseID, taskID);
                    _worklistModel.refreshLists(_userName);
                }
            } else if (command == _viewDataCommand) {
                if (rowSel >= 0) {
                    createApplicationXPage(rowSel);
                }
            } else if(command == _updateListsCommand){
                _worklistModel.refreshLists(_userName);
            }
        }
        _rowSelected = -1;
    }


    protected void completeWorkItem(String caseID, String taskID) {
        _worklistModel.attemptToFinishActiveJob(caseID, taskID);
        _newInstanceButton.setEnabled(false);
        _worklistModel.refreshLists(_userName);
    }

    private void applyForWorkItem(int rowSel) {
        if (rowSel >= 0) {
            String caseID = (String) _availableTable.getValueAt(rowSel, 0);
            String taskID = (String) _availableTable.getValueAt(rowSel, 1);
            _worklistModel.applyForWorkItem(caseID, taskID);
        }
    }


    /**
     * Called whenever the value of the selection changes.
     * @param e the event that characterizes the change.
     */
    public void valueChanged(ListSelectionEvent e) {
        //Ignore extra messages.
        if (e.getValueIsAdjusting()) return;
        ListSelectionModel lsm =
                (ListSelectionModel) e.getSource();
        if (lsm.isSelectionEmpty()) {
            //no rows are selected
        } else {
            int selectedRow = lsm.getMinSelectionIndex();
            //selectedRow is selected
            String caseID = (String) _activeTable.getValueAt(selectedRow, 0);
            String taskID = (String) _activeTable.getValueAt(selectedRow, 1);
            if (_worklistModel.allowsDynamicInstanceCreation(caseID, taskID)) {
                _newInstanceButton.setEnabled(true);
            } else {
                _newInstanceButton.setEnabled(false);
            }
        }
    }


    class WorkListPopupMenu extends JPopupMenu {
        JMenuItem _completionItem = new JMenuItem(_completionCommand);
        JMenuItem _viewDataItem = new JMenuItem(_viewDataCommand);
        JMenuItem _newInstanceItem = new JMenuItem(_newInstanceCommand);
        JMenuItem _cancelItem = new JMenuItem(_suspendTaskCommand);


        public WorkListPopupMenu(YWorklistGUI ref) {
            super("File");
            add(_completionItem);
            _completionItem.addActionListener(ref);
            add(_viewDataItem);
            _viewDataItem.addActionListener(ref);
            add(_newInstanceItem);
            _newInstanceItem.addActionListener(ref);
            add(_cancelItem);
            _cancelItem.addActionListener(ref);
        }

        public void setVisibityOfMenuItems(int rowSelected) {
        }
    }

    class TopPopupMenu extends JPopupMenu{
        JMenuItem _applyItem = new JMenuItem(_applyCommand);
        YWorklistGUI _ref;

        public TopPopupMenu(YWorklistGUI ref){
            add(_applyItem);
            _applyItem.addActionListener(ref);
        }
    }

    class MIUniqueInputDialog extends JDialog implements ActionListener{
        private YWorklistGUI _owner;
        final JTextPane dataPane;

        public MIUniqueInputDialog(YWorklistGUI owner, String miUniqueParamStr){
            super(owner, "Require Extra Information About new Instance", true);
            Container c = getContentPane();
            c.setLayout(new BorderLayout());
            _owner = owner;
            dataPane  = new JTextPane();
            dataPane.setText(miUniqueParamStr);
            c.add(new JScrollPane(dataPane), BorderLayout.CENTER);
            addWindowListener(new WindowAdapter(){
                public void windowClosing(WindowEvent e){
                    _owner.setNewInstanceData(dataPane.getText());
                    dispose();
                }
            });
            JButton addInstanceButton = new JButton("Add This instance");
            addInstanceButton.addActionListener(this);
            c.add(addInstanceButton, BorderLayout.SOUTH);
            setSize(700, 500);
            setLocation(150, 50);
            show();
        }

        /**
         * Invoked when an action occurs.
         */
        public void actionPerformed(ActionEvent e) {
            _owner.setNewInstanceData(dataPane.getText());
            dispose();
        }


    }


    private void setNewInstanceData(String newInstanceData) {
        _newInstanceData = newInstanceData;
    }


    public static void main(String[] args) {
        new YWorklistModel("fred");
    }
}


