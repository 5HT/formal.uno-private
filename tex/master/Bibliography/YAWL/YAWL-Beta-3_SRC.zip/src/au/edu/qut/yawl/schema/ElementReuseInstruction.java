package au.edu.qut.yawl.schema;

/**
 /**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 13/09/2004
 * Time: 12:40:16
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class ElementReuseInstruction extends Instruction{
    /**
     * An instruction for creating a schema element.
     * @param elementName the name of the element to create.
     */
    public ElementReuseInstruction(String elementName) {
        if(null == elementName){
            throw new IllegalArgumentException("you need to specify an element name.");
        }
        _elementName = elementName;
    }
}
