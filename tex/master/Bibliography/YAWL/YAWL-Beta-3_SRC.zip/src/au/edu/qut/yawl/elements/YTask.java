package au.edu.qut.yawl.elements;

import au.edu.qut.yawl.elements.data.YParameter;
import au.edu.qut.yawl.elements.state.YIdentifier;
import au.edu.qut.yawl.elements.state.YInternalCondition;
import au.edu.qut.yawl.engine.YWorkItemRepository;
import au.edu.qut.yawl.exceptions.YDataStateException;
import au.edu.qut.yawl.exceptions.YStateException;
import au.edu.qut.yawl.util.YSaxonOutPutter;
import au.edu.qut.yawl.util.YVerificationMessage;
import net.sf.saxon.Configuration;
import net.sf.saxon.om.DocumentInfo;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.query.DynamicQueryContext;
import net.sf.saxon.query.QueryProcessor;
import net.sf.saxon.query.StaticQueryContext;
import net.sf.saxon.query.XQueryExpression;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
import org.jdom.xpath.XPath;

import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.io.StringReader;
import java.util.*;


/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * A superclass of any type of task in the YAWL paper.
 * @author Lachlan Aldred
 * This file remains the property of the YAWL team at the Queensland University of
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public abstract class YTask extends YExternalNetElement {
    private final static boolean _generateReports = false;
    //class members
    private static Random _random = new Random(new Date().getTime());
    public static final int _AND = 95;
    public static final int _OR = 103;
    public static final int _XOR = 126;

    //internal state nodes
    protected YIdentifier _i;
    protected YInternalCondition _mi_active = new YInternalCondition(YInternalCondition._mi_active, this);
    protected YInternalCondition _mi_entered = new YInternalCondition(YInternalCondition._mi_entered, this);
    protected YInternalCondition _mi_complete = new YInternalCondition(YInternalCondition._mi_complete, this);
    protected YInternalCondition _mi_executing = new YInternalCondition(YInternalCondition._executing, this);
    protected static YWorkItemRepository _workItemRepository = YWorkItemRepository.getInstance();

    //private attributes
    private int _splitType;
    private int _joinType;
    protected YMultiInstanceAttributes _multiInstAttr;
    private Set _removeSet = new HashSet();
    private Map _dataMappingsForTaskStarting = new HashMap();//[key=varName, value=query]
    private Map _dataMappingsForTaskCompletion = new HashMap();//[key=query, value=varName]
    protected YDecomposition _decompositionPrototype;
    //input data storage
    private Map _caseToDataMap = new HashMap();
    private Iterator _multiInstanceSpecificParamsIterator;
    private Map _localVariableNameToReplaceableOuptutData;
    private Document _groupedOutputData;


    /**
     * Constructor
     * @param id
     * @param splitType
     * @param joinType
     * @param container
     */
    public YTask(String id, int joinType, int splitType, YNet container) {
        super(id, container);
        _splitType = splitType;
        _joinType = joinType;
    }


    public int getSplitType() {
        return _splitType;
    }


    public int getJoinType() {
        return _joinType;
    }


    public void setSplitType(int splitType) {
        _splitType = splitType;
    }


    public void setJoinType(int joinType) {
        _joinType = joinType;
    }


    public boolean isMultiInstance() {
        return _multiInstAttr != null && _multiInstAttr.isMultiInstance();
    }


    public String getPredicate(YExternalNetElement netElement) {
        YFlow flow = getPostsetFlow(netElement);
        return flow.getXpathPredicate();
    }



/*    public Map getPredicates() {
        return _predicateMap != null ? new HashMap(_predicateMap) : null;
    }
*/


    public YMultiInstanceAttributes getMultiInstanceAttributes() {
        return _multiInstAttr;
    }


    public void setUpMultipleInstanceAttributes(String minInstanceQuery, String maxInstanceQuery,
                                                String thresholdQuery, String creationMode) {
        _multiInstAttr = new YMultiInstanceAttributes
                (this, minInstanceQuery, maxInstanceQuery, thresholdQuery, creationMode);
    }


    public void setMultiInstanceInputDataMappings(String remoteVariableName, String inputProcessingExpression) {
        _multiInstAttr.setMIFormalInputParam(remoteVariableName);
        _multiInstAttr.setUniqueInputMISplittingQuery(inputProcessingExpression);
    }


    public void setMultiInstanceOutputDataMappings(String remoteOutputExpression,
                                                   String outputProcessingExpression) {
        _multiInstAttr.setMIFormalOutputQuery(remoteOutputExpression);
        _multiInstAttr.setUniqueOutputMIJoiningQuery(outputProcessingExpression);
    }


    public List verify() {
        List messages = new Vector();
        messages.addAll(super.verify());
        if (_splitType != _AND
                && _splitType != _OR
                && _splitType != _XOR) {
            messages.add(new YVerificationMessage(this, this + " Incorrect value for split type",
                    YVerificationMessage._errorStatus));
        }
        if (_joinType != _AND
                && _joinType != _OR
                && _joinType != _XOR) {
            messages.add(new YVerificationMessage(this, this + " Incorrect value for join type",
                    YVerificationMessage._errorStatus));
        }
        if (_splitType != _AND &&
                (_splitType == _OR || _splitType == _XOR)) {
            int defaultCount = 0;
            List postsetFlows = new ArrayList(getPostsetFlows());
            Collections.sort(postsetFlows);
            long lastOrdering = Long.MIN_VALUE;
            for (Iterator iterator = postsetFlows.iterator(); iterator.hasNext();) {
                YFlow flow = (YFlow) iterator.next();
                if (flow.getEvalOrdering() != null) {
                    int thisOrdering = flow.getEvalOrdering().intValue();
                    if (thisOrdering == lastOrdering) {
                        messages.add(new YVerificationMessage(this,
                                this + " no two elements may posess the same ordering (" + flow +
                                ") for the same task.",
                                YVerificationMessage._errorStatus));
                    }
                    lastOrdering = thisOrdering;
                }
                if (flow.isDefaultFlow()) {
                    defaultCount++;
                }
            }
            if (defaultCount != 1) {
                messages.add(new YVerificationMessage(this, this + " the postset of any OR/XOR " +
                        "split must have one default flow. (not " + defaultCount + ")",
                        YVerificationMessage._errorStatus));
            }
        }
        if (_multiInstAttr != null) {
            messages.addAll(_multiInstAttr.verify());
        }
        Iterator removeSetIt = _removeSet.iterator();
        while (removeSetIt.hasNext()) {
            YExternalNetElement element = (YExternalNetElement) removeSetIt.next();
            if (element == null) {
                messages.add(new YVerificationMessage(this,
                        this + " refers to a non existant element in its remove set.",
                        YVerificationMessage._errorStatus));
            } else if (!element._net.equals(_net)) {
                messages.add(new YVerificationMessage(this,
                        this + " and " + element + " must be contained in the same net."
                        + " (container " + _net + " & " + element._net + ")",
                        YVerificationMessage._errorStatus));
            }
        }
        if (_decompositionPrototype != null) {
            //check that there is a link to each inputParam
            Set inputParamNamesAtDecomposition = _decompositionPrototype.getInputParameterNames();
            Set inputParamNamesAtTask = getParamNamesForTaskStarting();
            //catch the case where serveral expressions map to the same decomposition input param
            //The only case where the schema misses this is where the muilti-instance input
            //is the same as one the regular variable mappings

            int numOfUniqueParamsMappedTo = new HashSet(
                    _dataMappingsForTaskStarting.values()).size();
            int numParams  = _dataMappingsForTaskStarting.size();
            if(numOfUniqueParamsMappedTo != numParams){
                messages.add(new YVerificationMessage(this, this + " the multi instance " +
                        "data extraction process applies the result to a decomposition input" +
                        " already used for a regular variable," +
                        " this is not allowed in YAWL.", YVerificationMessage._errorStatus));
            }
            //check that the MI data output extract process does not map to a net variable that is
            //already mapped to by the said task.
            //The only case where the schema misses this is where the muilti-instance output
            //is applied to the same net variable as one of regular outputs.
            int numOfUniqueNetVarsMappedTo = new HashSet(_dataMappingsForTaskCompletion.values()).size();
            numParams = _dataMappingsForTaskCompletion.size();
            if(numOfUniqueNetVarsMappedTo != numParams){
                messages.add(new YVerificationMessage(this, this + " the multi instance " +
                        "data output process applies the result to the same net variable as one " +
                        "of the regular net variables.", YVerificationMessage._errorStatus));
            }
            //check that task input var maps to decomp input var
            for (Iterator iterator = inputParamNamesAtDecomposition.iterator(); iterator.hasNext();) {
                String paramName = (String) iterator.next();
                if (!inputParamNamesAtTask.contains(paramName)) {
                    messages.add(new YVerificationMessage(this, this +
                            "(id= " + this.getID() + ") there exists an input" +
                            " parameter(" + paramName + ") in " + _decompositionPrototype + " that is" +
                            " not mapped to by this Task.", YVerificationMessage._errorStatus));
                }
            }
            for (Iterator iterator = inputParamNamesAtTask.iterator(); iterator.hasNext();) {
                String paramName = (String) iterator.next();
                if (!inputParamNamesAtDecomposition.contains(paramName)) {
                    messages.add(new YVerificationMessage(this, this +
                            "(id= " + this.getID() + ") there exists an input" +
                            " parameter(" + paramName + ") in this Task that has no corresponding mapping" +
                            " at its decomposition(" + _decompositionPrototype + ").",
                            YVerificationMessage._errorStatus));
                }
            }
            //check there is link to each to each output param(query).
            Set outputQueriesAtDecomposition = _decompositionPrototype.getOutputQueries();
            Set outputQueriesAtTask = getQueriesForTaskCompletion();
            Set outPutVarsAssignedTo = getLocalVariablesForTaskCompletion();
            for (Iterator iterator = outputQueriesAtDecomposition.iterator(); iterator.hasNext();) {
                String query = (String) iterator.next();
                if (!outputQueriesAtTask.contains(query)) {
                    messages.add(new YVerificationMessage(this, this + " there exists an output" +
                            " query(" + query + ") in " + _decompositionPrototype + " that is" +
                            " not mapped to by this Task.", YVerificationMessage._errorStatus));
                }
            }
            for (Iterator iterator = outputQueriesAtTask.iterator(); iterator.hasNext();) {
                String query = (String) iterator.next();
                if (!outputQueriesAtDecomposition.contains(query)) {
                    messages.add(new YVerificationMessage(this, this + " there exists an output" +
                            " query(" + query + ") in this Task that has no corresponding mapping" +
                            " at its decomposition(" + _decompositionPrototype + ").",
                            YVerificationMessage._errorStatus));
                }
            }
            for (Iterator iterator = outPutVarsAssignedTo.iterator(); iterator.hasNext();) {
                String localVarName = (String) iterator.next();
                if (_net.getLocalVariables().get(localVarName) == null &&
                        _net.getInputParameters().get(localVarName) == null) {
                    messages.add(new YVerificationMessage(this, this +
                            " (id= " + getID() + ") assigns the value(" +
                            localVarName + ") to a non existant net" +
                            " variable.", YVerificationMessage._errorStatus));
                }
            }
        } else {
            if (_dataMappingsForTaskStarting.size() > 0) {
                messages.add(new YVerificationMessage(
                        this, "Syntax error for " + this + " to have startingMappings and no decomposition.",
                        YVerificationMessage._errorStatus));
            }
            if (_dataMappingsForTaskCompletion.size() > 0) {
                messages.add(new YVerificationMessage(
                        this, "Syntax error for " + this + " to have completionMappings and no decomposition.",
                        YVerificationMessage._errorStatus));
            }
        }
        //todo check queries for syntax
        return messages;
    }

    private Set getQueriesForTaskCompletion() {
        return _dataMappingsForTaskCompletion.keySet();
    }


    private Set getParamNamesForTaskStarting() {
        return new HashSet(_dataMappingsForTaskStarting.keySet());
    }


    public Set getRemoveSet() {
        if (_removeSet != null) {
            return new HashSet(_removeSet);
        }
        return null;
    }


    public void setRemovesTokensFrom(List removeSet) {
        _removeSet.addAll(removeSet);
    }


    public synchronized List t_fire() throws YStateException, YDataStateException {
        YIdentifier id = getI();
        if (!t_enabled(id)) {
            throw new YStateException(
                    this + " cannot fire due to not being enabled");
        }
        _i = id;
        _i.addLocation(this);
        List conditions = new Vector(getPresetElements());
        Iterator conditionsIt = getPresetElements().iterator();
        long numToSpawn = determineHowManyInstancesToCreate();

        switch (_joinType) {
            case YTask._AND:
                while (conditionsIt.hasNext()) {
                    ((YConditionInterface) conditionsIt.next()).removeOne();
                }
                break;
            case YTask._OR:
                while (conditionsIt.hasNext()) {
                    YConditionInterface condition = (YConditionInterface) conditionsIt.next();
                    if (condition.containsIdentifier()) {
                        condition.removeOne();
                    }
                }
                break;
            case YTask._XOR:
                boolean done = false;
                do {
                    int i = Math.abs(_random.nextInt()) % conditions.size();
                    YConditionInterface condition = (YConditionInterface) conditions.get(i);
                    if (condition.containsIdentifier()) {
                        condition.removeOne();
                        done = true;
                    }
                } while (!done);
                break;
        }
        List childIdentifiers = new Vector();
        for (int i = 0; i < numToSpawn; i++) {
            YIdentifier childID = createFiredIdentifier();
            prepareDataForInstanceStarting(childID);
            childIdentifiers.add(childID);
        }
        prepareDataDocsForTaskOutput();
        return childIdentifiers;
    }


    private void prepareDataDocsForTaskOutput() {
        _groupedOutputData = new Document();
        _groupedOutputData.setRootElement(new Element("data"));
        _localVariableNameToReplaceableOuptutData = new HashMap();
    }


    public synchronized YIdentifier t_add(YIdentifier siblingWithPermission, Element newInstanceData) throws YDataStateException {
        if (!YMultiInstanceAttributes._creationModeDynamic.equals(_multiInstAttr.getCreationMode())) {
            throw new RuntimeException(this + " does not allow dynamic instance creation.");
        }
        if (t_addEnabled(siblingWithPermission)) {
            List newData = new Vector();
            newData.add(newInstanceData);
            _multiInstanceSpecificParamsIterator = newData.iterator();
            YIdentifier newInstance = createFiredIdentifier();
            this.prepareDataForInstanceStarting(newInstance);
            return newInstance;
        }
        return null;
    }


    public boolean t_addEnabled(YIdentifier identifier) {
        if (!isMultiInstance()) {
            return false;
        } else {
            return t_isBusy()
                    && YMultiInstanceAttributes._creationModeDynamic.equals(_multiInstAttr.getCreationMode())
                    && _mi_executing.contains(identifier)
                    && _mi_active.getIdentifiers().size() < _multiInstAttr.getMaxInstances();
        }
    }


    private long determineHowManyInstancesToCreate() throws YDataStateException {
        if (!isMultiInstance()) {
            return 1;
        }
        int max = _multiInstAttr.getMaxInstances();
        int min = _multiInstAttr.getMinInstances();
        String queryString = getPreSplittingMIQuery();
        Element dataToSplit = evaluateTreeQuery(queryString, _net.getInternalDataDocument());
        if (dataToSplit == null) {
            throw new YDataStateException("The MI data accessing query (" + queryString + ") for this task ("
                    + this + ") failed to extract data to split up.");
        }
        if (_generateReports) {
            System.out.println("YTask::fire() queryString " + queryString);
            System.out.println("YTask::fire() splitting up instances for " + getID());
            String inputDataDocStr = new org.jdom.output.XMLOutputter(Format.getPrettyFormat()).
                    outputString(_net.getInternalDataDocument()).trim();
            System.out.println("YTask::fire() dataToSplit " +
                    new org.jdom.output.XMLOutputter(Format.getPrettyFormat()).
                    outputString(dataToSplit).trim());
            System.out.println("YTask::fire() net data = " + inputDataDocStr);
            System.out.println("YTask::" + getID() + ".fire() the splitting query = "
                    + _multiInstAttr.getMISplittingQuery());
            System.out.println("YTask::determineHowManyInstancesToCreate() dataToSplit = "
                    + new XMLOutputter(Format.getPrettyFormat())
            .outputString(dataToSplit).trim());

        }
        List multiInstanceList = evaluateListQuery(_multiInstAttr.getMISplittingQuery(), dataToSplit);
        int listSize = multiInstanceList.size();
        if (listSize > max || listSize < min) {
            throw new YDataStateException("The size of the list (" + listSize + ") produced by the " +
                    "splitting expression for " + this + " lies outside the bounds of the " +
                    "specified min(" + min + ") or max(" + max + ") instances to create.");
        }
        _multiInstanceSpecificParamsIterator = multiInstanceList.iterator();
        return listSize;
    }


    protected String getPreSplittingMIQuery() {
        String miVarNameInDecomposition = _multiInstAttr.getMIFormalInputParam();
        for (Iterator iterator = _dataMappingsForTaskStarting.keySet().iterator();
             iterator.hasNext();) {
            String name = (String) iterator.next();
            if (miVarNameInDecomposition.equals(name)) {
                return (String) _dataMappingsForTaskStarting.get(name);
            }
        }
        return null;
    }


    public synchronized boolean t_isExitEnabled() {
        return
            t_isBusy() &&
            ((
            _mi_active.getIdentifiers().containsAll(_mi_complete.getIdentifiers())
            && _mi_complete.getIdentifiers().containsAll(_mi_active.getIdentifiers())
            ) || (
            _mi_complete.getIdentifiers().size() >= _multiInstAttr.getThreshold()
            ));
    }


    public synchronized boolean t_complete(YIdentifier childID, Document rawDecompositionData) throws YDataStateException {
        if (t_isBusy()) {
            Set queries = getQueriesForTaskCompletion();
            for (Iterator iter = queries.iterator(); iter.hasNext();) {
                String query = (String) iter.next();
                String localVarThatQueryResultGetsAppliedTo
                        = getMIOutputAssignmentVar(query);
                Element queryResultElement = evaluateTreeQuery(query, rawDecompositionData);
                if (_generateReports) {
                    System.out.println("\nYExternalTask::" + getID() + ".complete() query " + query);
                    String rawDataStr = new XMLOutputter().outputString(rawDecompositionData);
                    System.out.println("\nYExternalTask::" + getID() + ".complete() rawDecomositionData = "
                            + rawDataStr.trim());
                    String queryResultStr = new XMLOutputter(Format.getPrettyFormat()).outputString(queryResultElement);
                    System.out.println("\nYExternalTask::" + getID() + ".complete() QueryResult  = "
                            + queryResultStr.trim());
                }
                if (query.equals(getPreJoiningMIQuery())) {
                    _groupedOutputData.getRootElement().addContent(queryResultElement);
                } else {
                    _localVariableNameToReplaceableOuptutData.put(
                            localVarThatQueryResultGetsAppliedTo, queryResultElement);
                }
            }
            if (_generateReports) {
                System.out.println("\nYExternalTask::" + getID() + ".complete()  " +
                        "_localVariableNameToReplaceableOuptutData = " +
                        _localVariableNameToReplaceableOuptutData);
                System.out.println("\nYExternalTask::" + getID() + ".complete() _groupedOutPutData "
                        + new XMLOutputter(Format.getPrettyFormat()).outputString(_groupedOutputData));
            }
            _mi_executing.removeOne(childID);
            _mi_complete.add(childID);
            if (t_isExitEnabled()) {
                t_exit();
                return true;
            }
            return false;
        }
        throw new RuntimeException("You should not try to invoke this method when it is not active.");
    }


    protected String getMIOutputAssignmentVar(String query) {
        return (String) _dataMappingsForTaskCompletion.get(query);
    }


    private String getPreJoiningMIQuery() {
        return _multiInstAttr != null ? _multiInstAttr.getMIFormalOutputQuery() : null;
    }


    public synchronized void t_start(YIdentifier child) {
        if (t_isBusy()) {
            startOne(child);
        }
    }


    private YIdentifier getI() {
        Iterator iter;
        iter = iter = getPresetElements().iterator();
        while (iter.hasNext()) {
            YConditionInterface condition = (YConditionInterface) iter.next();
            if (condition.containsIdentifier()) {
                return (YIdentifier) condition.getIdentifiers().get(0);
            }
        }
        return null;
    }


    private synchronized void t_exit() throws YDataStateException {
        if(!t_isExitEnabled()){
            throw new RuntimeException(this + "_exit() is not enabled.");
        }
        YIdentifier i = _i;
        if (this instanceof YCompositeTask) {
            cancel();
        }
        for (Iterator removeIter = _removeSet.iterator(); removeIter.hasNext();) {
            YExternalNetElement netElement = (YExternalNetElement) removeIter.next();
            if (netElement instanceof YTask) {
                ((YTask) netElement).cancel();
            } else if(netElement instanceof YCondition) {
                ((YCondition) netElement).removeAll();
            }
        }
        _mi_active.removeAll();
        _mi_complete.removeAll();
        _mi_entered.removeAll();
        _mi_executing.removeAll();
        performDataAssignmentsAccordingToOutputExpressions();
        synchronized (_random) {
            switch (_splitType) {
                case YTask._AND:
                    doAndSplit(i);
                    break;
                case YTask._OR:
                    doOrSplit(i);
                    break;
                case YTask._XOR:
                    doXORSplit(i);
                    break;
            }
        }
        i.removeLocation(this);
        if (_generateReports/*true*/) {
            System.out.println("YTask::" + getID() + ".exit() caseID(" + _i + ") " +
                    "_parentDecomposition.getInternalDataDocument() = "
                    + new XMLOutputter(Format.getPrettyFormat()).outputString(_net.getInternalDataDocument()).trim());
        }
        _i = null;
    }


    private void performDataAssignmentsAccordingToOutputExpressions() throws YDataStateException {
        for (Iterator iter = _localVariableNameToReplaceableOuptutData.keySet().iterator();
             iter.hasNext();) {
            String localVariableName = (String) iter.next();
            Element queryResult =
                    (Element) _localVariableNameToReplaceableOuptutData.get(localVariableName);
            //todo check that queryResult is valid instance of variable type
            _net.addData(queryResult);
        }
        if (this.isMultiInstance() && _multiInstAttr.getMIJoiningQuery() != null) {
            Element result = evaluateTreeQuery(_multiInstAttr.getMIJoiningQuery(), _groupedOutputData);
            _net.addData(result);
        }
    }


    private Set getLocalVariablesForTaskCompletion() {
        return new HashSet(_dataMappingsForTaskCompletion.values());
    }


    private void doXORSplit(YIdentifier tokenToSend) {
        List flows = new ArrayList(getPostsetFlows());
        Collections.sort(flows);
        YFlow flow = null;
        for (int i = 0; i < flows.size(); i++) {
            flow = (YFlow) flows.get(i);
            if (flow.isDefaultFlow()) {
                ((YCondition) flow.getNextElement()).add(tokenToSend);
                return;
            }
            try {
                XPath xpath = XPath.newInstance("boolean(" + flow.getXpathPredicate() + ")");
                Boolean result = (Boolean) xpath.selectSingleNode(_net.getInternalDataDocument());
                if (result.booleanValue()) {
                    ((YCondition) flow.getNextElement()).add(tokenToSend);
                    return;
                }
            } catch (JDOMException e) {
                e.printStackTrace();
            }
        }
    }


    private void doOrSplit(YIdentifier tokenToSend) {
        boolean noTokensOutputted = true;
        List flows = new ArrayList(getPostsetFlows());
        Collections.sort(flows);
        YFlow flow = null;
        for (int i = 0; i < flows.size(); i++) {
            flow = (YFlow) flows.get(i);
            try {
                XPath xpath = XPath.newInstance("boolean(" + flow.getXpathPredicate() + ")");
                Boolean result = (Boolean) xpath.selectSingleNode(_net.getInternalDataDocument());
                if (result.booleanValue()) {
                    ((YCondition) flow.getNextElement()).add(tokenToSend);
                    noTokensOutputted = false;
                }
            } catch (JDOMException e) {
                e.printStackTrace();
            }
            if (flow.isDefaultFlow() && noTokensOutputted) {
                ((YCondition) flow.getNextElement()).add(tokenToSend);
            }
        }
    }


    private void doAndSplit(YIdentifier tokenToSend) {
        Set postset = getPostsetElements();
        for (Iterator iterator = postset.iterator(); iterator.hasNext();) {
            YCondition condition = (YCondition) iterator.next();
            if (tokenToSend == null) {
                throw new RuntimeException("token is equal to null = " + tokenToSend);
            }
            condition.add(tokenToSend);
        }
    }


    public synchronized boolean t_enabled(YIdentifier id) {
        //busy tasks are never enabled
        if (_i != null) {
            return false;
        }
        Set preset = getPresetElements();
        YCondition[] conditions = (YCondition[])
                preset.toArray(new YCondition[preset.size()]);
        switch (_joinType) {
            case YTask._AND:
                for (int i = 0; i < conditions.length; i++) {
                    if (!conditions[i].containsIdentifier()) {
                        return false;
                    }
                }
                return true;
            case YTask._OR:
                {
                    return _net.orJoinEnabled(this, id);
                }
            case YTask._XOR:
                for (int i = 0; i < conditions.length; i++) {
                    if (conditions[i].containsIdentifier()) {
                        return true;
                    }
                }
                return false;
            default:
                return false;
        }
    }


    public Object clone() throws CloneNotSupportedException {
        YTask copy = (YTask) super.clone();
        copy._mi_active = new YInternalCondition(YInternalCondition._mi_active, copy);
        copy._mi_complete = new YInternalCondition(YInternalCondition._mi_complete, copy);
        copy._mi_entered = new YInternalCondition(YInternalCondition._mi_entered, copy);
        copy._mi_executing = new YInternalCondition(YInternalCondition._executing, copy);
        copy._removeSet = new HashSet();
        Iterator iter = _removeSet.iterator();
        while (iter.hasNext()) {
            YExternalNetElement elem = (YExternalNetElement) iter.next();
            YExternalNetElement elemsClone = copy._net.getNetElement(elem.getID());
            if (elemsClone == null) {
                elemsClone = (YExternalNetElement) elem.clone();
            }
            copy._removeSet.add(elemsClone);
        }
/*        if (_predicateMap != null) {
            copy._predicateMap = new HashMap();
            iter = _predicateMap.keySet().iterator();
            while (iter.hasNext()) {
                YExternalNetElement elem = (YExternalNetElement) iter.next();
                YExternalNetElement elemsClone = copy._parentDecomposition.getNetElement(elem.getURI());
                if (elemsClone == null) {
                    elemsClone = (YExternalNetElement) elem.clone();
                }
                copy._predicateMap.put(elemsClone, _predicateMap.get(elem));
            }
        }*/
        if (this.isMultiInstance()) {
            copy._multiInstAttr = (YMultiInstanceAttributes) _multiInstAttr.clone();
            copy._multiInstAttr._myTask = copy;
        }
        return copy;
    }


    protected abstract void startOne(YIdentifier id);


    protected YIdentifier createFiredIdentifier() {
        YIdentifier childCaseID = _i.createChild();
        _mi_active.add(childCaseID);
        _mi_entered.add(childCaseID);
        return childCaseID;
    }


    private void prepareDataForInstanceStarting(YIdentifier childInstanceID) throws YDataStateException {
        Element dataForChildCase = new Element("data");
        Iterator iterator = _dataMappingsForTaskStarting.keySet().iterator();
        while (iterator.hasNext()) {
            String decompositionParameterName = (String) iterator.next();
            String  expression = (String)
                    _dataMappingsForTaskStarting.get(decompositionParameterName);
            if (this.isMultiInstance() && decompositionParameterName.equals(
                    _multiInstAttr.getMIFormalInputParam())) {
                Element specificMIData = (Element)
                        _multiInstanceSpecificParamsIterator.next();
                dataForChildCase.addContent(specificMIData);
            } else {
                Element result = evaluateTreeQuery(expression, _net.getInternalDataDocument());
                dataForChildCase.addContent(result);
            }

        }
        _caseToDataMap.put(childInstanceID, dataForChildCase);
    }


    private Element evaluateTreeQuery(String query, Document document) throws YDataStateException {
        Element resultingData = null;
        Object resultObj = null;
        try {
            //JDOM code for produce string for reading by SAXON
            XMLOutputter outputter = new XMLOutputter();
            //SAXON XQuery code
            Configuration configuration = new Configuration();
            StaticQueryContext staticQueryContext = new StaticQueryContext();
            QueryProcessor qp = new QueryProcessor(configuration, staticQueryContext);
            XQueryExpression xQueryExpression = qp.compileQuery(query);
            //if SAXON worked with JDOM directly (like it claims to) we could replace the next with:
            ///DocumentInfo saxonDocInfo = qp.buildDocument(new DocumentWrapper(_parentDecomposition.getInternalDataDocument(), null));
            DocumentInfo saxonDocInfo = qp.buildDocument(new StreamSource(
                    new StringReader(outputter.outputString(document))));
            DynamicQueryContext dynamicQueryContext = new DynamicQueryContext();
            dynamicQueryContext.setContextNode(saxonDocInfo);
            resultObj = xQueryExpression.evaluateSingle(dynamicQueryContext);
            NodeInfo nodeInfo = (NodeInfo) resultObj;
            //my code to parse SAXON resulting XML tree and produce a string
            //because saxons QueryResult class isn't yet able to produce the desired string from anything
            //but the root node
            if (nodeInfo != null) {
                YSaxonOutPutter saxonOutputter = new YSaxonOutPutter(nodeInfo);
                String result = saxonOutputter.getString();
                SAXBuilder builder = new SAXBuilder();
                Document doclet = builder.build(new StringReader(result));
                resultingData = doclet.detachRootElement();
            } else {
                throw new YDataStateException("The engine attempted to execute query (" + query +
                        ") over the document " +
                        new XMLOutputter(Format.getPrettyFormat()).outputString(document).trim() +
                        ". For some reason this produced nothing.");
            }
        } catch (ClassCastException e) {
            RuntimeException f = new RuntimeException("The result of the query yeilded an object of type "
                    + resultObj.getClass()
                    + ", but this engine insists on queries that produce elements only.");
            f.setStackTrace(e.getStackTrace());
            throw f;
        } catch (Exception e){
            throw new YDataStateException(e.getMessage());
        }
        return resultingData;
    }


    private List evaluateListQuery(String query, Element element) {
        List resultingData = new Vector();
        try {
            //JDOM code for produce string for reading by SAXON
            XMLOutputter outputter = new XMLOutputter();
            //SAXON XQuery code
            Configuration configuration = new Configuration();
            StaticQueryContext staticQueryContext = new StaticQueryContext();
            QueryProcessor qp = new QueryProcessor(configuration, staticQueryContext);
            XQueryExpression xQueryExpression = qp.compileQuery(query);
            //if SAXON worked with JDOM directly (like it claims to) we could replace the next with:
            ///DocumentInfo saxonDocInfo = qp.buildDocument(new DocumentWrapper(_parentDecomposition.getInternalDataDocument(), null));
            DocumentInfo saxonDocInfo = qp.buildDocument(new StreamSource(
                    new StringReader(outputter.outputString(element))));
            DynamicQueryContext dynamicQueryContext = new DynamicQueryContext();
            dynamicQueryContext.setContextNode(saxonDocInfo);
            List nodeList = xQueryExpression.evaluate(dynamicQueryContext);
            //my code to parse SAXON resulting XML tree and produce a string
            //because saxons QueryResult class isn't yet able to produce the desired string from anything
            //but the root node
            for (int i = 0; i < nodeList.size(); i++) {
                NodeInfo nodeInfo = (NodeInfo) nodeList.get(i);
                YSaxonOutPutter saxonOutputter = new YSaxonOutPutter(nodeInfo);
                String result = saxonOutputter.getString();
                if (result != null) {
                    SAXBuilder builder = new SAXBuilder();
                    Document doclet = builder.build(new StringReader(result));
                    resultingData.add(doclet.detachRootElement());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultingData;
    }


    public Element getData(YIdentifier childInstanceID) {
        return (Element) _caseToDataMap.get(childInstanceID);
    }


    public synchronized boolean t_isBusy() {
        return _i != null;
    }

    public synchronized void cancel(){
        _mi_active.removeAll();
        _mi_complete.removeAll();
        _mi_entered.removeAll();
        _mi_executing.removeAll();
        if(_i != null){
            _i.removeLocation(this);
            _i = null;
        }
    }

    public YInternalCondition getMIActive() {
        return _mi_active;
    }

    public YInternalCondition getMIEntered() {
        return _mi_entered;
    }

    public YInternalCondition getMIComplete() {
        return _mi_complete;
    }

    public YInternalCondition getMIExecuting() {
        return _mi_executing;
    }

    /**
     * The input must be map of [key="variableName", value="expression"]
     * @param map
     */
    public void setDataMappingsForTaskStarting(Map map) {
        _dataMappingsForTaskStarting.putAll(map);
    }


    /**
     * The input must be map of [key="expression", value="variableName"]
     * @param map
     */
    public void setDataMappingsForTaskCompletion(Map map) {
        _dataMappingsForTaskCompletion.putAll(map);
    }


    public String toXML() {
        StringBuffer xml = new StringBuffer();
        xml.append("<task id=\"" + this.getID() + "\"");
        if (this.isMultiInstance()) {
            xml.append(" xsi:type=\"MultipleInstanceExternalTaskFactsType\"");
            xml.append(" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"");
        }
        xml.append(">");
        xml.append(super.toXML());
        String joinType = null;
        switch (_joinType) {
            case _AND:
                joinType = "and";
                break;
            case _OR:
                joinType = "or";
                break;
            case _XOR:
                joinType = "xor";
                break;
        }
        xml.append("<join code=\"" + joinType + "\"/>");
        String splitType = null;
        switch (_splitType) {
            case _AND:
                splitType = "and";
                break;
            case _OR:
                splitType = "or";
                break;
            case _XOR:
                splitType = "xor";
                break;
        }
        xml.append("<split code=\"" + splitType + "\"/>");
        StringBuffer removeTokensFromFlow = new StringBuffer();
        List removeList = new ArrayList(_removeSet);
        Collections.sort(removeList);
        for (Iterator iterator = removeList.iterator(); iterator.hasNext();) {
            YExternalNetElement netElement = (YExternalNetElement) iterator.next();
            boolean implicitElement = false;
            if(netElement instanceof YCondition){
                YCondition maybeImplicit = (YCondition) netElement;
                if(maybeImplicit.isImplicit()){
                    removeTokensFromFlow.append("<removesTokensFromFlow>");
                    YExternalNetElement pre = (YTask) maybeImplicit.
                            getPresetElements().iterator().next();
                    removeTokensFromFlow.append("<flowSource id=\""+pre.getID()+"\"/>");
                    YExternalNetElement post = (YTask) maybeImplicit.
                            getPostsetElements().iterator().next();
                    removeTokensFromFlow.append("<flowDestination id=\""+post.getID()+"\"/>");
                    removeTokensFromFlow.append("</removesTokensFromFlow>");
                    implicitElement = true;
                }
            }
            if(! implicitElement) {
                xml.append("<removesTokens id=\"" + netElement.getID() + "\"/>");
            }
        }
        xml.append(removeTokensFromFlow);
        if (_dataMappingsForTaskStarting.size() > 0) {
            if(!(this.isMultiInstance() && _dataMappingsForTaskStarting.size() == 1)){
                xml.append("<startingMappings>");
                for (Iterator iterator = _dataMappingsForTaskStarting.keySet().iterator(); iterator.hasNext();) {
                    String mapsTo  = (String) iterator.next();
                    String  expression = (String) _dataMappingsForTaskStarting.get(mapsTo);
                    if(!isMultiInstance() || ! getPreSplittingMIQuery().equals(expression)){
                        xml.append("<mapping>");
                        xml.append("<expression query=\"" + marshal(expression) + "\"/>");
                        xml.append("<mapsTo>" + mapsTo + "</mapsTo>");
                        xml.append("</mapping>");
                    }
                }
                xml.append("</startingMappings>");
            }
        }
        if (_dataMappingsForTaskCompletion.size() > 0) {
            xml.append("<completedMappings>");
            for (Iterator iterator = _dataMappingsForTaskCompletion.keySet().iterator(); iterator.hasNext();) {
                String expression = (String) iterator.next();
                String mapsTo = (String) _dataMappingsForTaskCompletion.get(expression);
                xml.append("<mapping>");
                xml.append("<expression query=\"" + marshal(expression) + "\"/>");
                xml.append("<mapsTo>" + mapsTo + "</mapsTo>");
                xml.append("</mapping>");
            }
            xml.append("</completedMappings>");
        }
        if (_decompositionPrototype != null) {
            xml.append("<decomposesTo id=\"" + _decompositionPrototype.getID() + "\"/>");
        }
        if (isMultiInstance()) {
            xml.append(_multiInstAttr.toXML());
        }
        xml.append("</task>");
        return xml.toString();
    }


    public static String marshal(String expression) {
        if (expression != null) {
            expression = expression.replaceAll("&", "&amp;");
            expression = expression.replaceAll("<", "&lt;");
            expression = expression.replaceAll(">", "&gt;");
            expression = expression.replaceAll("\"", "&qout;");
        }
        return expression;
    }


    public YDecomposition getDecompositionPrototype() {
        return _decompositionPrototype;
    }


    public void setDecompositionPrototype(YDecomposition decomposition) {
        _decompositionPrototype = decomposition;
    }


    /**
     * Connects the query to a decomposition parameter.
     * @param query a query applied to the net variables in the net containing
     * this task.
     * @param paramName the decomposition parameter to which to apply the result.
     */
    public void setDataBindingForInputParam(String query, String paramName) {
        _dataMappingsForTaskStarting.put(paramName, query);
    }


    /**
     * Binds an output expression of a decomposition to a net variable.
     * @param query the ouptut expression belonging to the tasks decomposition
     * @param netVarName the net scope variable to which to apply the result.
     */
    public void setDataBindingForOutputExpression(String query, String netVarName) {
        _dataMappingsForTaskCompletion.put(query, netVarName);
    }


    public String getSignature(){
        try{
            YAWLServiceGateway gateway = (YAWLServiceGateway) getDecompositionPrototype();
            StringBuffer result = new StringBuffer();
            result.append("<taskInfo>");

            result.append("<specificationID>");
            result.append(_net.getSpecification().getID());
            result.append("</specificationID>");

            result.append("<taskID>");
            result.append(getID());
            result.append("</taskID>");

            result.append("<taskName>");
            result.append(_name != null ? _name : _decompositionPrototype.getID());
            result.append("</taskName>");

            if(_documentation != null){
                result.append("<taskDocumentation>");
                result.append(_documentation);
                result.append("</taskDocumentation>");
            }
            if(_decompositionPrototype != null){
                YAWLServiceGateway wsgw = (YAWLServiceGateway) _decompositionPrototype;
                YAWLServiceReference ys = wsgw.getYawlService();
                if(ys != null){
                    result.append("<yawlService>");
                    String ysID = ys.getURI();
                    result.append("<id>");
                    result.append(ysID);
                    result.append("</id>");
                    String wsdlLocation = ys.getWsdlLocation();
                    if(wsdlLocation != null){
                        result.append("<wsdlLocation>");
                        result.append(ys.getWsdlLocation());
                        result.append("</wsdlLocation>");
                    }
                    String operationName = ys.getOperationName();
                    if(operationName != null){
                        result.append("<operationName>");
                        result.append(operationName);
                        result.append("</operationName>");
                    }
                    result.append("</yawlService>");
                }
            }

            result.append("<params>");
            if (isMultiInstance()) {
                result.append(
                        "<formalInputParam>" +
                        getMultiInstanceAttributes().getMIFormalInputParam()
                        + "</formalInputParam>"
                );
            }
            Collection inputParams = gateway.getInputParameters().values();
            for (Iterator iterator = inputParams.iterator(); iterator.hasNext();) {
                YParameter parameter = (YParameter) iterator.next();
                String paramAsXML = parameter.toSummaryXML();
                result.append(paramAsXML);
            }
            Collection outputParams = gateway.getOutputParameters().values();
            for (Iterator iterator = outputParams.iterator(); iterator.hasNext();) {
                YParameter parameter = (YParameter) iterator.next();
                String paramAsXML = parameter.toSummaryXML();
                result.append(paramAsXML);
            }
            result.append("</params>");
            result.append("</taskInfo>");
            return result.toString();
        }catch(ClassCastException e){
            e.printStackTrace();
            return null;
        }
    }
}
