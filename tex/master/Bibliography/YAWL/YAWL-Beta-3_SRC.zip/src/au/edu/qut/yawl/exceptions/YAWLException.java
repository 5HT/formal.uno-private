package au.edu.qut.yawl.exceptions;

/**
 * Copyright � 2004 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 26/11/2004
 * Time: 15:26:54
 * This file remains the property of the Queensland University of 
 * Technology.
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL licence.
 * For more information about the YAWL licence refer to the 'downloads' section under
 * http://www.yawl-system.com
 */
public class YAWLException extends Exception{
    public YAWLException(String message) {
        super(message);
    }
}
