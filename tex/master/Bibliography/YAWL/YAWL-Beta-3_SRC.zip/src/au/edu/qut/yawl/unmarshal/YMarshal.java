package au.edu.qut.yawl.unmarshal;

import au.edu.qut.yawl.elements.YSpecification;
import au.edu.qut.yawl.exceptions.YSyntaxException;
import au.edu.qut.yawl.exceptions.YSchemaBuildingException;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * This file remains the property of the YAWL team at the Queensland University of
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YMarshal {

    /**
     * build a list of specification objects from a XML document.
     * @param specificationSetDoc the JDom element con
     * @return
     */
    private static List buildSpecifications(Document specificationSetDoc) throws YSchemaBuildingException, YSyntaxException  {
        Element specificationSetElem = specificationSetDoc.getRootElement();
        String version = specificationSetElem.getAttributeValue("version");
        if(null == version){
            //version attribute was not mandatory in version 2
            //therefore a missing version number would likely be version 2
            version = "beta2";
        }
        List specifications = new Vector();
        List specificationElemList = specificationSetElem.getChildren();
        for (int i = 0; i < specificationElemList.size(); i++) {

            Element xmlSpecification = (Element) specificationElemList.get(i);

            YSpecificationParser specParse = new YSpecificationParser(xmlSpecification, version);
            YSpecification spec = specParse.getSpecification();
            specifications.add(spec);
        }
        return specifications;
    }


    /**
     * Returns the _specifications.   Does some primary checking of the file against
     * schemas and checks well formedness of the XML.
     * @return List
     */
    public static List unmarshalSpecifications(String specificationSetFileID)
            throws YSyntaxException, YSchemaBuildingException, JDOMException, IOException {
        //first check if is well formed and build a document
        Element specificationSetEl = null;
        org.jdom.input.SAXBuilder builder = new SAXBuilder();
        Document document = builder.build(specificationSetFileID);
        specificationSetEl = document.getRootElement();

        //next get the version out as text - if possible
        String version = specificationSetEl.getAttributeValue("version");
        if(null == version){
            //version attribute was not mandatory in version 2
            //therefore a missing version number would likely be version 2
            version = "beta2";
        }

        //now check the specifgication file against its' respective schema
        String errors = YSchemaChecker.getInstance().checkSchema(specificationSetFileID, version);
        if (errors == null || errors.length() > 0) {
            throw new YSyntaxException(
                    " The file failed to verify against YAWL's Schema:\n"
                    + errors);
        }

        //now build a set of specifications - verifiaction has not yet occured.
        List specifications = buildSpecifications(document);
        return specifications;
    }


    public static String marshal(List specificationList, boolean generateStubbedData) {
        StringBuffer xml = new StringBuffer();
        xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
        xml.append("<specificationSet " +
                "version=\"beta3\" " +
                "xmlns=\"http://www.citi.qut.edu.au/yawl\" " +
                "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
                "xsi:schemaLocation=\"http://www.citi.qut.edu.au/yawl " +
                    "d:/yawl/schema/YAWL_SchemaBeta3.xsd\">");
        for (int i = 0; i < specificationList.size(); i++) {
            YSpecification specification = (YSpecification) specificationList.get(i);
            xml.append(specification.toXML());
        }
        xml.append("</specificationSet>");
        return xml.toString();
    }


    public static String marshal(YSpecification specification, boolean generateStubbbedData){
        List spLst = new ArrayList();
        spLst.add(specification);
        return marshal(spLst, generateStubbbedData);
    }


    public static void main(String[] args) throws IOException, YSchemaBuildingException, YSyntaxException, JDOMException {
            URL xmlFileURL = YMarshal.class.getResource("MakeRecordings.xml");
            File file = new File(xmlFileURL.getFile());
            List specifications = unmarshalSpecifications(file.getCanonicalPath());
            String marshalledSpecs = marshal(specifications, false);
            System.out.println("\n\n" + marshalledSpecs);
    }
}
