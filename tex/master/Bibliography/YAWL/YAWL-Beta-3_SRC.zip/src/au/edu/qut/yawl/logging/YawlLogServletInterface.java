package au.edu.qut.yawl.logging;
import au.edu.qut.yawl.engine.interfce.Interface_Client;

import java.util.HashMap;
import java.io.IOException;

public class YawlLogServletInterface extends Interface_Client {
    
    public String caseId = "0";
    
    public boolean enabled = true;
    
    public String servletURL = "http://localhost:8080/yawllog/servlet/YawlLogServlet";
    
    public static YawlLogServletInterface yawllog = null;

    public static YawlLogServletInterface getInstance() {
	if (yawllog == null) {
	    yawllog = new YawlLogServletInterface();
	}
	return yawllog;
    }
    
    public YawlLogServletInterface() {
    }
    
	
    public void retry() {
	enabled = true;
    }	
    
    public void logWorkItemEvent(String identifier,
				 String taskid,
				 String event,
					String resource
				 ) {
	if (!enabled)
	    return;
	
	HashMap map = new HashMap();
	
	map.put("method","LogEvent");
	map.put("id",identifier);
	map.put("task",taskid);
	map.put("event",event);
	map.put("resource",resource);


        try {
            if (executePost(servletURL,map)==null)
                enabled = false;
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void logCaseCreated(String caseid,
			       String resource,
			       String spec) {
	
	if (!enabled)
	    return;
	HashMap map = new HashMap();
	
	map.put("method","caseCreated");
	map.put("case",caseid);
	map.put("spec",spec);
	map.put("resource",resource);

        try {
            if (executePost(servletURL,map)==null)
                enabled = false;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }	
    public void logCaseCancelled(String caseid) {
	
	if (!enabled)
	    return;
	
	HashMap map = new HashMap();
		
	map.put("method","caseCancelled");
	map.put("case",caseid);


        try {
            if (executePost(servletURL,map)==null)
                enabled = false;
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    
    public void logCaseCompleted(String caseid) {
	
	if (!enabled)
	    return;
	HashMap map = new HashMap();
	
	map.put("method","caseComplete");
	map.put("case",caseid);


        try {
            if (executePost(servletURL,map)==null)
                enabled = false;
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public void createChild(String parent,
			    String child) {
	
	if (!enabled)
	    return;
	
	HashMap map = new HashMap();
	
	map.put("method","createChild");
	map.put("parent",parent);
	map.put("child",child);

        try {
            if (executePost(servletURL,map)==null)
                enabled = false;
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    
    public String getNextCaseId() {
	if (!enabled) {
	    int id = new Integer(caseId).intValue();
	    id++;
	    caseId = new Integer(id).toString();
	} else {
	    String nextid = null;
        try{
            nextid= executeGet(servletURL + "?method=nextId");

		new Integer(nextid);
	    } catch (Exception e) {
		nextid = null;
	    }
	    
	    if (nextid==null || nextid.equals("-1")) {
		enabled = false;
		int id = new Integer(caseId).intValue();
		id++;
		caseId = new Integer(id).toString();
	    }
	    else {
		caseId = nextid;
	    }
	}
	
	return caseId;
    }

}
