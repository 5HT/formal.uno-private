package au.edu.qut.yawl.engine;

/**
 * An interface to handle problems.  Implement this interface to handle any probelms. Details
 * of the problem are provided by the problem event.
 *
 *
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 15/10/2004
 * Time: 11:47:30
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public interface YProblemHandler {
    public void handleProblem(YProblemEvent problemEvent);
}
