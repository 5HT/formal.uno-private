package au.edu.qut.yawl.swingWorklist;

import au.edu.qut.yawl.elements.data.YParameter;
import au.edu.qut.yawl.elements.YTask;
import au.edu.qut.yawl.swingWorklist.util.ParamsDefinitions;
import au.edu.qut.yawl.worklist.model.Marshaller;
import au.edu.qut.yawl.worklist.model.TaskInformation;
import au.edu.qut.yawl.worklist.model.YParametersSchema;
import au.edu.qut.yawl.engine.YEngine;
import au.edu.qut.yawl.engine.YWorkItem;
import au.edu.qut.yawl.exceptions.YStateException;
import au.edu.qut.yawl.exceptions.YDataStateException;
import au.edu.qut.yawl.exceptions.YAWLException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 15/05/2003
 * Time: 16:32:43
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YWorklistModel{
    private YWorklistTableModel _availableWork;
    private YWorklistTableModel _myActiveTasks;
    private DateFormat _formatter;
    private static ParamsDefinitions _paramsDefinitions = new ParamsDefinitions();
    private static YEngine _engine = YEngine.getInstance(false);
    private String _username;

    /**
     * @param userName
     * @param createGUI
     * @deprecated Only recommended for use during testing
     */
    public YWorklistModel(String userName, boolean createGUI){
        _username = userName;
        _availableWork = new YWorklistTableModel(new String[]{
            "Case ID", "Task ID", "Description", "Status", "Enablement Time", "Firing Time"});
        _myActiveTasks = new YWorklistTableModel(new String[]{
            "Case ID", "Task ID", "Description", "Enablement Time", "Firing Time", "Start Time"});
        _formatter = new SimpleDateFormat("MMM dd H:mm:ss");
        if(createGUI){
            new YWorklistGUI(userName, this);
        }
    }



    public YWorklistModel(String userName){
        _username = userName;
        _availableWork = new YWorklistTableModel(new String[]{
            "Case ID", "Task ID", "Description", "Status", "Enablement Time", "Firing Time"});
        _myActiveTasks = new YWorklistTableModel(new String[]{
            "Case ID", "Task ID", "Description", "Enablement Time", "Firing Time", "Start Time"});
        _formatter = new SimpleDateFormat("MMM dd H:mm:ss");
        new YWorklistGUI(userName, this);
    }



    //####################################################################################
    //                    INTERFACE TO LOCAL WORKLIST
    //####################################################################################

    private void removeUnstartedWorkItem(String caseIDStr, String taskID){
        _availableWork.removeRow(caseIDStr + taskID);
    }


    private void addEnabledWorkItem(YWorkItem workItem){
        String caseIDStr = workItem.getCaseID().toString();
        String taskID = workItem.getTaskID();
        String specificationID = workItem.getSpecificationID();
        YTask task = _engine.getTaskDefinition(specificationID, taskID);
        String taskDescription = task.getName();
        if (null == taskDescription){
            taskDescription = taskID;
        }
        _availableWork.addRow(caseIDStr + taskID,
                new Object[]{caseIDStr, taskID, taskDescription, "Enabled",
                             _formatter.format(workItem.getEnablementTime()), ""});
        if(_paramsDefinitions.getParamsForTask(taskID) == null){
            String paramsAsXML = task.getSignature();
            TaskInformation taskInfo =
                    Marshaller.unmarshalTaskInformation(paramsAsXML);
            YParametersSchema paramsForTask = taskInfo.getParamSchema();
            _paramsDefinitions.setParamsForTask(taskID, paramsForTask);
        }
    }


    private void addFiredWorkItem(YWorkItem workItem){
        String caseIDStr = workItem.getCaseID().toString();
        String taskID = workItem.getTaskID();
        String specificationID = workItem.getSpecificationID();
        YTask task = _engine.getTaskDefinition(specificationID, taskID);
        String taskDescription = task.getName();
        if (null == taskDescription){
            taskDescription = taskID;
        }
        _availableWork.addRow(caseIDStr + taskID,
                new Object[]{caseIDStr,
                             taskID,
                             taskDescription,
                             "Fired",
                             _formatter.format(workItem.getEnablementTime()),
                             _formatter.format(workItem.getFiringTime())});
    }


    private void removeStartedItem(String caseIDStr, String taskID) {
        _myActiveTasks.removeRow(caseIDStr + taskID);
    }


    private void addStartedWorkItem(YWorkItem item) {
        String caseIDStr = item.getCaseID().toString();
        String taskID = item.getTaskID();
        String specificationID = item.getSpecificationID();
        YTask task = _engine.getTaskDefinition(specificationID, taskID);
        String taskDescription = task.getName();
        if (null == taskDescription){
            taskDescription = taskID;
        }
        boolean allowsDynamicInstanceCreation = true;
        try{
            _engine.checkElegibilityToAddInstances(item.getIDString());
        } catch (YAWLException e){
            allowsDynamicInstanceCreation = false;
        }
        _myActiveTasks.addRow(caseIDStr + taskID,
                new Object[]{
                    caseIDStr,
                    taskID,
                    taskDescription,
                    _formatter.format(item.getEnablementTime()),
                    _formatter.format(item.getFiringTime()),
                    _formatter.format(item.getStartTime()),
                    new Boolean(allowsDynamicInstanceCreation),
                    item.getDataString(),
                    getOutputSkeletonXML(caseIDStr, taskID)
                });
    }


    Object[] getActiveTableData(String caseIDStr, String taskIDStr){
        Object [] result = (Object []) _myActiveTasks._rows.get(caseIDStr + taskIDStr);
        return result;
    }

    void setActiveTableData(Object[] data){
        String workItemID;
        workItemID = (String)data[0] + data[1];
        _myActiveTasks._rows.put(workItemID, data);
    }





    //######################################################################################
    //                          INTERFACE TO GUI
    //######################################################################################

    // MUTATORS ############################################################################
    public void applyForWorkItem(String caseID, String taskID){
//todo delete these lines if ok
 //       List data = new Vector();
//        int rowIndex = _availableWork.getRowIndex(caseID + taskID);
//        for(int i = 0; i < _availableWork.getColumnCount(); i++){
//            data.add(_availableWork.getValueAt(rowIndex, i));
//        }
        Set workItems = _engine.getAvailableWorkItems();
        for (Iterator iterator = workItems.iterator(); iterator.hasNext();) {
            YWorkItem item = (YWorkItem) iterator.next();
            if(item.getCaseID().toString().equals(caseID) &&
                    item.getTaskID().equals(taskID)){
                try {
                    YWorkItem itemResult = _engine.startWorkItem(item, _username);

                } catch (YStateException e) {
                    e.printStackTrace();
                } catch (YDataStateException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public void createNewInstance(String caseID, String taskID, String newInstanceData) {
        Set workItems = _engine.getAllWorkItems();
        for (Iterator iterator = workItems.iterator(); iterator.hasNext();) {
            YWorkItem item = (YWorkItem) iterator.next();
            if(item.getCaseID().toString().equals(caseID) &&
                    item.getTaskID().equals(taskID)){
                try {
                    _engine.createNewInstance(item, newInstanceData);
                } catch (YStateException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public boolean allowsDynamicInstanceCreation(String caseID, String taskID) {
        Set workItems = _engine.getAllWorkItems();
        for (Iterator iterator = workItems.iterator(); iterator.hasNext();) {
            YWorkItem item = (YWorkItem) iterator.next();
            if(item.getCaseID().toString().equals(caseID) &&
                    item.getTaskID().equals(taskID)){
                try {
                    _engine.checkElegibilityToAddInstances(item.getIDString());
                    return true;
                } catch (YStateException e) {
                    return false;
                }
            }
        }
        return false;
    }


    public void attemptToFinishActiveJob(String caseID, String taskID) {
        Set workItems = _engine.getAllWorkItems();
        for (Iterator iterator = workItems.iterator(); iterator.hasNext();) {
            YWorkItem item = (YWorkItem) iterator.next();
            if(item.getCaseID().toString().equals(caseID) &&
                    item.getTaskID().equals(taskID)){
                String outputData = _myActiveTasks.getOutputData(caseID, taskID);
                try {
                    _engine.completeWorkItem(item, outputData);
                } catch (YStateException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public void rollBackActiveTask(String caseID, String taskID) {
        Set workItems = _engine.getAllWorkItems();
        for (Iterator iterator = workItems.iterator(); iterator.hasNext();) {
            YWorkItem item = (YWorkItem) iterator.next();
            if(item.getCaseID().toString().equals(caseID) &&
                    item.getTaskID().equals(taskID)){
                try {
                    _engine.suspendWorkItem(item.getIDString(), _username);
                } catch (YStateException e) {
                    e.printStackTrace();
                }
            }
        }
    }



    public void refreshLists(String userName){
        //clear the models
        List keys = new ArrayList();
        keys.addAll(_availableWork._rows.keySet());
        for (int i = 0; i < keys.size(); i++){
            String id = (String) keys.get(i);
            _availableWork.removeRow(id);
        }
        keys.clear();
        keys.addAll(_myActiveTasks._rows.keySet());
        for (int i = 0; i < keys.size(); i++){
            String id = (String) keys.get(i);
            _myActiveTasks.removeRow(id);
        }
        //now update them
        updateSelf();
//        _worklistManager.informRemotePartnerOfcurrentState(userName);
    }

    private void updateSelf() {
        Set availableWorkItems = _engine.getAvailableWorkItems();
        for (Iterator iterator = availableWorkItems.iterator(); iterator.hasNext();) {
            YWorkItem item = (YWorkItem) iterator.next();
            if(item.getStatus().equals(YWorkItem.statusEnabled)){
                addEnabledWorkItem(item);
            }
            else if(item.getStatus().equals(YWorkItem.statusFired)){
                addFiredWorkItem(item);
            }
        }
        Set allWorkItems = _engine.getAllWorkItems();
        for (Iterator iterator = allWorkItems.iterator(); iterator.hasNext();) {
            YWorkItem item = (YWorkItem) iterator.next();
            if(item.getStatus().equals(YWorkItem.statusExecuting)){
                if(item.getUserWhoIsExecutingThisItem().equals(_username)){
                    addStartedWorkItem(item);
                }
            }
        }
    }


    // ACCESSORS ###########################################################################
    public YWorklistTableModel getAvaliableModel(){
        return this._availableWork;
    }


    public YWorklistTableModel getActiveTasksModel() {
        return this._myActiveTasks;
    }


    public String getOutputSkeletonXML(String caseID, String taskID) {
        YParametersSchema params = _paramsDefinitions.getParamsForTask(taskID);
        return Marshaller.getOutputParamsInXML(params);
    }

    public List validateData() {
        List validationMessages = new Vector();

        return validationMessages;
    }


    public YParameter getMIUniqueParam(String taskID) {
        YParametersSchema p = _paramsDefinitions.getParamsForTask(taskID);
        if(p == null){
            return null;
        }
        return p.getFormalInputParam();
    }
}
