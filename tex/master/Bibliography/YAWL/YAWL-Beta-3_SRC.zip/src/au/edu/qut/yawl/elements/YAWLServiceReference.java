package au.edu.qut.yawl.elements;

import au.edu.qut.yawl.engine.YEngine;
import au.edu.qut.yawl.util.YVerificationMessage;

import java.util.ArrayList;
import java.util.List;
import java.io.StringReader;
import java.io.IOException;

import org.jdom.input.SAXBuilder;
import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.Element;

/**
 /**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 18/03/2004
 * Time: 15:10:09
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YAWLServiceReference implements YVerifiable{
    //todo split this class into two - one "partner link class with wsdlLoc and opName and more
    //todo another class for a registered yawl service
    private String _yawlServiceID;
    private String _wsdlLocation;
    private String _operationName;
    private YAWLServiceGateway _webServiceGateway;
    private String _documentation;

    public YAWLServiceReference(String yawlServiceID, YAWLServiceGateway webServiceGateway) {
        this._yawlServiceID = yawlServiceID;
        this._webServiceGateway = webServiceGateway;
    }

    public String getWsdlLocation() {
        return _wsdlLocation;
    }

    public void setWsdlLocation(String wsdlLocation) {
        this._wsdlLocation = wsdlLocation;
    }

    public String getOperationName() {
        return _operationName;
    }

    public void setOperationName(String operationName) {
        this._operationName = operationName;
    }

    public String getURI() {
        return _yawlServiceID;
    }

    public List verify() {
        List messages = new ArrayList();
        YEngine engine = YEngine.getInstance(false);
        YAWLServiceReference service = engine.getRegisteredYawlService(_yawlServiceID);
        if(service == null){
            messages.add(
                    new YVerificationMessage(
                            this,
                            "YAWL service[" + _yawlServiceID + "] at WSGateway[" +
                            _webServiceGateway.getID() + "] is not registered with engine.",
                            YVerificationMessage._errorStatus));
        }
        if((_wsdlLocation != null && _operationName == null)
                ||
                (_wsdlLocation == null && _operationName != null)){
            messages.add(
                    new YVerificationMessage(
                            this,
                            "YAWL service[" + _yawlServiceID + "] at WSGateway[" +
                            _webServiceGateway.getID() + "] must either have " +
                            "\n    no WSDL Location and no Operation Name; " +
                            "or have both a WSDL Location and an Operation Name.",
                            YVerificationMessage._errorStatus));
        }
        return messages;
    }

    public String toXML() {
        StringBuffer result = new StringBuffer();
        result.append("<yawlService id=\"" + _yawlServiceID + "\">");
        if(_documentation != null) {
            result.append("<documentation>");
            result.append(_documentation);
            result.append("</documentation>");
        }
        if(_wsdlLocation != null) {
            result.append("<wsdlLocation>");
            result.append(_wsdlLocation);
            result.append("</wsdlLocation>");
        }
        if(_operationName != null) {
            result.append("<operationName>");
            result.append(_operationName);
            result.append("</operationName>");
        }
        result.append("</yawlService>");
        return result.toString();
    }


    /**
     * Returns a YAWL service from XML (if valid).
     * @param serialisedService
     * @return
     */
    public static YAWLServiceReference unmarshal(String serialisedService){
        SAXBuilder builder = new SAXBuilder();
        try {
            Document doc = builder.build(new StringReader(serialisedService));
            String uri = doc.getRootElement().getAttributeValue("id");
            String docStr = doc.getRootElement().getChildText("documentation");
            String wsdlLocationStr = doc.getRootElement().getChildText("wsdlLocation");
            String operationNameStr = doc.getRootElement().getChildText("operationName");
            YAWLServiceReference service =  new YAWLServiceReference(uri, null);
            service.setDocumentation(docStr);
            service.setWsdlLocation(wsdlLocationStr);
            service.setOperationName(operationNameStr);
            return service;
        } catch (JDOMException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean isWorklistService() {
        return _wsdlLocation == null;
    }

    /**
     * gets the documentation
     * @return
     */
    public String getDocumentation() {
        return _documentation;
    }

    /**
     * sets the documentation
     * @param documentation
     */
    public void setDocumentation(String documentation) {
        this._documentation = documentation;
    }
}
