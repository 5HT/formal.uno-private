package au.edu.qut.yawl.elements.data;

import au.edu.qut.yawl.elements.YTask;
import au.edu.qut.yawl.elements.YDecomposition;
import au.edu.qut.yawl.util.YVerificationMessage;

import java.util.List;
import java.util.Vector;
import java.io.StringReader;
import java.io.IOException;

import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Document;
import org.jdom.output.XMLOutputter;
import org.jdom.output.Format;
import org.jdom.input.SAXBuilder;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 24/09/2003
 * Time: 15:49:36
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YParameter extends YVariable implements Comparable {
    private boolean _mandatory = false;
    private boolean _isInput;
    private int _ordering;




    /**
     * creates a parameter
     * @param dec the parent decomposition
     * @param dataType the datatype
     * @param name the name
     * @param nameSpaceURI
     * @param initialValue
     * @param inputTrueOutputFalse
     * @deprecated
     */
    public YParameter(YDecomposition dec, String dataType, String name, String nameSpaceURI, String initialValue, boolean inputTrueOutputFalse) {
        super(dec, dataType, name, initialValue, nameSpaceURI);
        _isInput = inputTrueOutputFalse;
    }


    /**
     *
     * @param dec
     * @param dataType
     * @param name
     * @param namespaceURI
     * @param mandatory
     * @param inputTrueOutputFalse
     * @deprecated
     */
    public YParameter(YDecomposition dec, String dataType, String name, String namespaceURI, boolean mandatory, boolean inputTrueOutputFalse) {
        super(dec, dataType, name, null, namespaceURI);
        _isInput = inputTrueOutputFalse;
        _mandatory = mandatory;
    }

    /**
     * creates a parameter
     * @param dec the parent decomposition
     * @param isInputParam if false means is output param
     */
    public YParameter(YDecomposition dec, boolean isInputParam){
        super(dec);
        _isInput = isInputParam;
    }


    /**
     * Establishes whether or not the parameter is meant to be mandatory
     * @param isMandatory
     */
    public void setManadatory(boolean isMandatory){
        //todo make this mean something to the engine because at the moment it means nothing
        _mandatory = isMandatory;
    }




    public boolean isMandatory() {
        return _mandatory;
    }


    public void setOrdering(int ordering) {
        _ordering = ordering;
    }


    public String getDirection() {
        return _isInput ? "input" : "output";
    }


    public String toXML() {
        StringBuffer xml = new StringBuffer();
        if (_isInput) {
            xml.append("<inputParam");
        } else {
            xml.append("<outputParam");
        }
        xml.append(toXMLGuts());
        if (_mandatory) {
            xml.append("<mandatory/>");
        }
        if (_isInput) {
            xml.append("</inputParam>");
        } else {
            xml.append("</outputParam>");
        }
        return xml.toString();
    }


    public String toSummaryXML(){
        SAXBuilder builder = new SAXBuilder();
        String xml = toXML();

        Document doc = null;
        try {
            doc = builder.build(new StringReader(xml));
        } catch (JDOMException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Element paramElem = doc.getRootElement();
        paramElem.removeChild("initialValue");
        Element typeElement = paramElem.getChild("type");
        Element orderingElem = new Element("ordering");
        orderingElem.setText("" + _ordering);
        if(null == typeElement){
            paramElem.addContent(0, orderingElem);
        } else {
            paramElem.addContent(1, orderingElem);
        }
        XMLOutputter outputter = new XMLOutputter(Format.getCompactFormat());
        return outputter.outputString(paramElem);
    }


    public String toString() {
        return toXML();
    }


    public List verify() {
        List messages = new Vector();
        messages.addAll(super.verify());
        if (_mandatory && _initialValue != null) {
            messages.add(new YVerificationMessage(this,
                    this + "cannot be mandatory and have initial value.",
                    YVerificationMessage._errorStatus));
        }
        return messages;
    }


    public int compareTo(Object o) {
        YParameter s = (YParameter) o;
        int dif = this._ordering - s._ordering;
        if (dif < 0) {
            return -1;
        }
        if (dif > 0) {
            return 1;
        }
        return 0;
    }




    public boolean isInput() {
        return _isInput;
    }
}
