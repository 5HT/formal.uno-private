package au.edu.qut.yawl.engine.interfce;

import javax.servlet.ServletContext;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.StringTokenizer;


/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 22/12/2003
 * Time: 12:03:41
 * This file remains the property of the YAWL team at the Queensland University of
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class InterfaceA_EngineBasedServer extends HttpServlet {
    private EngineGateway _engine;
    private static final boolean _debug = false;

    public void init() {
        ServletContext context = getServletContext();
        _engine = (EngineGateway) context.getAttribute("engine");
        if (_engine == null) {
            _engine = new EngineGatewayImpl();
            context.setAttribute("engine", _engine);
        }
    }


    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //reloading of the remote engine.

        PrintWriter outputWriter = ServletUtils.prepareResponse(response);
        StringBuffer output = new StringBuffer();
        output.append("<response>");
        output.append(processGetQuery(request));
        output.append("</response>");
        ServletUtils.finalizeResponse(outputWriter, output);
    }


    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //reloading of the remote engine.

        PrintWriter outputWriter = ServletUtils.prepareResponse(response);
        StringBuffer output = new StringBuffer();
        output.append("<response>");
        output.append(processPostQuery(request));
        output.append("</response>");
        ServletUtils.finalizeResponse(outputWriter, output);
    }

    protected void doPut(HttpServletRequest request, HttpServletResponse response) {

    }


    protected void doDelete(HttpServletRequest request, HttpServletResponse responce) {

    }


    //###############################################################################
    //      Start YAWL Processing methods
    //###############################################################################
    private String processGetQuery(HttpServletRequest request) {
        StringBuffer msg = new StringBuffer();
        try {
            if (_debug) {
                System.out.println("\nInterfaceA_Server_EngSide::doGet() request.getRequestURL = "
                        + request.getRequestURL());
                System.out.println("InterfaceA_EngineBasedServer::doGet() request.parameters:");
                Enumeration paramNms = request.getParameterNames();
                while (paramNms.hasMoreElements()) {
                    String name = (String) paramNms.nextElement();
                    System.out.println("\trequest.getParameter(" + name + ") = "
                            + request.getParameter(name));
                }
            }
            StringTokenizer tokens = new StringTokenizer(request.getRequestURI(), "/");
            String secondLastPartOfPath = null;
            String lastPartOfPath = null;
            String temp = null;
            while (tokens.hasMoreTokens()) {
                secondLastPartOfPath = temp;
                temp = tokens.nextToken();
                if (!tokens.hasMoreTokens()) {
                    lastPartOfPath = temp;
                }
            }
            //if parameters exist do the while
            String sessionHandle = request.getParameter("sessionHandle");
            String action = request.getParameter("action");
            if (action != null) {
                if (action.equals("checkConnection")) {
                    msg.append(_engine.checkConnectionForAdmin(sessionHandle));
                }
                else if(action.equals("getUsers")){
                    msg.append(_engine.getUsers(sessionHandle));
                }
                else if(action.equals("getList")){
                    msg.append(_engine.getSpecificationList(sessionHandle));
                }
                else if(action.equals("getYAWLServices")){
                    msg.append(_engine.getYAWLServices(sessionHandle));
                }
            }
            String specid = request.getParameter("specid");
            if (specid != null) {
                msg.append(_engine.getProcessDefinition(specid, sessionHandle));
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        if (msg.length() == 0) {
            msg.append(
                    "<failure><reason>" +
                    "params invalid or execption was thrown." +
                    "</reason></failure>");
        }
        if (_debug) {
            System.out.println("return = " + msg);
        }
        return msg.toString();
    }


    private String processPostQuery(HttpServletRequest request) {
        StringBuffer msg = new StringBuffer();
        try {
            if (_debug) {
                System.out.println("\nInterfaceA_Server_EngSide::doPost() request.getRequestURL = "
                        + request.getRequestURL());
                System.out.println("InterfaceA_EngineBasedServer::doPost() request.parameters:");
                Enumeration paramNms = request.getParameterNames();
                while (paramNms.hasMoreElements()) {
                    String name = (String) paramNms.nextElement();
                    System.out.println("\trequest.getParameter(" + name + ") = "
                            + request.getParameter(name));
                }
            }
            StringTokenizer tokens = new StringTokenizer(request.getRequestURI(), "/");
            String secondLastPartOfPath = null;
            String lastPartOfPath = null;
            String temp = null;
            while (tokens.hasMoreTokens()) {
                secondLastPartOfPath = temp;
                temp = tokens.nextToken();
                if (!tokens.hasMoreTokens()) {
                    lastPartOfPath = temp;
                }
            }
            //if parameters exist do the while
            String sessionHandle = request.getParameter("sessionHandle");
            String action = request.getParameter("action");
            if (lastPartOfPath.equals("connect")) {
                    String userID = request.getParameter("userid");
                    String password = request.getParameter("password");
                    msg.append(_engine.connect(userID, password));
            }
            if (action != null) {
                if ("createUser".equals(action) || "createAdmin".equals(action)) {
                    String userName = request.getParameter("userName");
                    String password = request.getParameter("password");
                    boolean isAdmin;
                    if ("createAdmin".equals(action)) {
                        isAdmin = true;
                    } else {
                        isAdmin = false;
                    }
                    msg.append(_engine.createUser(userName, password, isAdmin, sessionHandle));
                } else if("newYAWLService".equals(action)){
                    String serviceStr = request.getParameter("service");
                    msg.append(_engine.addYAWLService(serviceStr, sessionHandle));
                }
                if ("specID".equals(secondLastPartOfPath)) {
                    if ("unload".equals(action)) {
                        String specID = lastPartOfPath;
                        msg.append(_engine.unloadSpecification(specID, sessionHandle));
                    }
                }
            }
            if (lastPartOfPath.equals("uploader")) {
                sessionHandle = request.getHeader("YAWLSessionHandle");
                StringBuffer specification = new StringBuffer();
                ServletInputStream in = request.getInputStream();
                int i = in.read();
                while (i != -1) {
                    specification.append((char) i);
                    i = in.read();
                }
                msg.append(_engine.loadSpecification(specification.toString(), sessionHandle));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (msg.length() == 0) {
            msg.append(
                    "<failure><reason>" +
                    "params invalid or exception was thrown." +
                    "</reason></failure>");
        }
        if (_debug) {
            System.out.println("return = " + msg);
        }
        return msg.toString();
    }
}


