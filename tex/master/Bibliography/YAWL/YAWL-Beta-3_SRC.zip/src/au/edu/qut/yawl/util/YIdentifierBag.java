package au.edu.qut.yawl.util;

import au.edu.qut.yawl.elements.YConditionInterface;
import au.edu.qut.yawl.elements.state.YIdentifier;
import au.edu.qut.yawl.exceptions.YStateException;

import java.util.*;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YIdentifierBag{
	private Map _idToQtyMap = new HashMap();
    public YConditionInterface _condition;


    public YIdentifierBag(YConditionInterface condition){
        _condition = condition;
    }


	public void addIdentifier(YIdentifier identifier){
        int amount = 0;
        if(_idToQtyMap.containsKey(identifier)){
            amount = ((Integer) _idToQtyMap.get(identifier)).intValue();
        }
        _idToQtyMap.put(identifier, new Integer(++amount));
        identifier.addLocation(_condition);
	}


	public int getAmount(YIdentifier identifier){
        if(_idToQtyMap.containsKey(identifier)){
		    return  ((Integer)_idToQtyMap.get(identifier)).intValue();
        }
        else return 0;
	}


    public boolean contains(YIdentifier identifier){
        return _idToQtyMap.containsKey(identifier);
    }


	public List getIdentifiers(){
        List idList = new Vector();
        Set keys = _idToQtyMap.keySet();
        Iterator iter = keys.iterator();
        while(iter.hasNext()){
            YIdentifier identifier = (YIdentifier) iter.next();
            int amnt = ((Integer)_idToQtyMap.get(identifier)).intValue();
            for(int i = 0; i < amnt; i++){
                idList.add(identifier);
            }
        }
        return idList;
	}


    public void remove(YIdentifier identifier, int amountToRemove){
        if(_idToQtyMap.containsKey(identifier)){
            int amountExisting = ((Integer) _idToQtyMap.get(identifier)).intValue();
            if(amountToRemove <= 0){
                throw new RuntimeException("You cannot remove " + amountToRemove
                        + " from YIdentifierBag:"+_condition+ " " + identifier.toString());
            }
            else if (amountExisting > amountToRemove){
                _idToQtyMap.put(identifier, new Integer(amountExisting - amountToRemove));
                identifier.removeLocation(_condition);
            }
            else if(amountToRemove == amountExisting){
                _idToQtyMap.remove(identifier);
                identifier.removeLocation(_condition);
            }
            else{
                throw new RuntimeException("You cannot remove " + amountToRemove
                        + " tokens from YIdentifierBag:" + _condition
                        + " - this bag only contains " + amountExisting
                        + " identifiers of type " + identifier.toString());
            }
        }else{
            throw new RuntimeException("You cannot remove " + amountToRemove
                    + " tokens from YIdentifierBag:" + _condition
                    + " - this bag contains no"
                    + " identifiers of type " + identifier.toString()
                    + ".  It does have " + this.getIdentifiers()
                    + " (locations of " + identifier + ":" + identifier.getLocations() + " )"
                    );
        }
    }


    public void removeAll() {
        Iterator keys = new Vector(_idToQtyMap.keySet()).iterator();
        while(keys.hasNext()){
            YIdentifier identifier = (YIdentifier) keys.next();
            _idToQtyMap.remove(identifier);
            while(identifier.getLocations().contains(_condition)){
                identifier.getLocations().remove(_condition);
            }
        }
    }
}
