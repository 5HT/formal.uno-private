package au.edu.qut.yawl.elements;

import au.edu.qut.yawl.elements.state.YIdentifier;
import au.edu.qut.yawl.exceptions.YStateException;
import au.edu.qut.yawl.util.YIdentifierBag;

import java.util.List;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * An external condition is equivalent to a condition in the YAWL paper.
 * @author Lachlan Aldred
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YCondition extends YExternalNetElement implements YConditionInterface{
	

	protected YIdentifierBag _bag;
    private boolean _isImplicit;

	public YCondition(String id, String label, YNet container)
	{
		super(id, container);
		_name = label;
		_bag = new YIdentifierBag(this);
	}


    public YCondition(String id, YNet container)
    {
        super(id, container);
		_bag = new YIdentifierBag(this);
    }


    public void setImplicit(boolean isImplicit){
        _isImplicit = isImplicit;
    }


    public boolean isImplicit(){
        return _isImplicit;
    }


	public List verify()
	{
        return super.verify();
	}


    public boolean isAnonymous()
    {
        return _name == null;
    }






    public void add(YIdentifier identifier){
        _bag.addIdentifier(identifier);
    }

    public boolean contains(YIdentifier identifier) {
        return _bag.contains(identifier);
    }

    public boolean containsIdentifier() {
        return _bag.getIdentifiers().size() > 0;
    }

    public int getAmount(YIdentifier identifier) {
        return _bag.getAmount(identifier);
    }

    public List getIdentifiers() {
        return _bag.getIdentifiers();
    }

    public YIdentifier removeOne()  {
        YIdentifier identifier = (YIdentifier)getIdentifiers().get(0);
        _bag.remove(identifier, 1);
        return identifier;
    }

    public void removeOne(YIdentifier identifier) {
        _bag.remove(identifier, 1);
    }

    public void remove(YIdentifier identifier, int amount){
        _bag.remove(identifier, amount);
    }

    public void removeAll(YIdentifier identifier) {
        _bag.remove(identifier,_bag.getAmount(identifier));
    }

    public synchronized void removeAll() {
        _bag.removeAll();
    }

    public Object clone() throws CloneNotSupportedException{
        YNet copyContainer = _net.getCloneContainer();
        if(copyContainer.getNetElements().containsKey(this.getID())){
            return copyContainer.getNetElement(this.getID());
        }
        YCondition copiedCondition = (YCondition) super.clone();
        copiedCondition._bag = new YIdentifierBag(copiedCondition);
        return copiedCondition;
    }


    public String toXML(){
        StringBuffer xml = new StringBuffer();
        if(this instanceof YInputCondition){
            xml.append("<inputCondition");
        }
        else if(this instanceof YOutputCondition){
            xml.append("<outputCondition");
        }
        else{
            xml.append("<condition");
        }
        xml.append(" id=\"" + getID() + "\">");
        xml.append(super.toXML());
        if(this instanceof YInputCondition){
            xml.append("</inputCondition>");
        }
        else if(this instanceof YOutputCondition){
            xml.append("</outputCondition>");
        }
        else{
            xml.append("</condition>");
        }
        return xml.toString();
    }
}
