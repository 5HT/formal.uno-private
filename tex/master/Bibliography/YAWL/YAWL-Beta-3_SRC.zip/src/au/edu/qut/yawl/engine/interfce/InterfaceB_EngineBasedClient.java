package au.edu.qut.yawl.engine.interfce;

import au.edu.qut.yawl.elements.YAWLServiceReference;
import au.edu.qut.yawl.engine.YWorkItem;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.io.IOException;


/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 22/01/2004
 * Time: 17:19:12
 * This file remains the property of the YAWL team at the Queensland University of
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class InterfaceB_EngineBasedClient extends Interface_Client {

    /**
     * PRE: The work item is enabled.
     * announces a work item to a YAWL Service.
     * @param yawlService the reference to a YAWL service in the environment
     * @param workItem the work item to announce,
     */
    public static void announceWorkItem(YAWLServiceReference yawlService, YWorkItem workItem) {
        Handler myHandler = new Handler(yawlService, workItem, "announceWorkItem");
        myHandler.start();
    }


    /**
     * Annonuces work item cancellation to the YAWL Service.
     * @param yawlService the YAWL service reference.
     * @param workItem the work item to cancel.
     */
    protected static void cancelWorkItem(YAWLServiceReference yawlService, YWorkItem workItem) {
        Handler myHandler = new Handler(yawlService, workItem, "cancelWorkItem");
        myHandler.start();
    }

    /**
     * Cancels the work item, and all child
     * workitems under the provided work item.
     * @param yawlService the yawl service reference.
     * @param workItem the parent work item to cancel.
     */
    public static void cancelAllInstancesUnder(YAWLServiceReference yawlService, YWorkItem workItem) {
        Handler myHandler = new Handler(yawlService, workItem, "cancelAllInstancesUnderWorkItem");
        myHandler.start();
    }
}

class Handler extends Thread {
    private YWorkItem _workItem;
    private YAWLServiceReference _yawlService;
    private String _command;


    public Handler(YAWLServiceReference yawlService, YWorkItem workItem, String command) {
        _workItem = workItem;
        _yawlService = yawlService;
        _command = command;
    }


    public void run() {
        try {
            if ("announceWorkItem".equals(_command)) {
                String urlOfYawlService = _yawlService.getURI();
                String workItemXML = _workItem.toXML();
                Map paramsMap = new HashMap();
                paramsMap.put("workItem", workItemXML);
                paramsMap.put("action", "handleEnabledItem");
                Interface_Client.executePost(urlOfYawlService, paramsMap);
            } else if ("cancelAllInstancesUnderWorkItem".equals(_command)) {
                InterfaceB_EngineBasedClient.cancelWorkItem(_yawlService, _workItem);
                Iterator iter = _workItem.getChildren().iterator();
                while (iter.hasNext()) {
                    YWorkItem item = (YWorkItem) iter.next();
                    InterfaceB_EngineBasedClient.cancelWorkItem(_yawlService, item);
                }
            } else if ("cancelWorkItem".equals(_command)) {
                //cancel the parent
                String urlOfYawlService = _yawlService.getURI();
                String workItemXML = _workItem.toXML();
                Map paramsMap = new HashMap();
                paramsMap.put("workItem", workItemXML);
                paramsMap.put("action", "cancel");
                Interface_Client.executePost(urlOfYawlService, paramsMap);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
