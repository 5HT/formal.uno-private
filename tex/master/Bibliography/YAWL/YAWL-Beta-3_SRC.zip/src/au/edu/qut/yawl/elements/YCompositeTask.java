package au.edu.qut.yawl.elements;

import au.edu.qut.yawl.elements.state.YIdentifier;
import au.edu.qut.yawl.engine.YNetRunner;
import au.edu.qut.yawl.util.YVerificationMessage;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * A YCompositeTask object is the executable equivalent of the YCompositeTask
 * in the YAWL paper.   It has the same properties and behaviour.
 * @author Lachlan Aldred
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public final class YCompositeTask extends YTask{



	public YCompositeTask(String id, int joinType, int splitType, YNet container){
        super(id, joinType, splitType, container);
	}


    public List verify(){
        List messages = new Vector();
        messages.addAll(super.verify());
        if(_decompositionPrototype == null){
            messages.add(new YVerificationMessage(this, this + " composite task must contain a net.", YVerificationMessage._errorStatus));
        }
        if(! (_decompositionPrototype instanceof YNet)){
            messages.add(new YVerificationMessage(this, this + " composite task may not decompose to other than a net.", YVerificationMessage._errorStatus));
        }
        return messages;
    }


    public Object clone() throws CloneNotSupportedException {
        YNet copyContainer = _net.getCloneContainer();
        if(copyContainer.getNetElements().containsKey(this.getID())){
            return copyContainer.getNetElement(this.getID());
        }
        YCompositeTask copy = (YCompositeTask) super.clone();
        return copy;
    }


    protected synchronized void startOne(YIdentifier id) {
        _mi_executing.add(id);
        _mi_entered.removeOne(id);
        YNetRunner netRunner = new YNetRunner((YNet)_decompositionPrototype, this, id, getData(id));
        netRunner.start();
    }


    public synchronized void cancel(){
        if(_i != null){
            List activeChildIdentifiers = _mi_active.getIdentifiers();
            Iterator iter = activeChildIdentifiers.iterator();
            while(iter.hasNext()){
                YIdentifier identifier = (YIdentifier) iter.next();
                YNetRunner netRunner = _workItemRepository.getNetRunner(identifier);
                if(netRunner != null){
                    netRunner.cancel();
                }
            }
        }
        super.cancel();
    }
}
