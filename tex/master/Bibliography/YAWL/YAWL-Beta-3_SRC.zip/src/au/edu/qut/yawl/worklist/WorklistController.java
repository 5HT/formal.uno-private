package au.edu.qut.yawl.worklist;

import au.edu.qut.yawl.engine.interfce.InterfaceA_EnvironmentBasedClient;
import au.edu.qut.yawl.engine.interfce.InterfaceBWebsideController;
import au.edu.qut.yawl.worklist.model.*;
import au.edu.qut.yawl.elements.YAWLServiceReference;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import java.io.StringReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.util.Set;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 27/01/2004
 * Time: 18:56:33
 * This file remains the property of the YAWL team at the Queensland University of
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class WorklistController extends InterfaceBWebsideController{
    private InterfaceA_EnvironmentBasedClient _interfaceAClient;


    public WorklistController(){


    }


    public List getAvailableWork(String sessionHandle) throws JDOMException, IOException {
        List items = _interfaceBClient.getCompleteListOfLiveWorkItems(sessionHandle);
        List availableItems = new Vector();
        _model.updateWorkItems(items);
        for (Iterator iterator = items.iterator(); iterator.hasNext();) {
            WorkItemRecord record = (WorkItemRecord) iterator.next();
            if (record.getStatus().equals(WorkItemRecord.statusEnabled) ||
                    record.getStatus().equals(WorkItemRecord.statusFired)) {
                availableItems.add(record);
            }
        }
        return availableItems;
    }


    public List getActiveWork(String userid, String sessionHandle) throws JDOMException, IOException {
        List items = _interfaceBClient.getCompleteListOfLiveWorkItems(sessionHandle);
        List availableItems = new Vector();
        _model.updateWorkItems(items);
        for (Iterator iterator = items.iterator(); iterator.hasNext();) {
            WorkItemRecord record = (WorkItemRecord) iterator.next();
            if (record.getStatus().equals(WorkItemRecord.statusDeadlocked) ||
                    (record.getStatus().equals(WorkItemRecord.statusExecuting) &&
                    record.getWhoStartedMe().equals(userid))) {
                availableItems.add(record);
            }
        }
        return availableItems;
    }


    public WorkItemRecord getworkItem(String workItemID) {
        return _model.getWorkItem(workItemID);
    }


    public YParametersSchema getParamsForTask(String specID, String taskID, String sessionHandle) {
        TaskInformation taskInfo = _model.getTaskInformation(specID, taskID);
        if (taskInfo != null) {
            return taskInfo.getParamSchema();
        }
        return null;
    }


    public String getMarshalledOutputParamsForTask(String specificationID, String taskID, String sessionHandle) {
        YParametersSchema params = getParamsForTask(specificationID, taskID, sessionHandle);
        return Marshaller.getOutputParamsInXML(params);
    }


    public String getDataForWorkItem(String workItemID) {
        return _model.getDataForWorkItemID(workItemID);
    }


    public void saveWorkItem(String workItemID, String data) {
        _model.setDataForWorkItemID(workItemID, data);
    }





    public void unsaveWorkItem(String workItemID) {
        _model.unsaveWorkItem(workItemID);
    }


    public String checkPermissionToAddInstances(String workItemID, String sessionHandle) throws IOException {
        return _interfaceBClient.checkPermissionToAddInstances(
                workItemID,
                sessionHandle);
    }


    public String createNewInstance(String workItemID,
                                    String paramValueForMICreation,
                                    String sessionHandle) throws IOException {
        return _interfaceBClient.createNewInstance(
                workItemID, paramValueForMICreation, sessionHandle);
    }


    public WorkItemRecord addWorkItem(String workItemXML) {
        WorkItemRecord itemRecord = Marshaller.unmarshalWorkItem(workItemXML);
        _model.addWorkItem(itemRecord);
        return itemRecord;
    }


    public String suspendWorkItem(String workItemID, String sessionHandle) throws IOException {
        return _interfaceBClient.suspendWorkItem(workItemID, sessionHandle);
    }


    public List getSpecificationList(String sessionHandle) throws IOException {
        List specSummaryList = _interfaceBClient.getSpecificationList(sessionHandle);
        for (int i = 0; i < specSummaryList.size(); i++) {
            SpecificationData data = (SpecificationData) specSummaryList.get(i);
            _model.setSpecificationData(data);
        }
        return specSummaryList;
    }


    /**
     * Gets the specification data object with the spec id.  If called the first time
     * it will retrieve the information from the engine.  Otherwise it will use a copy
     * cached locally.
     * @see au.edu.qut.yawl.worklist.model.SpecificationData
     * @param specID
     * @param sessionHandle
     * @return a Specification data object for spec id else null.
     * @throws IOException
     */
    public SpecificationData getSpecificationData(String specID, String sessionHandle) throws IOException {
        SpecificationData specData = _model.getSpecificationData(specID);
        if(specData != null){
            String specAsXML = specData.getAsXML();
            if(specAsXML == null){
                specAsXML = _interfaceBClient.getSpecification(specID, sessionHandle);

                specData.setSpecAsXML(specAsXML);
            }
        }
        return specData;
    }


    public String launchCase(String specID, String caseData, String sessionHandle) throws IOException {
        return _interfaceBClient.launchCase(specID, caseData, sessionHandle);
    }


    public List getCases(String specID, String sessionHandle) throws IOException {
        String casesAsXML = _interfaceBClient.getCases(specID, sessionHandle);
        if(_interfaceBClient.successful(casesAsXML)){
            List cases = Marshaller.unmarshalCaseIDs(casesAsXML);
            return cases;
        }
        return null;
    }

    public String getCaseState(String caseID, String sessionHandle) throws IOException {
        String result = _interfaceBClient.getCaseState(caseID, sessionHandle);
        StringBuffer html = new StringBuffer();
        SAXBuilder builder = new SAXBuilder();
        Document doc;
        try {
            doc = builder.build(new StringReader(result));
            List kids = doc.getRootElement().getChildren();
            for (int i = 0; i < kids.size(); i++) {
                html.append("<tr><td>&nbsp</td><td><pre>\n");
                Element yawlElement = (Element) kids.get(i);
                String id = yawlElement.getAttributeValue("id");
                String name = yawlElement.getAttributeValue("name");
                if(yawlElement.getName().equals("task")){
                    html.append(
                            "    Task ");
                    if(name.equals("null")){
                        html.append(
                            " id: " + id + "\n");
                    } else {
                        html.append(
                            " name: " + name + "\n");
                    }
                    List kidsOfKids = yawlElement.getChildren();
                    for (int j = 0; j < kidsOfKids.size(); j++) {
                        Element internalCondition = (Element) kidsOfKids.get(j);
                        html.append(
                            "        Internal Condition id:"
                                + internalCondition.getAttributeValue("id") + "\n"
                        );
                        List idientifiers = internalCondition.getChildren();
                        for (int k = 0; k < idientifiers.size(); k++) {
                            Element identifier = (Element) idientifiers.get(k);
                            html.append(
                            "            Identifier: " + identifier.getText() + "\n"
                            );
                        }
                    }
                }else{
            html.append(
                            "    Condition ");
                    if(name.equals("null")){
                        html.append(
                            " id: " + id + "\n");
                    } else {
                        html.append(
                            " name: " + name + "\n");
                    }
                    List idientifiers = yawlElement.getChildren();
                    for (int k = 0; k < idientifiers.size(); k++) {
                        Element identifier = (Element) idientifiers.get(k);
                        html.append(
                        "            Identifier: " + identifier.getText() + "\n"
                        );
                    }
                }
                html.append("</pre></td></tr>");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return html.toString();
    }

    public String cancelCase(String caseID, String sessionHandle) throws IOException {
        return _interfaceBClient.cancelCase(caseID, sessionHandle);
    }

    /**
     * Implements InterfaceBWebsideController.  It recieves messages from the engine
     * notifying an enabled task and acts accordingly.  In the case of a worklist
     * it does nothing because work items are pulled from the engine.
     * @param workItemRecord
     */
    public void handleEnabledWorkItemEvent(WorkItemRecord workItemRecord) {
    }


    public void handleCancelledWorkItemEvent(WorkItemRecord workItemRecord) {
    }

    public boolean checkConnectionForAdmin(String sessionHandle) {
        String msg = _interfaceAClient.checkConnection(sessionHandle);
        return _interfaceBClient.successful(msg);
    }


    /**
     * Return a set of yawl services
     * @param sessionHandle use to ensure authentication.
     * @return yawl service objects
     */
    public Set getRegisteredYAWLServices(String sessionHandle){
        return _interfaceAClient.getRegisteredYAWLServices(sessionHandle);
    }

    public void setUpInterfaceAClient(String backEndURI) {
        _interfaceAClient = new InterfaceA_EnvironmentBasedClient(backEndURI);
    }

    public String uploadSpecification(String specification, String sessionHandle) {
        return _interfaceAClient.uploadSpecification(specification, sessionHandle);
    }

    public String unloadSpecification(String specID, String sessionHandle) throws IOException {
        return _interfaceAClient.unloadSpecification(specID, sessionHandle);
    }

    public String createUser(String userName, String password,
                             boolean isAdmin, String sessionHandle) throws IOException {
        return _interfaceAClient.createUser(userName, password, isAdmin, sessionHandle);
    }

    public List getUsers(String sessionHandle) {
        return _interfaceAClient.getUsers(sessionHandle);
    }


    /**
     * Adds a YAWL service to the engine.  It doesn't create the service. the service is assumed
     * to already exist.
     * @param serviceURI URI of it
     * @param serviceDocumentation
     * @param sessionHandle
     * @return result message success / failure ...reason
     */
    public String addYAWLService(String serviceURI, String serviceDocumentation, String sessionHandle) throws IOException {
        YAWLServiceReference service = new YAWLServiceReference(serviceURI, null);
        service.setDocumentation(serviceDocumentation);
        return _interfaceAClient.setYAWLService(service, sessionHandle);
    }
}
