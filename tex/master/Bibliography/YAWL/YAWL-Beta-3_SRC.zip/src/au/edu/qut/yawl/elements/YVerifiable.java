package au.edu.qut.yawl.elements;

import java.util.List;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 27/10/2003
 * Time: 14:41:07
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public interface YVerifiable {
    /**
     * The verify method returns a list of YVerificationMessage objects
     * @see au.edu.qut.yawl.util.YVerificationMessage
     * @return List of YVerificationMessage
     */
    public List verify();
}
