package au.edu.qut.yawl.engine;

import au.edu.qut.yawl.elements.state.YIdentifier;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 23/05/2003
 * Time: 14:32:32
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YWorkItemID {
    private YIdentifier _caseID;
    private String _taskID;

    public YWorkItemID(YIdentifier caseID, String taskID) {
        _caseID = caseID;
        _taskID = taskID;
    }

    public String toString() {
        return _caseID.toString() + ":" + _taskID;
    }

    public YIdentifier getCaseID() {
        return _caseID;
    }

    public String getTaskID() {
        return _taskID;
    }
}
