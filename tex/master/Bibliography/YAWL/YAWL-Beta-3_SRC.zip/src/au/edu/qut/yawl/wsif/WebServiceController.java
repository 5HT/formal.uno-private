package au.edu.qut.yawl.wsif;

import au.edu.qut.yawl.engine.interfce.InterfaceBWebsideController;
import au.edu.qut.yawl.worklist.model.TaskInformation;
import au.edu.qut.yawl.worklist.model.WorkItemRecord;
import au.edu.qut.yawl.exceptions.YStateException;
import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.io.IOException;


/**
 *
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 19/03/2004
 * Time: 11:40:59
 * This file remains the property of the YAWL team at the Queensland University of
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class WebServiceController extends InterfaceBWebsideController {

    private String _userName4Engine = "admin";
    private String _password4Engine = "YAWL";
    private String _sessionHandle = null;



    /**
     * Implements InterfaceBWebsideController.  It recieves messages from the engine
     * notifying an enabled task and acts accordingly.  In this case it takes the message,
     * tries to check out the work item, and if successful it begins to start up a web service
     * invokation.
     * @param enabledWorkItem
     */
    public void handleEnabledWorkItemEvent(WorkItemRecord enabledWorkItem) {

        try {
            if (!checkConnection(_sessionHandle)) {
                _sessionHandle = connect(_userName4Engine, _password4Engine);
            }
            if (successful(_sessionHandle)) {
                String result = checkOut(enabledWorkItem.getID(), _sessionHandle);
                if (successful(result)) {
                    TaskInformation taskInfo = getTaskInformation(
                            enabledWorkItem.getSpecificationID(),
                            enabledWorkItem.getTaskID(), _sessionHandle);
                    List mixedChildren = super.getChildren(enabledWorkItem.getID(), _sessionHandle);
                    for (int i = 0; i < mixedChildren.size(); i++) {
                        WorkItemRecord itemRecord = (WorkItemRecord) mixedChildren.get(i);
                        if (WorkItemRecord.statusFired.equals(itemRecord.getStatus())) {
                            result += checkOut(itemRecord.getID(), _sessionHandle);
                        }
                    }
                    List executingChildren = super.getChildren(enabledWorkItem.getID(), _sessionHandle);
                    for (int i = 0; i < executingChildren.size(); i++) {
                        WorkItemRecord itemRecord = (WorkItemRecord) executingChildren.get(i);
                        Element inputData = itemRecord.getDataList();
                        String wsdlLocation = taskInfo.getWSDLLocation();
                        String operationName = taskInfo.getOperationName();

                        Map reply = WSIFInvoker.invokeMethod(
                                wsdlLocation,
                                operationName,
                                inputData,
                                getAuthenticationConfig());
                        StringBuffer replyStr = new StringBuffer();
                        replyStr.append("<data>");
                        for (Iterator iterator = reply.keySet().iterator(); iterator.hasNext();) {
                            String varName = (String) iterator.next();
                            Object replyMsg = reply.get(varName);
                            System.out.println("replyMsg class = " + replyMsg.getClass().getName());
                            String varVal = replyMsg.toString();
                            replyStr.append("<" + varName + ">");
                            replyStr.append(varVal);
                            replyStr.append("</" + varName + ">");
                        }
                        replyStr.append("</data>");
                        String inputDataStr = new XMLOutputter(Format.getCompactFormat())
                                .outputString(inputData);

                        result += checkInWorkItem(
                                itemRecord.getID(),
                                inputDataStr,
                                replyStr.toString(),
                                _sessionHandle);
                    }
                    System.out.println("WebServiceController::handleEnabledWorkItemEvent() finalReport = " + result);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void handleCancelledWorkItemEvent(WorkItemRecord workItemRecord) {

    }

}

