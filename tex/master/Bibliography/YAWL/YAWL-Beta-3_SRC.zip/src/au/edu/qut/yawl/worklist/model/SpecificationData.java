package au.edu.qut.yawl.worklist.model;

import au.edu.qut.yawl.elements.data.YParameter;

import java.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.net.URL;

import org.jdom.input.SAXBuilder;
import org.jdom.JDOMException;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Namespace;
import org.jdom.output.XMLOutputter;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;


/**
 *  Just some summary data about a workflow specification.
 *
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 8/03/2004
 * Time: 12:16:02
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class SpecificationData {
    private String _specificationID;
    private String _specificationName;
    private String _documentation;
    private String _status;
    private String _specAsXML;
    private Map _inputParams = new HashMap();
    private Map _dataTypes = new HashMap();


    public SpecificationData(String specificationID, String specificationName,
                             String documentation, String status) {
        this._specificationID = specificationID;
        this._specificationName = specificationName;
        this._documentation = documentation;
        this._status = status;
    }


    public String getStatus() {
        return _status;
    }


    public String getID() {
        return _specificationID;
    }


    public String getName() {
        return _specificationName;
    }


    public String getDocumentation() {
        return _documentation;
    }


    public String getAsXML() {
        return _specAsXML;
    }


    public void setSpecAsXML(String specAsXML) {
        this._specAsXML = specAsXML;
    }


    public void addInputParam(YParameter parameter) {
        _inputParams.put(parameter.getName(), parameter);
    }


    public List getInputParams(){
        List params = new ArrayList(_inputParams.values());
        Collections.sort(params);
        return params;
    }


    public void setDataType(String nameSpaceURI, String typeName, String typeSpecification){
        _dataTypes.put(nameSpaceURI + "#" + typeName, typeSpecification);
    }


    public String getDataType(String typeName){
        return (String) _dataTypes.get(typeName);
    }

    /**
     * If the specification contains a schema library this method returns the
     * schema library as a string (in XML Schema format).
     * @return  schema library as a string.
     */
    public String getSchemaLibrary() throws IOException, JDOMException {
        SAXBuilder builder = new SAXBuilder();
        
        InputSource yawlSpecificationInputSource = new InputSource(new StringReader(_specAsXML));

        Document document = builder.build(yawlSpecificationInputSource);
        Element yawlSpecSetElement = document.getRootElement();
        
        Namespace yawlNameSpace = Namespace.getNamespace("http://www.citi.qut.edu.au/yawl");
        Element yawlSpecElement = yawlSpecSetElement.getChild("specification", yawlNameSpace);
        
        Namespace schema2SchNS = Namespace.getNamespace("http://www.w3.org/2001/XMLSchema");
        Element schemaLibraryElement = yawlSpecElement.getChild("schema", schema2SchNS);
        
        if(schemaLibraryElement != null){
            XMLOutputter output = new XMLOutputter();
            return output.outputString(schemaLibraryElement);
        }
        return null;
    }
    
    public static void main(String args[]) throws Exception{
    	SpecificationData sd = new SpecificationData("specid", "specname", "doco", "ok");
    	StringBuffer sb = new StringBuffer();
    	URL url = SpecificationData.class.getResource("MakeRecordings.xml");
    	File f = new File(url.getFile());
    	BufferedReader br = new BufferedReader(new FileReader(f));
    	String line = null;
    	
    	while((line = br.readLine()) != null){
    		sb.append(line);
    	}
    	sd.setSpecAsXML(sb.toString());
    	
    	System.out.println(sb.toString());
    	System.out.println(sd.getSchemaLibrary());
    }
}