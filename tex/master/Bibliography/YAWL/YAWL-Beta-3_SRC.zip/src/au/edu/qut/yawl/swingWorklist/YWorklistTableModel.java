package au.edu.qut.yawl.swingWorklist;

import au.edu.qut.yawl.worklist.model.Marshaller;

import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 15/05/2003
 * Time: 13:51:11
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YWorklistTableModel extends AbstractTableModel {
    protected Map _rows = new TreeMap();
    private String[] _colNames;

    public YWorklistTableModel(String[] colNames) {
        _colNames = colNames;
    }


    /**
     * Returns the number of rows in the model. A
     * <code>JTable</code> uses this method to determine how many rows it
     * should display.  This method should be quick, as it
     * is called frequently during rendering.
     *
     * @return the number of rows in the model
     * @see #getColumnCount
     */
    public synchronized int getRowCount() {
        return _rows.size();
    }


    /**
     * Returns the number of columns in the model. A
     * <code>JTable</code> uses this method to determine how many columns it
     * should create and display by default.
     *
     * @return the number of columns in the model
     * @see #getRowCount
     */
    public synchronized int getColumnCount() {
        if (_colNames != null) {
            return _colNames.length;
        }
        return 0;
    }


    /**
     * Returns the value for the cell at <code>columnIndex</code> and
     * <code>rowIndex</code>.
     *
     * @param	rowIndex	the row whose value is to be queried
     * @param	columnIndex 	the column whose value is to be queried
     * @return	the value Object at the specified cell
     */
    public synchronized Object getValueAt(int rowIndex, int columnIndex) {
        if (rowIndex < _rows.size()) {
            Object[] row = ((Object[]) new Vector(_rows.values()).get(rowIndex));
            if (row.length > columnIndex) {
                return row[columnIndex];
            }
        }
        return null;
    }


/*
    public void setValueAt(Object value, int rowIndex, int columnIndex){
        ((Object[])_rows.get(rowIndex))[columnIndex]= value;
    }
*/


    public synchronized void addRow(Object key, Object[] rowValues) {
        _rows.put(key, rowValues);
        final int position = new Vector(_rows.keySet()).indexOf(key);
        EventQueue.invokeLater(new Thread() {
            public void run() {
                fireTableRowsInserted(position, position);
            }
        });
    }


    public synchronized String getColumnName(int columnIndex) {
        if (this._colNames != null && _colNames.length > 0) {
            return _colNames[columnIndex % _colNames.length];
        } else
            return super.getColumnName(columnIndex);
    }


    public synchronized void removeRow(Object caseAndTaskID) {
        final int rowIndex = getRowIndex(caseAndTaskID);
        if (rowIndex >= 0) {
            _rows.remove(caseAndTaskID);
            EventQueue.invokeLater(new Thread() {
                public void run() {
                    fireTableRowsDeleted(rowIndex, rowIndex);
                }
            });
        }
    }


    public synchronized Class getColumnClass(int c) {
        Object o = getValueAt(0, c);
        return o != null ? o.getClass() : null;
    }


    public synchronized int getRowIndex(Object caseAndTaskID) {
        return new Vector(_rows.keySet()).indexOf(caseAndTaskID);
    }


    public String[] getColumnNames() {
        return _colNames;
    }

    public Map getRowMap() {
        return _rows;
    }

/*    public String getOutputData(String caseIDStr, String taskID) {
        Object[] row = (Object[]) _rows.get(caseIDStr + taskID);
        if (row != null && row.length > 8) {
            String outputParamsData = (String) row[8];
            String inputParamsData = (String) row[7];
            SAXBuilder builder = new SAXBuilder();
            Document finalDoc = null;
            Document outputDataDoc = null;
            try {
                finalDoc = builder.build(new StringReader(inputParamsData));
                outputDataDoc = builder.build(new StringReader(outputParamsData));
                java.util.List children = outputDataDoc.getRootElement().getContent();
                for (int i = 0; i < children.size(); i++) {
                    Object o = children.get(i);
                    if (o instanceof Element) {
                        Element child = (Element) o;
                        child.detach();
                        finalDoc.getRootElement().removeChild(child.getName());
                        finalDoc.getRootElement().addContent(child);
                    }
                }
            } catch (JDOMException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return new XMLOutputter().outputString(finalDoc.getRootElement()).trim();
        }
        return null;
    }*/


    public String getOutputData(String caseIDStr, String taskID) {
        Object[] row = (Object[]) _rows.get(caseIDStr + taskID);
        if (row != null && row.length > 8) {
            String outputParamsData = (String) row[8];
            String inputParamsData = (String) row[7];
            return Marshaller.getFinalOutputData(inputParamsData, outputParamsData);
        }
        return null;
    }
}
