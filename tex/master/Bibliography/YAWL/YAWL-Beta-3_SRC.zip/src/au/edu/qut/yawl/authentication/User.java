package au.edu.qut.yawl.authentication;

/**
 /**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 19/04/2004
 * Time: 15:59:23
 * This file remains the property of the YAWL team at the Queensland University of
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class User {
    String _userID;
    String _password;
    private boolean _isAdmin = false;

    public User(String userID, String password) {
        this._userID = userID;
        this._password = password;
    }

    public String getUserID() {
        return _userID;
    }

    public String toString() {
        return "<userid>" + _userID + "</userid>" +
                "<password>" + _password + "</password>";
    }

    public boolean isAdmin() {
        return _isAdmin;
    }

    public void setAdmin(boolean isAdmin) {
        _isAdmin = isAdmin;
    }

    public String toXML() {
        StringBuffer result = new StringBuffer();
        result.append("<user>");
        result.append("<id>" + _userID + "</id>");
        result.append("<isAdmin>" + _isAdmin + "</isAdmin>");
        result.append("</user>");
        return result.toString();
    }
}
