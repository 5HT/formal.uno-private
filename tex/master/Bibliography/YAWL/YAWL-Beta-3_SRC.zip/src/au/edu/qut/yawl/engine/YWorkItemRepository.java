package au.edu.qut.yawl.engine;

import au.edu.qut.yawl.elements.state.YIdentifier;
import au.edu.qut.yawl.elements.YTask;

import java.util.*;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 30/05/2003
 * Time: 14:04:39
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YWorkItemRepository {
    private static Map _idStringToWorkItemsMap = new HashMap();//[case&taskIDStr=YWorkItem]
    protected static Map _caseToNetRunnerMap = new HashMap();
    private static YWorkItemRepository _myInstance;


    private YWorkItemRepository(){
    }


    public static YWorkItemRepository getInstance() {
        if (_myInstance == null) {
            _myInstance = new YWorkItemRepository();
        }
        return _myInstance;
    }


    //mutators
    protected void addNewWorkItem(YWorkItem workItem) {
        _idStringToWorkItemsMap.put(workItem.getIDString(), workItem);
    }


    private void  removeWorkItem(YWorkItem workItem) {
        _idStringToWorkItemsMap.remove(workItem.getIDString());
    }


    public boolean removeWorkItemFamily(YWorkItem workItem) {
        Set children = workItem.getParent() == null ? workItem.getChildren() : workItem.getParent().getChildren();
        YWorkItem parent = workItem.getParent() == null ? workItem : workItem.getParent();
        if (parent != null){
            if(children != null) {
                Iterator iter = children.iterator();
                while (iter.hasNext()) {
                    YWorkItem siblingItem = (YWorkItem) iter.next();
                    removeWorkItem(siblingItem);
                }
            }
            removeWorkItem(parent);
            return true;
        }
        return false;
    }


    //look up tables to find netrunners
    public void setNetRunnerToCaseIDBinding(YNetRunner netRunner, YIdentifier caseID) {
        _caseToNetRunnerMap.put(caseID, netRunner);
    }


    protected void clear() {
        _idStringToWorkItemsMap = new HashMap();
        _caseToNetRunnerMap = new HashMap();
    }


    /**
     * Cancels the net runner and removes any workitems that belong to it.
     * @param caseIDForNet
     */
    public void cancelSubnet(YIdentifier caseIDForNet) {
        _caseToNetRunnerMap.remove(caseIDForNet);
        List allWorkItems = new ArrayList(_idStringToWorkItemsMap.values());
        //go through all the work items and if there are any belonging to
        //the id for this net then remove them.
        for (int i = 0; i < allWorkItems.size(); i++) {
            YWorkItem item = (YWorkItem) allWorkItems.get(i);
            YIdentifier identifier = item.getWorkItemID().getCaseID();
            if(identifier.isImmediateChildOf(caseIDForNet)){
                _idStringToWorkItemsMap.remove(item.getWorkItemID().toString());
            }
        }
    }


    //###################################################################################
    //                                  accessors
    //###################################################################################

    public YNetRunner getNetRunner(YIdentifier caseID) {
        return (YNetRunner)
                _caseToNetRunnerMap.get(caseID);
/*        return (YNetRunner)
                (_caseToNetRunnerMap.containsKey(caseID) ?
                _caseToNetRunnerMap.get(caseID) : _caseToNetRunnerMap.get(caseID.getFather()));*/
    }


    public YWorkItem getWorkItem(String caseIDStr, String taskID) {
        return (YWorkItem) _idStringToWorkItemsMap.get(caseIDStr + ":" + taskID);
    }


    public YWorkItem getWorkItem(String workItemID){
        return (YWorkItem) _idStringToWorkItemsMap.get(workItemID);
    }


    public Set getEnabledWorkItems() {
        Set aSet = new HashSet();
        Iterator iter = _idStringToWorkItemsMap.values().iterator();
        while (iter.hasNext()) {
            YWorkItem workitem = (YWorkItem) iter.next();
            if (workitem.getStatus() == YWorkItem.statusEnabled) {
                YIdentifier caseID = workitem.getWorkItemID().getCaseID();
                YNetRunner runner = (YNetRunner) _caseToNetRunnerMap.get(
                        caseID);
                Set enabledTasks = runner.getEnabledTasks();
                for (Iterator iterator = enabledTasks.iterator(); iterator.hasNext();) {
                    YTask task = (YTask) iterator.next();
                    if(task.getID().equals(workitem.getTaskID())){
                        aSet.add(workitem);
                    }
                }
            }
        }
        return aSet;
    }


    public Set getParentWorkItems(){
        Set aSet = new HashSet();
        Iterator iter = _idStringToWorkItemsMap.values().iterator();
        while (iter.hasNext()) {
            YWorkItem workitem = (YWorkItem) iter.next();
            if (workitem.getStatus() == YWorkItem.statusIsParent) {
                aSet.add(workitem);
            }
        }
        return aSet;
    }


    public Set getFiredWorkItems() {
        Set aSet = new HashSet();
        Iterator iter = _idStringToWorkItemsMap.values().iterator();
        while (iter.hasNext()) {
            YWorkItem workitem = (YWorkItem) iter.next();
            if (workitem.getStatus() == YWorkItem.statusFired) {
                aSet.add(workitem);
            }
        }
        return aSet;
    }


    public Set getExecutingWorkItems() {
        Set aSet = new HashSet();
        Iterator iter = _idStringToWorkItemsMap.values().iterator();
        while (iter.hasNext()) {
            YWorkItem workitem = (YWorkItem) iter.next();
            if (workitem.getStatus() == YWorkItem.statusExecuting) {
                aSet.add(workitem);
            }
        }
        return aSet;
    }


    public Set getExecutingWorkItems(String userName) {
        Set aSet = new HashSet();
        Iterator iter = _idStringToWorkItemsMap.values().iterator();
        while (iter.hasNext()) {
            YWorkItem workitem = (YWorkItem) iter.next();
            if (workitem.getStatus() == YWorkItem.statusExecuting &&
                    workitem.getUserWhoIsExecutingThisItem().equals(userName)) {
                aSet.add(workitem);
            }
        }
        return aSet;
    }


    public Set getCompletedWorkItems() {
        Set aSet = new HashSet();
        Iterator iter = _idStringToWorkItemsMap.values().iterator();
        while (iter.hasNext()) {
            YWorkItem workitem = (YWorkItem) iter.next();
            if (workitem.getStatus() == YWorkItem.statusComplete) {
                aSet.add(workitem);
            }
        }
        return aSet;
    }


    public Set getWorkItems(){
        return new HashSet(_idStringToWorkItemsMap.values());
    }


    public Map getNetRunners() {
        return _caseToNetRunnerMap;
    }


    public Set getChildrenOf(String workItemID) {
        YWorkItem item = (YWorkItem) _idStringToWorkItemsMap.get(workItemID);
        if(item != null){
            return item.getChildren();
        }
        else return new HashSet();
    }

    /**
     * Removes all work items for a given case id.  Searches through the work items for
     * ones that are related to the case id and removes them.
     * @param caseID must be a case id, (not a child of a caseid).
     */
    public void removeWorkItemsForCase(YIdentifier caseID) {
        if(caseID == null || caseID.getFather() != null){
            throw new IllegalArgumentException("the argument <caseID> is not valid.");
        }
        Set workItems = getWorkItems();
        for (Iterator iterator = workItems.iterator(); iterator.hasNext();) {
            YWorkItem item = (YWorkItem) iterator.next();
            YWorkItemID wid = item.getWorkItemID();
            //get the root id for this work items case
            //and if it matches the cancellation case id then remove it.
            YIdentifier workItemsCaseID = wid.getCaseID();
            while(workItemsCaseID.getFather() != null){
                workItemsCaseID = workItemsCaseID.getFather();
            }
            //if a work item's root case id matches case to be cancelled
            //then remove it.
            if(workItemsCaseID.toString().equals(caseID.toString())){
                removeWorkItemFamily(item);
            }
        }
    }
}
