package au.edu.qut.yawl.worklist;

import au.edu.qut.yawl.worklist.model.SpecificationData;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 /**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 8/03/2004
 * Time: 14:41:54
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class SpecificationBrowser extends HttpServlet{


    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        WorklistController controller = null;
        ServletContext context = getServletContext();
        controller = (WorklistController) context.getAttribute(
                "au.edu.qut.yawl.worklist.WorklistController");
        if(controller == null){
            controller = new WorklistController();
            controller.setUpInterfaceBClient(context.getInitParameter("InterfaceB_BackEnd"));
            controller.setUpInterfaceAClient(context.getInitParameter("InterfaceA_BackEnd"));
            context.setAttribute("au.edu.qut.yawl.worklist.WorklistController", controller);
        }
        response.setContentType("text/xml");
        StringBuffer output = new StringBuffer();
        PrintWriter outputWriter = response.getWriter();
        String specID = request.getParameter("specID");
        if(specID != null){
            SpecificationData specData = controller.getSpecificationData(
                    specID,
                    (String)request.getSession().getAttribute("sessionHandle"));
            String specAsXML = specData.getAsXML();
            output.append(specAsXML);
        }
        outputWriter.write(output.toString());
        outputWriter.flush();
        outputWriter.close();
    }
}
