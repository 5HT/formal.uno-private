package au.edu.qut.yawl.util;

import java.util.List;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 7/10/2003
 * Time: 14:21:11
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YVerificationMessage {
    private Object _source;
    private String _message;
    private String _status;
    public static String _errorStatus = "Error";
    public static String _warningStatus = "Warning";


    public YVerificationMessage(Object source, String message, String status){
        _source = source;
        _message = message;
        _status = status;
    }


    public Object getSource() {
        return _source;
    }


    public String getMessage() {
        return _message;
    }


    public String getStatus(){
        return _status;
    }


    public static boolean containsNoErrors(List messages) {
        for (int i = 0; i < messages.size(); i++) {
            YVerificationMessage message = (YVerificationMessage) messages.get(i);
            if(message.getStatus() == _errorStatus){
                return false;
            }
        }
        return true;
    }

    public void setSource(Object source) {
        _source = source;
    }
}
