package au.edu.qut.yawl.worklist.model;

import au.edu.qut.yawl.elements.data.YParameter;
import au.edu.qut.yawl.unmarshal.YDecompositionParser;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 16/02/2004
 * Time: 18:41:17
 * This file remains the property of the YAWL team at the Queensland University of
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class Marshaller {
    private static SAXBuilder builder = new SAXBuilder();

    public static String getOutputParamsInXML(YParametersSchema params) {
        StringBuffer result = new StringBuffer();
        result.append("<data>");
        if (params != null) {
            for (Iterator iter = params.getOutputParams().iterator();
                 iter.hasNext();) {
                YParameter param = (YParameter) iter.next();
                result.append(presentParam(param));
            }
        }
        result.append("\n</data>");
        return result.toString();
    }


    public static String presentParam(YParameter param) {
        boolean typedParam = param.getDataTypeName() != null;
        StringBuffer result = new StringBuffer();
        result.append("\n  <!--");
        if(typedParam){
            result.append("Data Type:     " + param.getDataTypeName());
        }
        result.append("\n      Is Mandatory:  " + param.isMandatory());
        if (param.getDocumentation() != null) {
            result.append("\n      Documentation: " + param.getDocumentation());
        }
        result.append("-->\n  ");
        if(typedParam || param.isUntyped()){
            result.append("<" + param.getName() + "></" + param.getName() + ">");
        } else {
            result.append("<" + param.getElementName() + "></" + param.getElementName() + ">");
        }
        return result.toString();
    }


    public static TaskInformation unmarshalTaskInformation(String taskInfoAsXML) {
        YParametersSchema paramsForTaskNCase = new YParametersSchema();
        String taskID = null;
        String specificationID = null;
        String taskName = null;
        String taskDocumentation = null;
        String wsdlLocation = null;
        String operationName = null;
        try {
            Document doct = builder.build(new StringReader(taskInfoAsXML));
            Element taskInfo = doct.getRootElement();
            taskID = taskInfo.getChildText("taskID");
            specificationID = taskInfo.getChildText("specificationID");
            taskName = taskInfo.getChildText("taskName");
            taskDocumentation = taskInfo.getChildText("taskDocumentation");
            Element yawlService = taskInfo.getChild("yawlService");
            if (yawlService != null) {
                wsdlLocation = yawlService.getChildText("wsdlLocation");
                operationName = yawlService.getChildText("operationName");
            }
            Element params = taskInfo.getChild("params");
            List paramElementsList = params.getChildren();
            for (int i = 0; i < paramElementsList.size(); i++) {
                Element paramElem = (Element) paramElementsList.get(i);
                if ("formalInputParam".equals(paramElem.getName())) {
                    paramsForTaskNCase.setFormalInputParam(paramElem.getText());
                    continue;
                }
                boolean isInput = paramElem.getName().equals("inputParam");
                YParameter param = new YParameter(null, isInput);
                YDecompositionParser.parseParameter(
                        paramElem,
                        param,
                        null,
                        false);
                if (param.isInput()) {
                    paramsForTaskNCase.setInputParam(param);
                } else {
                    paramsForTaskNCase.setOutputParam(param);
                }
                String paramOrdering = paramElem.getChildText("ordering");
                int order = Integer.parseInt(paramOrdering);
                param.setOrdering(order);
            }
        } catch (JDOMException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        TaskInformation taskInfo = new TaskInformation(
                paramsForTaskNCase, taskID, specificationID, taskName, taskDocumentation);
        taskInfo.setWsdlLocation(wsdlLocation);
        taskInfo.setOperationName(operationName);
        return taskInfo;
    }


    /**
     * Creates a list of SpecificationDatas from formatted XML.
     * These are brief meta data summary
     * information objects that describe a worklfow specification.
     * @param specificationSummaryListXML
     * @return  the list
     */
    public static List unmarshalSpecificationSummary(String specificationSummaryListXML) {
        List specSummaryList = new ArrayList();
        Document doc = null;
        try {
            doc = builder.build(new StringReader(specificationSummaryListXML));
            List specSummaryElements = doc.getRootElement().getChildren();
            for (int i = 0; i < specSummaryElements.size(); i++) {
                SpecificationData specData = null;
                Element specElement = (Element) specSummaryElements.get(i);
                String specID = specElement.getChildText("id");
                String specName = specElement.getChildText("name");
                String specDodo = specElement.getChildText("documentation");
                String specStatus = specElement.getChildText("status");
                if (specID != null && specStatus != null) {
                    specData = new SpecificationData(
                            specID, specName, specDodo, specStatus);
                    specSummaryList.add(specData);
                    Element inputParams = specElement.getChild("params");
                    if (inputParams != null) {
                        List paramElements = inputParams.getChildren();
                        for (int j = 0; j < paramElements.size(); j++) {
                            Element paramElem = (Element) paramElements.get(j);
                            YParameter param = new YParameter(null, true);
                            YDecompositionParser.parseParameter(
                                paramElem,
                                param,
                                null,
                                true);
                            specData.addInputParam(param);
                        }
                    }
                }
            }
        } catch (JDOMException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return specSummaryList;
    }


    public static WorkItemRecord unmarshalWorkItem(String workItemXML) {
        WorkItemRecord workItem = null;
        Document doc = null;
        try {
            doc = builder.build(new StringReader(workItemXML));
            workItem = unmarshalWorkItem(doc.getRootElement());
        } catch (JDOMException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return workItem;
    }


    public static WorkItemRecord unmarshalWorkItem(Element workItemElement) {
        WorkItemRecord workItem = null;
        String status = workItemElement.getChildText("status");
        String caseID = workItemElement.getChildText("caseID");
        String taskID = workItemElement.getChildText("taskID");
        String specID = workItemElement.getChildText("specID");
        String enablementTime = workItemElement.getChildText("enablementTime");
        if (caseID != null && taskID != null && specID != null &&
                enablementTime != null && status != null) {
            workItem = new WorkItemRecord(
                    caseID, taskID, specID,
                    enablementTime, status);
            String firingTime = workItemElement.getChildText("firingTime");
            workItem.setFiringTime(firingTime);
            String startTime = workItemElement.getChildText("startTime");
            workItem.setStartTime(startTime);
            String user = workItemElement.getChildText("assignedTo");
            workItem.setAssignedTo(user);
            Element data = workItemElement.getChild("data");
            workItem.setDataList(data);
        }
        return workItem;
    }


    public static List unmarshalCaseIDs(String casesAsXML) {
        List cases = new ArrayList();
        try {
            StringReader reader = new StringReader(casesAsXML);
            Element casesElem = builder.build(reader).getRootElement();
            for (Iterator iterator = casesElem.getChildren().iterator(); iterator.hasNext();) {
                Element caseElem = (Element) iterator.next();
                String caseID = caseElem.getText();
                if (caseID != null) {
                    cases.add(caseID);
                }
            }
        } catch (JDOMException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return cases;
    }


    public static String getFinalOutputData(String inputData, String outputData) {
        SAXBuilder builder = new SAXBuilder();
        Document finalDoc = null;
        Document outputDataDoc = null;
        boolean exception = false;
        try {
            finalDoc = builder.build(new StringReader(inputData));
            outputDataDoc = builder.build(new StringReader(outputData));
            java.util.List children = outputDataDoc.getRootElement().getContent();
            for (int i = 0; i < children.size(); i++) {
                Object o = children.get(i);
                if (o instanceof Element) {
                    Element child = (Element) o;
                    child.detach();
                    finalDoc.getRootElement().removeChild(child.getName());
                    finalDoc.getRootElement().addContent(child);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            exception = true;
        }
        if (exception || finalDoc == null) {
            return null;
        }
        return new XMLOutputter().outputString(finalDoc.getRootElement()).trim();
    }
}
