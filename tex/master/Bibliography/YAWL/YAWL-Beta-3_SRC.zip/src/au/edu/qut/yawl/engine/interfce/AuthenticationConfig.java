package au.edu.qut.yawl.engine.interfce;



/**
 /**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 15/03/2004
 * Time: 12:11:08
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.qut.au/yawl.
 */
public class AuthenticationConfig {
    private static String userName;
    private String _password;
    private String _proxyHost;
    private String _proxyPort;


    private static AuthenticationConfig _myInstance;


    private AuthenticationConfig(){}


    public static boolean isSetForAuthentication(){
        return userName != null;
    }


    public static AuthenticationConfig getInstance(){
        if(_myInstance == null){
            _myInstance = new AuthenticationConfig();
        }
        return _myInstance;
    }


    public void setProxyAuthentication(String userName, String password,
                                       String proxyHost, String proxyPort) {
        this.userName = userName;
        this._password = password;
        this._proxyHost = proxyHost;
        this._proxyPort = proxyPort;
    }


    public String getPassword() {
        return _password;
    }


    public String getProxyHost() {
        return _proxyHost;
    }


    public String getUserName() {
        return userName;
    }


    public String getProxyPort() {
        return _proxyPort;
    }
}
