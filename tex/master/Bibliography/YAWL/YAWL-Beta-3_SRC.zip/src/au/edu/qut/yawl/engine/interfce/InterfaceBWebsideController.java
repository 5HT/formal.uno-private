package au.edu.qut.yawl.engine.interfce;

import au.edu.qut.yawl.worklist.model.Marshaller;
import au.edu.qut.yawl.worklist.model.TaskInformation;
import au.edu.qut.yawl.worklist.model.WorkItemRecord;
import au.edu.qut.yawl.worklist.model.WorklistModel;
import au.edu.qut.yawl.exceptions.YStateException;

import java.util.List;
import java.io.IOException;


/**
 *
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 19/03/2004
 * Time: 11:44:49
 * This file remains the property of the YAWL team at the Queensland University of
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public abstract class InterfaceBWebsideController {
    protected InterfaceB_EnvironmentBasedClient _interfaceBClient;
    protected WorklistModel _model;
    private AuthenticationConfig _authConfig4WS;


    public InterfaceBWebsideController(){
        _model = new WorklistModel();
        _authConfig4WS = AuthenticationConfig.getInstance();
    }


    public void setUpInterfaceBClient(String backEndURI){
        _interfaceBClient = new InterfaceB_EnvironmentBasedClient(backEndURI);
    }


    /**
     * By implementing this method and deploying a web app containing the implementation
     * the YAWL engine will send events to this method notifying your custom
     * YAWL service of an impending enabled work item.
     * @param workItemRecord a "snapshot" of the work item available in
     * the engine.
     */
    public abstract void handleEnabledWorkItemEvent(WorkItemRecord workItemRecord);


    /**
     * By implementing this method and deploying a web app containing the implementation
     * the YAWL engine will send events to this method notifying your custom
     * YAWL service that an active work item has been cancelled by the
     * engine.
     * @param workItemRecord a "snapshot" of the work item cancelled in
     * the engine.
     */
    public abstract void handleCancelledWorkItemEvent(WorkItemRecord workItemRecord);


    /**
     * If you are going outside of a firewall then you will need to
     * set this method once.  Doing so will allow the WSIF code to access
     * Web services outside your organisation's firewall (http authenticating
     * proxy).
     *
     * NOTE:  If your custom YAWL service doesn't need to negotiate a
     * a firewall merely provide an empty implementation of this method.
     *
     * @param userName mandatory
     * @param password mandatory
     * @param httpProxyHost optional (if using a non authenticating proxy firewall).
     * @param proxyPort optional (if using a non authenticating proxy firewall).
     */
    public void setRemoteAuthenticationDetails(String userName, String password,
                                         String httpProxyHost, String proxyPort)
    {
        _authConfig4WS.setProxyAuthentication(
                userName, password, httpProxyHost, proxyPort);
    }


    public boolean checkConnection(String sessionHandle) throws IOException {
        String msg = _interfaceBClient.checkConnection(sessionHandle);
        return _interfaceBClient.successful(msg);
    }


    public String connect(String userID, String password) throws IOException {
        return _interfaceBClient.connect(userID, password);
    }


    public String checkOut(String workItemID, String sessionHandle) throws IOException {
        String msg = _interfaceBClient.checkOutWorkItem(workItemID, sessionHandle);
        return msg;
    }


    public String checkInWorkItem(String workItemID, String inputData, String outputData, String sessionHandle) throws IOException {
        String finalOutputData = Marshaller.getFinalOutputData(inputData, outputData);
        return _interfaceBClient.checkInWorkItem(workItemID, finalOutputData, sessionHandle);
    }


    public TaskInformation getTaskInformation(String specificationID, String taskID, String sessionHandle) throws IOException {
        TaskInformation taskInfo = _model.getTaskInformation(specificationID, taskID);
        if (taskInfo == null) {
            String taskInfoASXML = _interfaceBClient.getTaskInformationStr(
                    specificationID, taskID, sessionHandle);
            taskInfo = _interfaceBClient.parseTaskInformation(taskInfoASXML);
            _model.setTaskInformation(specificationID, taskID, taskInfo);
        }
        return taskInfo;
    }


    public WorklistModel getModel() {
        return _model;
    }


    public List getChildren(String workItemID, String sessionHandle) {
        List childrenOfWorkItem =
                _interfaceBClient.getChildrenOfWorkItem(workItemID, sessionHandle);
        return childrenOfWorkItem;
    }


    public AuthenticationConfig getAuthenticationConfig() {
        return _authConfig4WS;
    }



    /**
     * logs the failure of client to contact the YAWL engine. gives some suggestion of why?
     * @param e
     * @param backEndURIStr
     */
    public static void logContactError(IOException e, String backEndURIStr) {
        System.out.println("[error] problem contacting YAWL engine at URI [" +
                backEndURIStr + "]");
        if(e.getStackTrace() != null){
            System.out.println("line of code := " + e.getStackTrace()[0].toString());
        }
    }


    /**
     * checks to see if the inupt string doesn't contain a <failure>..</failure> message.
     * @param input
     */
    public boolean successful(String input){
        return _interfaceBClient.successful(input);
    }



}
