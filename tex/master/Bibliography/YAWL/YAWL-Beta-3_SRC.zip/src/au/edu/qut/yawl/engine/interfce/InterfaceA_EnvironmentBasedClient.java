package au.edu.qut.yawl.engine.interfce;

import au.edu.qut.yawl.authentication.User;
import au.edu.qut.yawl.elements.YAWLServiceReference;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.output.XMLOutputter;
import org.jdom.output.Format;
import org.jdom.input.SAXBuilder;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

/**
 /**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 16/04/2004
 * Time: 16:15:02
 * This file remains the property of the YAWL team at the Queensland University of
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class InterfaceA_EnvironmentBasedClient extends Interface_Client {
    private String _backEndURIStr;
    private SAXBuilder _builder = new SAXBuilder();;


    /**
     * Constructor
     * @param backEndURIStr the back end uri of where to find
     * the engine.  A default deployment this value is
     * http://localhost:8080/yawl/ia
     */
    public InterfaceA_EnvironmentBasedClient(String backEndURIStr) {
        _backEndURIStr = backEndURIStr;
    }

    public String checkConnection(String sessionHandle) {
        try {
            return executeGet(_backEndURIStr + "?" +
                    "action=checkConnection" +
                    "&" +
                    "sessionHandle=" + sessionHandle);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * Returns a sessionhandle for use in all other engine access methods.  It is used for
     * to achieve "admin level" access.
     * @param userID a valid user ID
     * @param password a valid password
     * @return the sessionHandle - expires after one hour.
     */
    public String connect(String userID, String password) throws IOException {
        Map queryMap = new HashMap();
        queryMap.put("userid", userID);
        queryMap.put("password", password);
        return executePost(_backEndURIStr + "/connect", queryMap);
    }


    /**
     * Returns a list of YAWL service objects registered with
     * the engine.
     * @param sessionHandle the session handle - won't work without the correct one.
     * @return
     */
    public Set getRegisteredYAWLServices(String sessionHandle) {
        Set yawlServices = new HashSet();
        try {
            String result = executeGet(_backEndURIStr + "?" +
                    "action=getYAWLServices" +
                    "&" +
                    "sessionHandle=" + sessionHandle);
            SAXBuilder builder = new SAXBuilder();
            if (result != null && successful(result)) {
                Document doc = null;
                doc = builder.build(new StringReader(result));
                Iterator yawlServiceIter = doc.getRootElement().getChildren().iterator();
                XMLOutputter out = new XMLOutputter(Format.getCompactFormat());

                while (yawlServiceIter.hasNext()) {
                    Element yawlServiceElem = (Element) yawlServiceIter.next();
                    YAWLServiceReference service =
                            YAWLServiceReference.unmarshal(out.outputString(yawlServiceElem));
                    yawlServices.add(service);
                }
            }
        } catch (JDOMException e) {
            e.printStackTrace();
        } catch (IOException e) {
            InterfaceBWebsideController.logContactError(e, _backEndURIStr);
        }
        return yawlServices;
    }






    public String setYAWLService(YAWLServiceReference service, String sessionHandle) throws IOException {
        String serialisedYAWLService = service.toXML();
        Map queryMap = new HashMap();
        queryMap.put("sessionHandle", sessionHandle);
        queryMap.put("action", "newYAWLService");
        queryMap.put("service", serialisedYAWLService);
        return executePost(_backEndURIStr, queryMap);
    }



    /**
     * Uploads a specification into the engine.
     * @param specification this is not file name this is the entire specification
     * in string format.
     * @param sessionHandle
     * @return a result message indicting failure/success and some diagnostics
     */
    public String uploadSpecification(String specification, String sessionHandle) {
        return executeUpload(_backEndURIStr + "/uploader", specification, sessionHandle);
    }

    private String executeUpload(String urlStr, String specification, String sessionHandle) {
        StringBuffer result = new StringBuffer();
        try {
            URL url = new URL(urlStr);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("YAWLSessionHandle", sessionHandle);
            connection.setRequestProperty("Content-Type", "text/xml");

            //send query
            PrintWriter out = new PrintWriter(connection.getOutputStream());
            out.print(specification);
            out.flush();

            //retrieve reply
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                result.append(inputLine);
            }
            //clean up
            in.close();
            out.close();
            connection.disconnect();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            InterfaceBWebsideController.logContactError(e, _backEndURIStr);
        }
        String msg = result.toString();
        return stripOuterElement(msg);
    }

    public String unloadSpecification(String specID, String sessionHandle) throws IOException {
        Map params = new HashMap();
        params.put("action", "unload");
        params.put("sessionHandle", sessionHandle);
        return executePost(_backEndURIStr + "/specID/" + specID, params);
    }

    public String createUser(String userName, String password, boolean isAdmin, String sessionHandle) throws IOException {
        Map params = new HashMap();
        params.put("userName", userName);
        params.put("password", password);
        if (isAdmin) {
            params.put("action", "createAdmin");
        } else {
            params.put("action", "createUser");
        }
        params.put("sessionHandle", sessionHandle);
        return executePost(_backEndURIStr, params);
    }

    public List getUsers(String sessionHandle) {
        String result = null;
        try {
            result = executeGet(_backEndURIStr +
                    "?" +
                    "action=getUsers" +
                    "&" +
                    "sessionHandle=" + sessionHandle);
        } catch (IOException e) {
            InterfaceBWebsideController.logContactError(e, _backEndURIStr);
        }
        ArrayList users = new ArrayList();
        if (successful(result)) {
            try {
                Document doc = _builder.build(new StringReader(result));
                List userElems = doc.getRootElement().getChildren();
                for (int i = 0; i < userElems.size(); i++) {
                    Element element = (Element) userElems.get(i);
                    String id = element.getChildText("id");
                    String isAdmin = element.getChildText("isAdmin");
                    User u = new User(id, null);
                    if (isAdmin.equals("true")) {
                        u.setAdmin(true);
                    }
                    users.add(u);
                }
            } catch (JDOMException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return users;
    }
}
