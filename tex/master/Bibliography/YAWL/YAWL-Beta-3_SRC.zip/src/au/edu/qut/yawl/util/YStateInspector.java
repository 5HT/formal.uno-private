package au.edu.qut.yawl.util;

import au.edu.qut.yawl.elements.YConditionInterface;
import au.edu.qut.yawl.elements.YCondition;
import au.edu.qut.yawl.elements.YTask;
import au.edu.qut.yawl.elements.YNetElement;
import au.edu.qut.yawl.elements.state.YIdentifier;
import au.edu.qut.yawl.elements.state.YInternalCondition;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 22/10/2003
 * Time: 15:25:41
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YStateInspector {

    public static String inspectState(YIdentifier parentID){
            //###########################################################################
            //##########            BEGIN State inspection code             #############
            //###########################################################################
            Set allChildren = parentID.getDescendants();
            Set allLocations = new HashSet();
            for (Iterator childIter = allChildren.iterator(); childIter.hasNext();) {
                YIdentifier identifier = (YIdentifier) childIter.next();
                allLocations.addAll(identifier.getLocations());
            }
            StringBuffer stateText = new StringBuffer();
            for (Iterator locationsIter = allLocations.iterator(); locationsIter.hasNext();) {
                YNetElement element = (YNetElement) locationsIter.next();
                if (element instanceof YCondition) {
                    stateText.append("CaseIDs in: " + element.toString() + "\r\n");
                    List identifiers = ((YConditionInterface) element).getIdentifiers();
                    for (Iterator idIter = identifiers.iterator(); idIter.hasNext();) {
                        YIdentifier identifier = (YIdentifier) idIter.next();
                        stateText.append("\t" + identifier.toString() + "\r\n");
                    }
                } else if (element instanceof YTask) {
                    stateText.append("CaseIDs in: " + element.toString() + "\r\n");
                    YTask task = (YTask) element;
                    for (int i = 0; i < 4; i++) {
                        YInternalCondition internalCondition = null;
                        if (i == 0) {
                            internalCondition = task.getMIActive();
                        }
                        if (i == 1) {
                            internalCondition = task.getMIEntered();
                        }
                        if (i == 2) {
                            internalCondition = task.getMIExecuting();
                        }
                        if (i == 3) {
                            internalCondition = task.getMIComplete();
                        }
                        if (internalCondition.containsIdentifier()) {
                            stateText.append("\t" + internalCondition.toString() + "\r\n");
                            List identifiers = internalCondition.getIdentifiers();
                            for (Iterator iterator = identifiers.iterator(); iterator.hasNext();) {
                                YIdentifier identifier = (YIdentifier) iterator.next();
                                stateText.append("\t\t" + identifier.toString() + "\r\n");
                            }
                        }
                    }

                }
            }
            return stateText.toString();
            //###########################################################################
            //#######                  END state inspection code               ##########
            //###########################################################################
    }
}
