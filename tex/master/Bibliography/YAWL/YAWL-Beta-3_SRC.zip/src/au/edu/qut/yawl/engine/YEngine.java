package au.edu.qut.yawl.engine;

import au.edu.qut.yawl.elements.*;
import au.edu.qut.yawl.elements.data.YParameter;
import au.edu.qut.yawl.elements.state.YIdentifier;
import au.edu.qut.yawl.elements.state.YInternalCondition;
import au.edu.qut.yawl.engine.gui.YEngineGUI;
import au.edu.qut.yawl.engine.interfce.InterfaceB_EngineBasedClient;
import au.edu.qut.yawl.exceptions.*;
import au.edu.qut.yawl.logging.YawlLogServletInterface;
import au.edu.qut.yawl.unmarshal.YMarshal;
import au.edu.qut.yawl.util.YDocumentCleaner;
import au.edu.qut.yawl.util.YMessagePrinter;
import au.edu.qut.yawl.util.YVerificationMessage;
import au.edu.qut.yawl.authentication.UserList;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.*;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 17/06/2003
 * Time: 13:46:54
 * This file remains the property of the YAWL team at the Queensland University of
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YEngine {
    private Map _specifications = new HashMap();
    protected Map _caseIDToNetRunnerMap = new HashMap();
    private Map _runningCaseIDToSpecIDMap = new HashMap();
    private YWorkItemRepository _workItemRepository = YWorkItemRepository.getInstance();
    private static YEngine _myInstance;
    private YEngineGUI _gui;
    private Map _yawlServices = new HashMap();
    private static boolean _networked = false;
    private static YawlLogServletInterface yawllog = null;
    private List _problemHandlers = new ArrayList();
    private static UserList _userList;

    private YEngine() {
        yawllog = YawlLogServletInterface.getInstance();
    }


    public static YEngine getInstance(boolean networked) {
        if (_myInstance == null) {
            _myInstance = new YEngine();
            YAWLServiceReference ys = new YAWLServiceReference("http://localhost:8080/yawlWSInvoker/", null);
            ys.setDocumentation("This YAWL Service enables suitably decalred" +
                    " workflow tasks to invoke RPC style service on the Web.");
            _myInstance.addYawlService(ys);
            _userList = UserList.getInstance();
/*
            if(networked) {
                _networked = networked;
                try {
                    EngineGatewayImpl gateway = new EngineGatewayImpl();
                    gateway.registerRMI();
                } catch (Exception e) {
                    e.printStackTrace();
                    System.exit(1);
                }
            }
*/
        }
        return _myInstance;
    }


    //###################################################################################
    //                                MUTATORS
    //###################################################################################
    /**
     * Adds the specification contained in the parameter file to the engine
     * @param specificationFile
     * @param ignoreErors ignore verfication errors and load the spec anyway.
     * @param errorMessages - an in/out param passing any error messages.
     * @return the specification ids of the sucessfully loaded specs
     */
    public List addSpecifications(File specificationFile, boolean ignoreErors, List errorMessages) throws JDOMException, IOException {
        List returnIDs = new Vector();
        List newSpecifications = null;
        String parsingMsg = null;
        try {
            //if there is an XML Schema problem report it and abort
            newSpecifications = YMarshal.unmarshalSpecifications(specificationFile.getAbsolutePath());
        } catch (YSyntaxException e) {

            parsingMsg = e.getMessage();
            //catch the xml parsers exception,
            //transform it into YAWL format and abort the load
            for (StringTokenizer tokens = new StringTokenizer(parsingMsg, "\n"); tokens.hasMoreTokens();) {
                String msg = tokens.nextToken();
                errorMessages.add(new YVerificationMessage(
                        null, msg, YVerificationMessage._errorStatus));
            }
            return returnIDs;
        } catch (YSchemaBuildingException e) {
            e.printStackTrace();
        }
        for (Iterator iterator = newSpecifications.iterator(); iterator.hasNext();) {
            YSpecification specification = (YSpecification) iterator.next();
            List messages = specification.verify();
            if (messages.size() > 0 && !ignoreErors) {
                YMessagePrinter.printMessages(messages);
                errorMessages.addAll(messages);
            }
            //if the error messages are empty or contain only warnings
            if (YVerificationMessage.containsNoErrors(errorMessages)) {
                boolean success = loadSpecification(specification);
                if (success) {
                    returnIDs.add(specification.getID());
                } else {//the user has loaded the specification with identical id
                    errorMessages.add(new YVerificationMessage(this,
                            "There is a specification with an identical id to ["
                            + specification.getID() + "] already loaded into the engine.",
                            YVerificationMessage._errorStatus));
                }
            }
        }
        return returnIDs;
    }


    public boolean loadSpecification(YSpecification spec) {
        if (!_specifications.containsKey(spec.getID())) {
            _specifications.put(spec.getID(), spec);
            return true;
        }
        return false;
    }


    public YIdentifier startCase(String specID) throws YStateException {
        YSpecification specification = (YSpecification) _specifications.get(specID);
        if (specification != null) {
            YNetRunner runner = new YNetRunner(specification.getRootNet(), this);
            // LOG CASE EVENT
            yawllog.logCaseCreated(runner.getCaseID().toString(), "SYSTEM", specID);
            runner.start();
            _caseIDToNetRunnerMap.put(runner.getCaseID(), runner);
            _runningCaseIDToSpecIDMap.put(runner.getCaseID(), specID);
            if (_gui != null) {
                _gui.addCase(specID, runner.getCaseID().toString());
            }
            return runner.getCaseID();
        } else {
            throw new YStateException("No specification found with ID ["
            + specID + "]");
        }
    }


    public void finishCase(YIdentifier caseIDForNet) {
        _caseIDToNetRunnerMap.remove(caseIDForNet);
        _runningCaseIDToSpecIDMap.remove(caseIDForNet);
        //  LOG CASE EVENT
        yawllog.logCaseCompleted(caseIDForNet.toString());
        if (_gui != null) {
            _gui.removeActiveCase(caseIDForNet.toString());
        }
    }


    public void unloadSpecification(String specID) throws YStateException{
        if (_specifications.containsKey(specID)) {
            _specifications.remove(specID);
        } else {
            throw new YStateException(
                    "Engine contains no such specification with id [" +
                    specID + "].");
        }
    }


    /**
     * Cancels the case.
     * @param id the case ID.
     */
    public void cancelCase(YIdentifier id){
        if(id == null){
            throw new IllegalArgumentException("should not cancel case with a null id");
        }
        YNetRunner runner = (YNetRunner) _caseIDToNetRunnerMap.get(id);
        _runningCaseIDToSpecIDMap.remove(id);
        _workItemRepository.removeWorkItemsForCase(id);

        // LOG CASE EVENT
        yawllog.logCaseCancelled(id.toString());
        runner.cancel();
        finishCase(id);
    }


    //####################################################################################
    //                          ACCESSORS
    //####################################################################################
    /**
     * Provides the set of specification ids for specs loaded into the engine.
     * @return a set of spec id strings.
     */
    public Set getSpecIDs() {
        return _specifications.keySet();
    }


    public YSpecification getSpecification(String specID) {
        return (YSpecification) _specifications.get(specID);
    }


    public YIdentifier getCaseID(String caseIDStr) {
        Set idSet = _caseIDToNetRunnerMap.keySet();
        for (Iterator idSetIter = idSet.iterator(); idSetIter.hasNext();) {
            YIdentifier identifier = (YIdentifier) idSetIter.next();
            if (identifier.toString().equals(caseIDStr)) {
                return identifier;
            }
        }
        return null;
    }


    public String getStateTextForCase(YIdentifier caseID) {
        Set allChildren = caseID.getDescendants();
        Set allLocations = new HashSet();
        for (Iterator childIter = allChildren.iterator(); childIter.hasNext();) {
            YIdentifier identifier = (YIdentifier) childIter.next();
            allLocations.addAll(identifier.getLocations());
        }
        StringBuffer stateText = new StringBuffer();
        stateText.append(
                "#############################################################\r\n" +
                "CaseID: " + caseID + "\r\n" +
                "Spec:   " + _runningCaseIDToSpecIDMap.get(caseID) + "\r\n" +
                "#############################################################\r\n");
        for (Iterator locationsIter = allLocations.iterator(); locationsIter.hasNext();) {
            YNetElement element = (YNetElement) locationsIter.next();
            if (element instanceof YCondition) {
                stateText.append("CaseIDs in: " + element.toString() + "\r\n");
                List identifiers = ((YConditionInterface) element).getIdentifiers();
stateText.append("\thashcode "+element.hashCode()+"\r\n");
                for (Iterator idIter = identifiers.iterator(); idIter.hasNext();) {
                    YIdentifier identifier = (YIdentifier) idIter.next();
                    stateText.append("\t" + identifier.toString() + "\r\n");
                }
            } else if (element instanceof YTask) {
                stateText.append("CaseIDs in: " + element.toString() + "\r\n");
                YTask task = (YTask) element;
                for (int i = 0; i < 4; i++) {
                    YInternalCondition internalCondition = null;
                    if (i == 0) {
                        internalCondition = task.getMIActive();
                    }
                    if (i == 1) {
                        internalCondition = task.getMIEntered();
                    }
                    if (i == 2) {
                        internalCondition = task.getMIExecuting();
                    }
                    if (i == 3) {
                        internalCondition = task.getMIComplete();
                    }
                    if (internalCondition.containsIdentifier()) {
                        stateText.append("\t" + internalCondition.toString() + "\r\n");
                        List identifiers = internalCondition.getIdentifiers();
                        for (Iterator iterator = identifiers.iterator(); iterator.hasNext();) {
                            YIdentifier identifier = (YIdentifier) iterator.next();
                            stateText.append("\t\t" + identifier.toString() + "\r\n");
                        }
                    }
                }
            }
        }
        return stateText.toString();
    }


    public String getStateForCase(YIdentifier caseID) {
        Set allChildren = caseID.getDescendants();
        Set allLocations = new HashSet();
        for (Iterator childIter = allChildren.iterator(); childIter.hasNext();) {
            YIdentifier identifier = (YIdentifier) childIter.next();
            allLocations.addAll(identifier.getLocations());
        }
        StringBuffer stateText = new StringBuffer();
        stateText.append("<caseState " +
                "caseID=\"" + caseID + "\" " +
                "specID=\"" + _runningCaseIDToSpecIDMap.get(caseID) + "\">");
        for (Iterator locationsIter = allLocations.iterator(); locationsIter.hasNext();) {
            YNetElement element = (YNetElement) locationsIter.next();
            if (element instanceof YCondition) {
                stateText.append("<condition " +
                        "id=\"" + element.toString() + "\" " +
                        "name=\"" + ((YCondition) element).getName() + "\">");
                List identifiers = ((YConditionInterface) element).getIdentifiers();
                for (Iterator idIter = identifiers.iterator(); idIter.hasNext();) {
                    YIdentifier identifier = (YIdentifier) idIter.next();
                    stateText.append("<identifier>" + identifier.toString() + "</identifier>");
                }
                stateText.append("</condition>");
            } else if (element instanceof YTask) {
                stateText.append("<task " +
                        "id=\"" + element.toString() + "\" " +
                        "name=\"" + ((YTask) element).getDecompositionPrototype()
                        .getID() + "\">");
                YTask task = (YTask) element;
                for (int i = 0; i < 4; i++) {
                    YInternalCondition internalCondition = null;
                    if (i == 0) {
                        internalCondition = task.getMIActive();
                    }
                    if (i == 1) {
                        internalCondition = task.getMIEntered();
                    }
                    if (i == 2) {
                        internalCondition = task.getMIExecuting();
                    }
                    if (i == 3) {
                        internalCondition = task.getMIComplete();
                    }
                    if (internalCondition.containsIdentifier()) {
                        stateText.append("<internalCondition " +
                                "id=\"" + internalCondition.toString() + "\">");
                        List identifiers = internalCondition.getIdentifiers();
                        for (Iterator iterator = identifiers.iterator(); iterator.hasNext();) {
                            YIdentifier identifier = (YIdentifier) iterator.next();
                            stateText.append("<identifier>" + identifier.toString() + "</identifier>");
                        }
                        stateText.append("</internalCondition>");
                    }
                }
                stateText.append("</task>");
            }
        }
        stateText.append("</caseState>");
        return stateText.toString();
    }


    public void setGUI(YEngineGUI gui) {
        _gui = gui;
    }


    //################################################################################
    //   BEGIN REST-FUL SERVICE METHODS
    //################################################################################
    public Set getAvailableWorkItems() {
        Set allItems = new HashSet();
        allItems.addAll(_workItemRepository.getEnabledWorkItems());
        allItems.addAll(_workItemRepository.getFiredWorkItems());
        return allItems;
    }


    public YSpecification getProcessDefinition(String specID) {
        return (YSpecification) _specifications.get(specID);
    }


    public YWorkItem getWorkItem(String workItemID) {
        YWorkItem workItem = _workItemRepository.getWorkItem(workItemID);
        if (workItem != null) {
            return workItem;
        } else
            return null;
    }


    public Set getAllWorkItems() {
        Set workItems = _workItemRepository.getWorkItems();
        return workItems;
    }


    /**
     * Starts a work item.  If the workitem param is enabled this method fires the task
     * and returns the first of its child instances in the exectuting state.
     * Else if the workitem is fired then it moves the state from fired to exectuing.
     * Either way the method returns the resultant work item.
     * @param workItem the enabled, or fired workitem.
     * @param userID the user id.
     * @return the resultant work item in the executing state.
     * @throws YStateException if the workitem is not in either of these
     * states.
     * @throws YDataStateException
     */
    public YWorkItem startWorkItem(YWorkItem workItem, String userID) throws YStateException, YDataStateException {
        YNetRunner netRunner;
        YWorkItem resultantItem = null;
        if (workItem != null) {
            if (workItem.getStatus() == YWorkItem.statusEnabled) {
                netRunner = _workItemRepository.getNetRunner(workItem.getCaseID());
                List childCaseIDs = null;
                childCaseIDs = netRunner.attemptToFireAtomicTask(workItem.getTaskID());
if(workItem.getTaskID().equals("C")){
 System.out.println("childCaseIDs = " + childCaseIDs);
}
                if (childCaseIDs != null) {
                    for (int i = 0; i < childCaseIDs.size(); i++) {
                        YIdentifier childID = (YIdentifier) childCaseIDs.get(i);
                        YWorkItem nextWorkItem = workItem.createChild(childID);
                        if (i == 0) {
                            netRunner.startWorkItemInTask(nextWorkItem.getCaseID(), workItem.getTaskID());
                            nextWorkItem.setStatusToStarted(userID);
                            Element dataList = ((YTask)
                                    netRunner.getNetElement(workItem.getTaskID())).getData(childID);
                            nextWorkItem.setData(dataList);
                            resultantItem = nextWorkItem;
                        }
                    }
                }
            } else if (workItem.getStatus() == YWorkItem.statusFired) {
                workItem.setStatusToStarted(userID);
                netRunner = _workItemRepository.getNetRunner(workItem.getCaseID().getFather());
                Element dataList = ((YTask) netRunner.getNetElement(workItem.getTaskID())
                        ).getData(workItem.getCaseID());
                workItem.setData(dataList);
                netRunner.startWorkItemInTask(workItem.getCaseID(), workItem.getTaskID());
                resultantItem = workItem;
            } else if (workItem.getStatus() == YWorkItem.statusDeadlocked) {
                resultantItem = workItem;
            } else {
                throw new YStateException(
                        "Item status (" + workItem.getStatus() +
                        ") does not permit starting.");
                //this work item is likely already executing.
            }
        } else {
            throw new YStateException(
                    "No such work item currently available.");
        }
        return resultantItem;
    }


    /**
     * Returns the task definition, not the task instance.
     * @param specificationID the specification id
     * @param taskID the task id
     * @return the task definition object.
     */
    public YTask getTaskDefinition(String specificationID, String taskID) {
        YSpecification specification = (YSpecification) _specifications.get(specificationID);
        if (specification != null) {
            Set decompositions = specification.getDecompositions();
            for (Iterator iterator2 = decompositions.iterator(); iterator2.hasNext();) {
                YDecomposition decomposition = (YDecomposition) iterator2.next();
                if (decomposition instanceof YNet) {
                    if (((YNet) decomposition).getNetElements().containsKey(taskID)) {
                        YExternalNetElement el = ((YNet) decomposition).getNetElement(taskID);
                        if (el instanceof YTask) {
                            return (YTask) ((YNet) decomposition).getNetElement(taskID);
                        }
                    }
                }
            }
        }
        return null;
    }



    /**
     * Completes the work item.
     * @param workItem
     * @param data
     * @throws YStateException
     */
    public void completeWorkItem(YWorkItem workItem, String data) throws YStateException {
        if (workItem != null) {
            if (workItem.getStatus() == YWorkItem.statusExecuting) {
                YNetRunner netRunner = _workItemRepository.getNetRunner(workItem.getCaseID().getFather());
                synchronized (netRunner) {
                    SAXBuilder builder = new SAXBuilder();
                    //doing this because saxon can't do an effective query when the whitespace is there
                    try {
                        Document d = builder.build(new StringReader(data));
                        Document e = YDocumentCleaner.cleanDocument(d);
                        boolean taskExited = netRunner.completeWorkItemInTask(
                                workItem.getCaseID(), workItem.getTaskID(), e);
                        if (taskExited) {
                            _workItemRepository.removeWorkItemFamily(workItem);
                            /* Calling this to fix a problem.
                             * When a Task is enabled twice by virtue of having two enabling sets of
                             * tokens in the current marking the work items are not created twice.
                             * Instead an Enabled work item is created for one of the enabling sets.
                             * Once that task has well and truly finished it is then an appropriate
                             * time to notify the worklists that it is enabled again.
                             * This is done by calling continueIfPossible().*/
                            netRunner.continueIfPossible();
                        }
                    } catch (Exception e) {
                        YStateException f =  new YStateException(
                                "Engine threw Exception: " + e.getMessage() );
                        f.setStackTrace(e.getStackTrace());
                        throw f;
                    }
                }
                workItem.setStatusToComplete();
            } else if (workItem.getStatus() == YWorkItem.statusDeadlocked) {
                _workItemRepository.removeWorkItemFamily(workItem);
            } else {
                throw new YStateException(
                        "WorkItem with ID [" + workItem.getIDString() +
                        "] not in executing state.");
            }
        } else {
            throw new YStateException(
                    "WorkItem argument is equal to null.");
        }
    }


    /**
     * Determines whether or not a task will aloow a dynamically
     * created new instance to be created.  MultiInstance Task with
     * dyanmic instance creation.
     * @param workItemID the workItemID of a sibling work item.
     * @throws YStateException if task is not MultiInstance, or
     * if task does not allow dynamic instance creation,
     * or if current number of instances is not less than the maxInstances
     * for the task.
     */
    public void checkElegibilityToAddInstances(String workItemID) throws YStateException {
        YWorkItem item = _workItemRepository.getWorkItem(workItemID);
        if (item != null) {
            if (item.getStatus() == YWorkItem.statusExecuting) {
                if (item.allowsDynamicCreation()) {
                    YIdentifier identifier = item.getCaseID().getFather();
                    YNetRunner netRunner =
                            _workItemRepository.getNetRunner(identifier);
                    boolean addEnabled =
                            netRunner.isAddEnabled(item.getTaskID(), item.getCaseID());
                    if (addEnabled) {
                        //do nothing
                    } else {
                        throw new YStateException("Adding instances is not possible in " +
                                "current state.");
                    }
                } else {
                    throw new YStateException("WorkItem[" + workItemID +
                            "] does not allow new instance creation.");
                }
            } else {
                throw new YStateException("WorkItem[" + workItemID +
                        "] is not in appropriate (executing) " +
                        "state for instance adding.");
            }
        } else {
            throw new YStateException("No work Item Found with id : " +
                    workItemID);
        }
    }


    /**
     * Creates a new work item instance when possible.
     * @param workItem the id of a work item inside the task to have a new instance.
     * @param paramValueForMICreation format "<data>[InputParam]*</data>
     * InputParam == <varName>varValue</varName>
     * @return the work item of the new instance.
     * @throws YStateException if the task is not able to create a new instance, due to
     * its state or its design.
     */
    public YWorkItem createNewInstance(YWorkItem workItem, String paramValueForMICreation) throws YStateException {
        if (workItem == null) {
            throw new YStateException("No work item found.");
        }
        String taskID = workItem.getTaskID();
        YIdentifier siblingID = workItem.getCaseID();
        YNetRunner netRunner = _workItemRepository.getNetRunner(siblingID.getFather());
        synchronized (netRunner) {
            checkElegibilityToAddInstances(workItem.getIDString());
            //calling it again to double check while we hold the semaphore to the netRunner
            SAXBuilder builder = new SAXBuilder();
            //doing this because stupid saxon can't do an effective query when the whitespace is there
            try {
                Document d = null;
                d = builder.build(new StringReader(paramValueForMICreation));
                Document e = YDocumentCleaner.cleanDocument(d);
                Element el = e.detachRootElement();
                YIdentifier id = netRunner.addNewInstance(taskID, workItem.getCaseID(), el);
                if (id != null) {
                    YWorkItem firedItem = workItem.getParent().createChild(id);
                    return firedItem;
                    //success!!!!
                }
                else {
                    throw new YStateException("New work item not created.");
                }
            } catch (Exception e) {
                throw new YStateException(e.getMessage());
            }
        }
    }


    public void suspendWorkItem(String workItemID, String userName) throws YStateException {
        YWorkItem workItem = _workItemRepository.getWorkItem(workItemID);
        if (workItem != null) {
            if (workItem.getStatus() == YWorkItem.statusExecuting) {
                workItem.rollBackStatus();
                YNetRunner netRunner = _workItemRepository.getNetRunner(workItem.getCaseID().getFather());
                if (netRunner.suspendWorkItem(
                        workItem.getCaseID(), workItem.getTaskID())) {
                } else {
                    throw new YStateException("Work Item[" + workItemID +
                            "] is not in executing state.");
                }
            }
        } else{
            throw new YStateException("Work Item[" + workItemID + "] not found.");
        }
    }


    public String launchCase(String specID, String caseParams) throws YStateException {
        YIdentifier caseID = startCase(specID, caseParams);
        if (caseID != null) {
            return caseID.toString();
        }
        throw new YStateException("No specification found for [" + specID + "].");
    }


    private YIdentifier startCase(String specID, String caseParams) throws YStateException {
        if (caseParams == null || caseParams.equals("")) {
            return startCase(specID);
        }
        SAXBuilder builder = new SAXBuilder();
        Document d = null;
        try {
            d = builder.build(new StringReader(caseParams));
            Document e = YDocumentCleaner.cleanDocument(d);
            YSpecification specification = (YSpecification) _specifications.get(specID);
            if (specification != null) {
                YNetRunner runner = new YNetRunner(
                        specification.getRootNet(),
                        this,
                        e.getRootElement());
                // LOG CASE EVENT
                yawllog.logCaseCreated(runner.getCaseID().toString(), "SYSTEM", specID);
                runner.start();
                _caseIDToNetRunnerMap.put(runner.getCaseID(), runner);
                _runningCaseIDToSpecIDMap.put(runner.getCaseID(), specID);
                if (_gui != null) {
                    _gui.addCase(specID, runner.getCaseID().toString());
                }
                return runner.getCaseID();
            }
        } catch (JDOMException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
            throw new YStateException("No specification found with ID ["
            + specID + "]");
    }


    /**
     * Given a process specification id return the cases that are its running
     * instances.
     * @param specID the process specification id string.
     * @return a set of YIdentifer caseIDs that are run time instances of the
     * process specification with id = specID
     */
    public Set getCasesForSpecification(String specID) {
        Set resultSet = new HashSet();
        if (_specifications.containsKey(specID)) {
            Set caseIDs = _runningCaseIDToSpecIDMap.keySet();
            for (Iterator iterator = caseIDs.iterator(); iterator.hasNext();) {
                YIdentifier caseID = (YIdentifier) iterator.next();
                String specIDForCaseID = (String) _runningCaseIDToSpecIDMap.get(caseID);
                if (specIDForCaseID.equals(specID)) {
                    resultSet.add(caseID);
                }
            }
         }
         return resultSet;
    }


    public YAWLServiceReference getRegisteredYawlService(String yawlServiceID) {
        return (YAWLServiceReference) _yawlServices.get(yawlServiceID);
    }


    /**
     * Returns a set of YAWL services registered in the engine.
     * @return
     */
    public Set getYAWLServices() {
        return new HashSet(_yawlServices.values());
    }


    /**
     * Adds a YAWL service to the engine.
     * @param yawlService
     */
    public void addYawlService(YAWLServiceReference yawlService) {
        _yawlServices.put(yawlService.getURI(), yawlService);
    }


    public Set getChildrenOfWorkItem(YWorkItem workItem) {
        Set childItems = _workItemRepository.getChildrenOf(workItem.getIDString());
        return childItems;
    }


    /**
     * Announces an enabled task to a YAWL service.  This is a classic push style
     * interaction where the Engine pushes the work item out into the
     * YAWL service.
     * PRE: the YAWL service exists and is on line.
     * @param yawlService the YAWL service
     * @param item the work item must be enabled.
     */
    protected void announceEnabledTask(YAWLServiceReference yawlService, YWorkItem item) {
        InterfaceB_EngineBasedClient.announceWorkItem(yawlService, item);
    }



    public void announceCancellationToEnvironment(YAWLServiceReference yawlService, YWorkItem item) {
        InterfaceB_EngineBasedClient.cancelAllInstancesUnder(yawlService, item);
    }


    /**
     * A programming "handle" for
     * compensating for data state problems that occured during firing or
     * executing a task or case.
     * @param e the problem event
     */
    public void logProblem(YProblemEvent e) {
        for (Iterator iterator = _problemHandlers.iterator(); iterator.hasNext();) {
            YProblemHandler handler = (YProblemHandler) iterator.next();
            handler.handleProblem(e);
        }
    }

    /**
     * The problem handler to add.
     * @param handler the handler.
     */
    public void addProblemHandler(YProblemHandler handler){
        _problemHandlers.add(handler);
    }


    /**
     * Connects the user to the engine, and returns a sessionhandle back to the user.
     * This session lasts for one hour at time of writing.
     * @param userID the userid
     * @param password the password
     * @return the session handle
     * @throws YAuthenticationException if the password is not valid.
     */
    public String connect(String userID, String password) throws YAuthenticationException {
        return _userList.connect(userID, password);
    }

    public Set getUsers(){
        return _userList.getUsers();
    }


}
