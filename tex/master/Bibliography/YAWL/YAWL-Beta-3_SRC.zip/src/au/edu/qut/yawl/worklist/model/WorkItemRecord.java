package au.edu.qut.yawl.worklist.model;

import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 2/02/2004
 * Time: 18:30:18
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class WorkItemRecord {
    public static final String statusEnabled = "Enabled";
    public static final String statusFired = "Fired";
    public static final String statusExecuting = "Executing";
    public static final String statusComplete = "Complete";
    public static final String statusIsParent = "Is parent";
    public static final String statusDeadlocked = "Deadlocked";

    private String _taskID;
    private String _caseID;
    private String _enablementTime;
    private String _firingTime;
    private String _startTime;
    private String _status;
    private String _whoStartedMe;
    private Element _dataList;
    private String _specificationID;


    public WorkItemRecord(String caseID, String taskID, String specificationID,
                          String enablementTime, String status) {
        this._taskID = taskID;
        this._caseID = caseID;
        this._specificationID = specificationID;
        this._enablementTime = enablementTime;
        this._status = status;
    }

    public void setFiringTime(String firingTime) {
        this._firingTime = firingTime;
    }

    public void setStartTime(String startTime) {
        this._startTime = startTime;
    }

    public void setAssignedTo(String whoStartedMe) {
        this._whoStartedMe = whoStartedMe;
    }

    public void setDataList(Element dataList) {
        this._dataList = dataList;
    }

    public String getTaskID() {
        return _taskID;
    }

    public String getCaseID() {
        return _caseID;
    }

    public String getEnablementTime() {
        return _enablementTime;
    }

    public String getFiringTime() {
        return _firingTime;
    }

    public String getStartTime() {
        return _startTime;
    }

    public String getStatus() {
        return _status;
    }

    public String getWhoStartedMe() {
        return _whoStartedMe;
    }


    public Element getDataList() {
        return _dataList;
    }


    public String getDataListString() {
        XMLOutputter out = new XMLOutputter(Format.getPrettyFormat());
        return out.outputString(_dataList);
    }


    public String getOutputDataString() {
        return "stubbed data";
    }


    public String getSpecificationID() {
        return _specificationID;
    }

    public String getID() {
        return _caseID + ":" +  _taskID;
    }
}
