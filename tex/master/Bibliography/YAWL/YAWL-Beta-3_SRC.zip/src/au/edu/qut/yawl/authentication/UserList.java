package au.edu.qut.yawl.authentication;

import au.edu.qut.yawl.exceptions.YAuthenticationException;
import au.edu.qut.yawl.exceptions.YStateException;

import java.util.*;


/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 27/01/2004
 * Time: 17:23:05
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class UserList {
    private Map _users;
    private Map _connections;
    private Random _random;
    private static UserList _myInstance;

    public static String _permissionGranted = "Permission Granted";


    public static UserList getInstance(){
        if(_myInstance == null){
            _myInstance = new UserList();
            try {
                _myInstance.addUser("admin", "YAWL", false);
            } catch (YAuthenticationException e) {
                e.printStackTrace();
            }
            _myInstance.setIsAdmin("admin", true);
        }
        return _myInstance;
    }

    private void setIsAdmin(String userName, boolean isAdmin) {
        User user = (User) _users.get(userName);
        if(user != null){
            user.setAdmin(isAdmin);
        }
    }


    private UserList() {
        this._users = new HashMap();
        this._connections = new HashMap();
        this._random = new Random();
    }


    public String checkConnection(String sessionHandle) throws YAuthenticationException{
        Connection connection = (Connection) _connections.get(sessionHandle);
        Date now = new Date();
        if(connection == null){
            throw new YAuthenticationException(
                    "There is no registered connection for " + sessionHandle);
        }
        else if(now.after(connection._timeOut)){
            throw new YAuthenticationException(
                    "Connection for session (" + sessionHandle +
                    ") has timed out");
        }
        return _permissionGranted;
    }


    /**
     * Checks the connection for administraive priviledges.
     * @param sessionHandle the user sessionhandle
     * @throws YAuthenticationException if the connection is not allowed.
     */
    public String checkConnectionForAdmin(String sessionHandle) throws YAuthenticationException {
        checkConnection(sessionHandle);
        Connection connection = (Connection) _connections.get(sessionHandle);
        User user = (User) _users.get(connection._userid);
        if (!user.isAdmin()) {
            throw new YAuthenticationException(
                    "This user is not an administrator.");
        }
        return _permissionGranted;
    }


    public void addUser(String userID, String password, boolean isAdmin) throws YAuthenticationException {
        if(userID != null){
            if(password != null && password.length() > 3){
                if(! _users.containsKey(userID)){
                    User user = new User(userID, password);
                    _users.put(userID, user);
                    if(isAdmin){
                        user.setAdmin(isAdmin);
                    }
                } else {
                    throw new YAuthenticationException(
                        "The userID[" + userID + "] is being used already.");
                }
            } else {
                throw new YAuthenticationException("Password must be at least 4 chars.");
            }
        } else {
            throw new YAuthenticationException("UserID cannot be null.");
        }
    }


    public void removeUser(String userID){
        List connections = new ArrayList(_connections.values());
        for (int i = 0; i < connections.size(); i++) {
            Connection connection = (Connection) connections.get(i);
            if(connection._userid.equals(userID)){
                _connections.remove(connection._sessionHandle);
                return;
            }
        }
        _users.remove(userID);
    }


    public String connect(String userID, String password) throws YAuthenticationException{
        User user = (User) _users.get(userID);
        if(user != null){
            if(user._password.equals(password)){
                Connection connection = new Connection(userID);
                _connections.put(connection._sessionHandle, connection);
                return connection._sessionHandle;
            }
            throw new YAuthenticationException("Password (" + password + ") not valid.");
        }
        throw new YAuthenticationException("Userid (" + userID + ") not valid.");
    }


    public String getUserID(String sessionHandle) {
        Connection connection = (Connection) _connections.get(sessionHandle);
        return connection != null ? connection._userid : null;
    }


    public Set getUsers() {
        Set result = new HashSet();
        for (Iterator iterator = _users.values().iterator(); iterator.hasNext();) {
            User user = (User) iterator.next();
            result.add(user);
        }
        return result;
    }




    //#####################################################################################
    //                                  Private Classes
    //#####################################################################################

    private class Connection{
        String _sessionHandle;
        Date _timeOut;
        String _userid;
        public Connection(String userid) {
            _sessionHandle = "" + Math.abs(_random.nextLong());
            Date anHourFromNow = new Date((60 * 60 * 1000) + new Date().getTime());
            _timeOut = anHourFromNow;
            _userid = userid;
        }
    }
}
