package au.edu.qut.yawl.elements.state;

import au.edu.qut.yawl.elements.YConditionInterface;
import au.edu.qut.yawl.elements.YTask;
import au.edu.qut.yawl.exceptions.YStateException;
import au.edu.qut.yawl.logging.YawlLogServletInterface;

import java.util.*;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * This class has control over data structures that allow for
 * storing an identifer and manging a set of children.
 * @author Lachlan Aldred
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YIdentifier {

    private List _locations = new Vector();
    private String _idString;
    private List _children = new Vector();
    private YIdentifier _father;


    public YIdentifier() {
	_idString = YawlLogServletInterface.getInstance().getNextCaseId();
		//_idString = "" + _count++;
    }


    /**
     * Constructor Identifier.
     * @param idString
     */
    private YIdentifier(String idString) {
        _idString = idString;
    }


    public List getChildren() {
        return _children;
    }


    public void clearChildren() {
        _children.clear();
    }


    public Set getDescendants() {
        Set descendants = new HashSet();
        descendants.add(this);

        if (_children.size() > 0) {
            Iterator childIter = _children.iterator();
            while (childIter.hasNext()) {
                descendants.addAll(((YIdentifier) childIter.next())
                        .getDescendants());
            }
        }
        return descendants;
    }


    public YIdentifier createChild() {
        YIdentifier identifier =
                new YIdentifier(this._idString + "." + (_children.size() + 1));
        _children.add(identifier);
        identifier._father = this;
        return identifier;
    }

    /**
     * Creates a child identifier.
     * @param childNum
     * @return the child YIdentifier object with id == childNum
     */
    public YIdentifier createChild(int childNum) {
        if(childNum < 1){
            throw new IllegalArgumentException("Childnum must > 0");
        }
        String childNumStr = "" + childNum;
        for (int i = 0; i < _children.size(); i++) {
            YIdentifier identifier = (YIdentifier) _children.get(i);
            String exisitingChildNumString = identifier.toString();
            String lastPartOfExisistingChildNumString =
                    exisitingChildNumString.substring(
                            exisitingChildNumString.lastIndexOf('.') + 1
                    );
            if(childNumStr.equals(lastPartOfExisistingChildNumString)){
                throw new IllegalArgumentException("" +
                        "Childnum uses an int already being used.");
            }
        }
        YIdentifier identifier =
                new YIdentifier(this._idString + "." + childNumStr);
        _children.add(identifier);
        identifier._father = this;
        return identifier;
    }


    public YIdentifier getFather() {
        return _father;
    }


    public boolean isImmediateChildOf(YIdentifier identifier) {
        return this._father == identifier;
    }


    public String toString() {
        return this._idString;
    }


    public synchronized void addLocation(YConditionInterface condition) {
        if(condition == null){
            throw new RuntimeException("Cannot add null condition to this identifier.");
        }
        this._locations.add(condition);
    }


    public synchronized void removeLocation(YConditionInterface condition) {
        if(condition == null){
            throw new RuntimeException("Cannot remove null condition from this identifier.");
        }
        this._locations.remove(condition);
    }


    public synchronized void addLocation(YTask task) {
        if(task == null){
            throw new RuntimeException("Cannot add null task to this identifier.");
        }
        this._locations.add(task);
    }


    public synchronized void removeLocation(YTask task) {
        if(task == null){
            throw new RuntimeException("Cannot remove null task from this identifier.");
        }
        this._locations.remove(task);
    }


    public synchronized List getLocations(){
        return _locations;
    }
}
