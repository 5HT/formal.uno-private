package au.edu.qut.yawl.elements;

import au.edu.qut.yawl.elements.state.YIdentifier;
import au.edu.qut.yawl.engine.YEngine;
import au.edu.qut.yawl.engine.YWorkItem;
import au.edu.qut.yawl.util.YVerificationMessage;

import java.util.List;
import java.util.Vector;


/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * A YAtomicTask object is the executable equivalent of the YAtomicTask
 * in the YAWL paper.   They have the same properties and behaviour.
 * @author Lachlan Aldred
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public final class YAtomicTask extends YTask {


    public YAtomicTask(String id, int joinType, int splitType, YNet container) {
        super(id, joinType, splitType, container);
    }





    public List verify() {
        List messages = new Vector();
        messages.addAll(super.verify());
        if(_decompositionPrototype == null){
            if(_multiInstAttr != null && (_multiInstAttr.getMaxInstances() > 1 ||
                    _multiInstAttr.getThreshold() > 1)){
                messages.add(new YVerificationMessage(this, this + " cannot have multiInstances and a "
                + " blank work description.", YVerificationMessage._errorStatus));
            }
        }
        else if(! (_decompositionPrototype instanceof YAWLServiceGateway)){
            messages.add(new YVerificationMessage(this, this + " composite task may not decompose to " +
                    "other than a WebServiceGateway.", YVerificationMessage._errorStatus));
        }
        return messages;
    }


    protected void startOne(YIdentifier id) {
        this._mi_entered.removeOne(id);
        this._mi_executing.add(id);
    }


    public boolean isRunning() {
        return _i != null;
    }


    public synchronized void cancel() {
        super.cancel();
        if (_i != null && _decompositionPrototype != null) {
            YWorkItem workItem = _workItemRepository.getWorkItem(_i.toString(), getID());
            _i = null;
            _workItemRepository.removeWorkItemFamily(workItem);
            //if applicable cancel yawl service
            YAWLServiceGateway wsgw = (YAWLServiceGateway) getDecompositionPrototype();
            if (wsgw != null) {
                YAWLServiceReference ys = wsgw.getYawlService();
                if (ys != null && !ys.isWorklistService()) {

                    YEngine.getInstance(false).announceCancellationToEnvironment(ys, workItem);
                }
            }
        }
    }

    public boolean t_rollBackToFired(YIdentifier caseID) {
        if(_mi_executing.contains(caseID)){
            _mi_executing.removeOne(caseID);
            _mi_entered.add(caseID);
            return true;
        }
        return false;
    }


    public YNet getNet() {
        return _net;
    }


    public Object clone() throws CloneNotSupportedException {
        YNet copyContainer = _net.getCloneContainer();
        if(copyContainer.getNetElements().containsKey(this.getID())){
            return copyContainer.getNetElement(this.getID());
        }
        YAtomicTask copy = (YAtomicTask) super.clone();
        return copy;
    }
}
