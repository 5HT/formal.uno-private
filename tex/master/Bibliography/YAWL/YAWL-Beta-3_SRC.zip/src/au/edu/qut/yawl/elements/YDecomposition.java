package au.edu.qut.yawl.elements;

import au.edu.qut.yawl.elements.data.YParameter;
import au.edu.qut.yawl.util.YVerificationMessage;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;

import java.io.StringReader;
import java.util.*;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 25/09/2003
 * Time: 16:04:21
 * This file remains the property of the YAWL team at the Queensland University of
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public abstract class YDecomposition implements Cloneable, YVerifiable {
    protected String _id;
    private YSpecification _specification;
    private String _name;
    private String _documentation;
    private Map _inputParameters;
    private Map _outputParameters;
    private Set _outputExpressions;
    protected Document _data;



    public String getID() {
        return this._id;
    }


    public YDecomposition(String id, YSpecification specification) {
        this._id = id;
        _specification = specification;
        _inputParameters = new HashMap();
        _outputParameters = new HashMap();
        _outputExpressions = new HashSet();
        _data = new Document();
        _data.setRootElement(new Element("data"));
    }


    public void setDocumentation(String documentation) {
        _documentation = documentation;
    }


    public String getDocumentation() {
        return _documentation;
    }


    public void setName(String name) {
//        Element oldDataRootElement = _data.getRootElement();
//        Element newDataRootElement = new Element(name);
//        List children = oldDataRootElement.removeContent();
//        if(children != null){
//            newDataRootElement.addContent(children);
//        }
//        _data.setRootElement(newDataRootElement);
        _name = name;
    }


    public String getName() {
        return _name;
    }


    public void setInputParam(YParameter parameter) {
        if(null != parameter.getName()){
            _inputParameters.put(parameter.getName(), parameter);
        } else if(null != parameter.getElementName()) {
            _inputParameters.put(parameter.getElementName(), parameter);
        }
    }


    public Map getInputParameters() {
        return _inputParameters;
    }


    public Map getOutputParameters() {
        return _outputParameters;
    }


    /**
     * Adds an output parameter to this.
     * @param parameter the parameter to be added
     */
    public void setOutputParameter(YParameter parameter) {
        if(null != parameter.getName()){
            _outputParameters.put(parameter.getName(), parameter);
        } else if(null != parameter.getElementName()) {
            _outputParameters.put(parameter.getElementName(), parameter);
        }
    }


    /**
     * @deprecated
     * @param query
     */
    public void setOutputExpression(String query) {
        _outputExpressions.add(query);
    }


    /**
     * @deprecated
     * @return
     */
    public Set getOutputQueries() {
        return _outputExpressions;
    }


    public String toXML() {
        StringBuffer xml = new StringBuffer();
        //just do the decomposition facts (not the surrounding element) - to keep life simple
        if (_name != null) {
            xml.append("<name>" + _name + "</name>");
        }
        if (_documentation != null) {
            xml.append("<documentation>" + _documentation + "</documentation>");
        }
        List parameters = new ArrayList(_inputParameters.values());
        Collections.sort(parameters);
        for (Iterator iterator = parameters.iterator(); iterator.hasNext();) {
            YParameter parameter = (YParameter) iterator.next();
            xml.append(parameter.toXML());
        }
        for (Iterator iterator = _outputParameters.values().iterator(); iterator.hasNext();) {
            YParameter parameter = (YParameter) iterator.next();
            xml.append(parameter.toXML());
        }
        for (Iterator iter = _outputExpressions.iterator(); iter.hasNext();) {
            String expression = (String) iter.next();
            xml.append("<outputExpression query=\"" + YTask.marshal(expression) + "\"/>");
        }
        return xml.toString();
    }


    public List verify() {
        List messages = new Vector();
        if (_id == null) {
            messages.add(new YVerificationMessage(this, this + " cannot have null id.", YVerificationMessage._errorStatus));
        }
        for (Iterator iterator = _inputParameters.values().iterator(); iterator.hasNext();) {
            YParameter parameter = (YParameter) iterator.next();
            messages.addAll(parameter.verify());
        }
        return messages;
    }


    public String toString() {
        String fullClassName = getClass().getName();
        String shortClassName = fullClassName.substring(fullClassName.lastIndexOf('.') + 2);
        return shortClassName + ":" + getID();
    }


    public Object clone() throws CloneNotSupportedException {
        YDecomposition copy = (YDecomposition) super.clone();
        copy._inputParameters = new HashMap();
        Collection params = _inputParameters.values();
        for (Iterator iterator = params.iterator(); iterator.hasNext();) {
            YParameter parameter = (YParameter) iterator.next();
            YParameter copyParam = (YParameter) parameter.clone();
            copy.setInputParam(copyParam);
        }
        return copy;
    }


    /**
     * @deprecated
     * @return
     */
    public Document getInternalDataDocument() {
        return _data;
    }

    /**
     * This method returns the list of data from a decomposition. According to
     * its declared output parameters.  In other word the data inside this
     * decomposition is groomed so to speak so that the output data is returned
     * in sequence.  Furthermore no internal variables, or input only
     * parameters are returned.
     * @return a JDom Document of the output data.
     */
    public Document getOutputData(){
        //create a new output document to return
        Document outputDoc = new Document();
        String rootDataElementName = _data.getRootElement().getName();
        Element rootElement = new Element(rootDataElementName);
        outputDoc.setRootElement(rootElement);

        //now prepare a list of output params to iterate over.
        Collection outputParams = getOutputParameters().values();
        List outputParamsList = new ArrayList(outputParams);
        Collections.sort(outputParamsList);

        for (Iterator iterator = outputParamsList.iterator(); iterator.hasNext();) {
            YParameter parameter = (YParameter) iterator.next();
            String varElementName =
                    parameter.getName() != null ?
                    parameter.getName() : parameter.getElementName();
            Element root = _data.getRootElement();
            Element child = root.getChild(varElementName);
            Element clone = (Element) child.clone();
            outputDoc.addContent(clone);
        }
        return outputDoc;
    }


    public Element getVariableDataByName(String name) {
        return _data.getRootElement().getChild(name);
    }


    public void assignData(Element variable) {
        _data.getRootElement().removeChild(variable.getName());
        _data.getRootElement().addContent(variable);
    }


    public void initialise() {
        Iterator iter = _inputParameters.values().iterator();
        while (iter.hasNext()) {
            YParameter inputParam = (YParameter) iter.next();
            Element initialValuedXMLDOM = null;
            if (inputParam.getInitialValue() != null) {
                String initialValue = inputParam.getInitialValue();
                initialValue = "<" + inputParam.getName() + ">" + initialValue + "</" + inputParam.getName() + ">";
                try {
                    SAXBuilder builder = new org.jdom.input.SAXBuilder();
                    Document doc = builder.build(new StringReader(initialValue));
                    initialValuedXMLDOM = doc.detachRootElement();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                initialValuedXMLDOM = new Element(inputParam.getName());
            }
            addData(initialValuedXMLDOM);
        }
    }


    protected void addData(Element element) {
        _data.getRootElement().removeChild(element.getName());
        _data.getRootElement().addContent(element);
    }


    public Set getInputParameterNames() {
        return _inputParameters.keySet();
    }


    /**
     * Returns a link to the containing specification.
     * @return
     */
    public YSpecification getSpecification() {
        return _specification;
    }
}
