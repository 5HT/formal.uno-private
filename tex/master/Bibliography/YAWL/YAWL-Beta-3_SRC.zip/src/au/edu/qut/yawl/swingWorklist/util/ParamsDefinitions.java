package au.edu.qut.yawl.swingWorklist.util;

import au.edu.qut.yawl.worklist.model.YParametersSchema;

import java.util.HashMap;
import java.util.Map;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 5/11/2003
 * Time: 11:46:06
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class ParamsDefinitions {
    Map _nameNDecompositionIDMapsToParameterTuple = new HashMap();


    public YParametersSchema getParamsForTask(String taskID){
        return (YParametersSchema) _nameNDecompositionIDMapsToParameterTuple.get(taskID);
    }


    public void setParamsForTask(String taskID, YParametersSchema parameterTuple){
        _nameNDecompositionIDMapsToParameterTuple.put(taskID, parameterTuple);
    }
}
