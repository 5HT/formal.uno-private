package au.edu.qut.yawl.util;


import java.lang.*;

/**
 * Extracted from source obtained from http://www.koders.com/
 */

public interface Order {

    public boolean lessThan(Object a, Object b);

}

