package au.edu.qut.yawl.engine;


/**
 * A problem event describes the nature of a runtime execution problem.
 *
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 15/10/2004
 * Time: 11:50:00
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YProblemEvent {
    private Object _source;
    private String _message;
    private int _eventType;

    public static int RuntimeError = 1;
    public static int RuntimeWarning = 2;

    public YProblemEvent(Object source, String message, int eventType) {
        this._source = source;
        this._message = message;
        this._eventType = eventType;

        if(source == null ||
                (eventType != RuntimeError && eventType != RuntimeWarning )){
            throw new IllegalArgumentException("Check your arguments: " +
                    "source cannot equal null and evenType must be a registered type.");
        }
    }

    /**
     * Gets the message of the event, if any.
     * @return message
     */
    public String getMessage() {
        return _message;
    }


    /**
     * Gets the source of the event.
     * @return event source object.
     */
    public Object getSource() {
        return _source;
    }

    /**
     * Gets the event type.
     * @return event ype.
     */
    public int getEventType() {
        return _eventType;
    }
}
