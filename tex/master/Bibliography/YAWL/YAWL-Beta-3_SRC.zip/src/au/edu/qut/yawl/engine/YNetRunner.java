package au.edu.qut.yawl.engine;

import au.edu.qut.yawl.elements.*;
import au.edu.qut.yawl.elements.state.YIdentifier;
import au.edu.qut.yawl.exceptions.YDataStateException;
import au.edu.qut.yawl.exceptions.YStateException;
import au.edu.qut.yawl.exceptions.YAWLException;
import org.jdom.Document;
import org.jdom.Element;

import java.util.*;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 16/04/2003
 * Time: 16:08:01
 * This file remains the property of the YAWL team at the Queensland University of
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YNetRunner extends Thread {
    protected YNet _net;
    private Set _enabledTasks = new HashSet();
    private Set _busyTasks = new HashSet();;

    private static YWorkItemRepository _workItemRepository = YWorkItemRepository.getInstance();
    private YIdentifier _caseIDForNet;
    private YCompositeTask _containingCompositeTask;
    private YEngine _engine;
    private boolean _cancelling;


    /**
     * Allocates a new <code>Thread</code> object. This constructor has
     * the same effect as <code>Thread(null, null,</code>
     * <i>gname</i><code>)</code>, where <b><i>gname</i></b> is
     * a newly generated name. Automatically generated names are of the
     * form <code>"Thread-"+</code><i>n</i>, where <i>n</i> is an integer.
     *
     * @see     Thread#Thread(ThreadGroup,
            *          Runnable, String)
     */
    public YNetRunner(YNet netPrototype, YEngine engine) {
        super("NetRunner:" + netPrototype.getID());
        _caseIDForNet = new YIdentifier();
        _net = (YNet) netPrototype.clone();
        _engine = engine;
        prepare();
    }


    public YNetRunner(YNet netPrototype, YEngine engine, Element paramsData)  {
        super("NetRunner:" + netPrototype.getID());
        _caseIDForNet = new YIdentifier();
        _net = (YNet) netPrototype.clone();
        _engine = engine;
        prepare();
        _net.setIncomingData(paramsData);
    }


    public YNetRunner(YNet netPrototype, YCompositeTask container, YIdentifier caseIDForNet, Element incomingData)  {
        super("NetRunner:" + netPrototype.getID());
        _caseIDForNet = caseIDForNet;
        _net = (YNet) netPrototype.clone();
        _containingCompositeTask = container;
        prepare();
        _net.setIncomingData(incomingData);
    }


    private void prepare()  {
        _workItemRepository.setNetRunnerToCaseIDBinding(this, _caseIDForNet);
        YInputCondition inputCondition = _net.getInputCondition();
        inputCondition.add(_caseIDForNet);
        _net.initialise();
        continueIfPossible();
    }


    public void run() {
        while (continueIfPossible()) {
            try {
                synchronized (this) {
                    wait();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        _workItemRepository.cancelSubnet(_caseIDForNet);
        if (!_cancelling && deadLocked()) {
            notifyDeadLock();
        }
        cancel();
        if (_engine != null) {
            _engine.finishCase(_caseIDForNet);
        }
    }


    private void notifyDeadLock() {
        List locations = _caseIDForNet.getLocations();
        for (int i = 0; i < locations.size(); i++) {
            YNetElement element = (YNetElement) locations.get(i);
            if (_net.getNetElements().values().contains(element)) {
                if (element instanceof YTask) {
                    createDeadlockItem((YTask) element);
                }
                Set postset = ((YExternalNetElement) element).getPostsetElements();
                if (postset.size() > 0) {
                    for (Iterator iterator = postset.iterator(); iterator.hasNext();) {
                        YExternalNetElement postsetElement = (YExternalNetElement) iterator.next();
                        createDeadlockItem(postsetElement);
                    }
                }
            }
        }
    }


    private void createDeadlockItem(YExternalNetElement netElement) {
        String specificationID = _net.getSpecification().getID();
        boolean allowsNewInstances = false;
        boolean isDeadlocked = true;
        YWorkItemID deadlockWorkItemID = new YWorkItemID(
                _caseIDForNet,
                netElement.getID());
        new YWorkItem(
                specificationID,
                deadlockWorkItemID,
                allowsNewInstances,
                isDeadlocked);
    }


    private boolean deadLocked() {
        List locations = _caseIDForNet.getLocations();
        for (int i = 0; i < locations.size(); i++) {
            Object o = locations.get(i);
            try {
                YExternalNetElement element = (YExternalNetElement) o;
                if (element.getPostsetElements().size() > 0) {
                    return true;
                }
            } catch (ClassCastException e) {
            }
        }
        return false;
    }


    private synchronized void processCompletedSubnet(YIdentifier caseIDForSubnet, YCompositeTask busyCompositeTask, Document rawSubnetData) throws YDataStateException {
        if (caseIDForSubnet == null) {
            throw new RuntimeException();
        }
        boolean compositeTaskExited = busyCompositeTask.t_complete(caseIDForSubnet, rawSubnetData);
        if (compositeTaskExited) {
            _busyTasks.remove(busyCompositeTask);
            notify();
//            String caseIDStr = caseIDForSubnet.toString();
//            String taskIDStr = busyCompositeTask.getID();
//            YWorkItem item = _workItemRepository.getWorkItem(
//                    caseIDStr,
//                    taskIDStr);
//System.out.println("\tcaseIDStr = " + caseIDStr);
//System.out.println("\ttaskIDStr = " + taskIDStr);
//Set items = _workItemRepository.getWorkItems();
//for (Iterator iterator = items.iterator(); iterator.hasNext();) {
//YWorkItem item2 = (YWorkItem) iterator.next();
//System.out.println("item2 = " + item2);
//}
//            _workItemRepository.removeWorkItemFamily(item);
//            YWorkItem item = YLocalWorklist.getWorkItem(caseIDForSubnet.toString(), busyCompositeTask.getURI());
//            YLocalWorklist.removeWorkItemFamily(item);
        }

    }


    public synchronized List attemptToFireAtomicTask(String taskID) throws YDataStateException, YStateException {
        YAtomicTask task = (YAtomicTask) _net.getNetElement(taskID);
        if (task.t_enabled(_caseIDForNet)) {
            List newChildIdentifiers = task.t_fire();
            _enabledTasks.remove(task);
            _busyTasks.add(task);
            synchronized (this) {
                notify();
            }
            return newChildIdentifiers;
        }
        return null;
    }


    public synchronized YIdentifier addNewInstance(String taskID, YIdentifier aSiblingInstance, Element newInstanceData) throws YDataStateException {
        YAtomicTask task = (YAtomicTask) _net.getNetElement(taskID);
        if (task.t_isBusy()) {
            return task.t_add(aSiblingInstance, newInstanceData);
        }
        return null;
    }


    public synchronized void startWorkItemInTask(YIdentifier caseID, String taskID) {
        YAtomicTask task = (YAtomicTask) _net.getNetElement(taskID);
        task.t_start(caseID);
    }


    public synchronized boolean completeWorkItemInTask(YIdentifier caseID, String taskID, Document outputData) throws YDataStateException {
        YAtomicTask task = (YAtomicTask) _net.getNetElement(taskID);
        return completeTask(task, caseID, outputData);
    }


    protected synchronized boolean continueIfPossible() {
        List tasks = new ArrayList(_net.getNetElements().values());
        Iterator tasksIter = tasks.iterator();
        while (tasksIter.hasNext()) {
            YExternalNetElement netElement = (YExternalNetElement) tasksIter.next();
            if (netElement instanceof YTask) {
                YTask task = (YTask) netElement;
                if (task.t_enabled(_caseIDForNet)) {

                    boolean taskRecordedAsEnabled = _enabledTasks.contains(task);
                    boolean taskRecordedAsBusy = _busyTasks.contains(task);
                    if (!taskRecordedAsEnabled && !taskRecordedAsBusy) {
                        if (task instanceof YAtomicTask) {
                            YAtomicTask atomicTask = (YAtomicTask) task;
                            YAWLServiceGateway wsgw = (YAWLServiceGateway) atomicTask.getDecompositionPrototype();
                            //if its not an empty task
                            if (wsgw != null) {
                                createEnabledWorkItem(_caseIDForNet, atomicTask);
                                YAWLServiceReference ys = wsgw.getYawlService();
                                if (ys != null && !ys.isWorklistService()) {
                                    YWorkItem item = _workItemRepository.getWorkItem(
                                            _caseIDForNet.toString(), atomicTask.getID());
                                    _engine.announceEnabledTask(ys, item);
                                }
                                _enabledTasks.add(task);
                            } else {
                                //fire the empty atomic task
                                YIdentifier id = null;
                                try {
                                    id = (YIdentifier) atomicTask.t_fire().iterator().next();
                                    atomicTask.t_start(id);
                                    completeTask(atomicTask, id, null);//atomicTask.t_complete(id);
                                } catch (YAWLException e) {
                                    YProblemEvent pe =
                                            new YProblemEvent(
                                                    atomicTask,
                                                    e.getMessage(),
                                                    YProblemEvent.RuntimeError);
                                    logProblem(pe);
                                }
                            }
                        } else {
                            //fire the composite task
                            _busyTasks.add(task);
                            Iterator caseIDs = null;
                            try {
                                caseIDs = task.t_fire().iterator();
                            } catch (YAWLException e) {
                                    YProblemEvent pe =
                                            new YProblemEvent(
                                                    task,
                                                    e.getMessage(),
                                                    YProblemEvent.RuntimeError);
                                    logProblem(pe);
                            }
                            while (caseIDs.hasNext()) {
                                YIdentifier id = (YIdentifier) caseIDs.next();
                                task.t_start(id);
                            }
                        }
                    }
                } else /*if (!task.t_enabled(_caseIDForNet))*/ {
                    if (_enabledTasks.contains(task)) {
//                        YLocalWorklist.announceToWorklistsNoLongerEnabled(_caseIDForNet, task.getID());
                        _enabledTasks.remove(task);
                    }
                }
                if (task.t_isBusy() && !_busyTasks.contains(task)) {
                    throw new RuntimeException("busy task list out of synch with a busy task: " + task.getID() + " busy tasks: " + _busyTasks);
                }
            }
        }
        Set busyTasks;
        _busyTasks = _net.getBusyTasks();
        //todo if I uncomment out the below a have an unlikely failing unit test - find out why.
        Set enabledTasks;
        return _enabledTasks.size() > 0 || _busyTasks.size() > 0;
    }


    /**
     * Creates an enabled work item.
     * @param caseIDForNet the caseid for the net
     * @param atomicTask the atomic task that contains it.
     */
    private void createEnabledWorkItem(YIdentifier caseIDForNet, YAtomicTask atomicTask) {
        boolean allowDynamicCreation =
                atomicTask.getMultiInstanceAttributes() == null ? false :
                YMultiInstanceAttributes._creationModeDynamic.equals(
                        atomicTask.getMultiInstanceAttributes().getCreationMode());
        //creating a new work item puts it into the work item
        //repository automatically.
        new YWorkItem(
                atomicTask.getNet().getSpecification().getID(),
                new YWorkItemID(caseIDForNet, atomicTask.getID()),
                allowDynamicCreation, false);
    }


    /**
     * Would be a good programming "handle" for
     * compensating/handling problems that occured during firing or executing a task.
     * @param e
     */
    private void logProblem(YProblemEvent e) {
        _engine.logProblem(e);
    }



    private boolean completeTask(YAtomicTask atomicTask, YIdentifier identifier, Document outputData) throws YDataStateException {
        boolean taskExited;
        taskExited = atomicTask.t_complete(identifier, outputData);
        if (taskExited) {
            //here are check to see if completing this task resulted in completing the net.
            if (this.isCompleted() && _net.getOutputCondition().getIdentifiers().size() == 1) {
                //so now we know the net is complete we check if this net is a subnet.
                if (_containingCompositeTask != null) {
                    YNetRunner parentRunner = _workItemRepository.getNetRunner(
                            _caseIDForNet.getFather());
                    if (parentRunner != null) {
                        synchronized (parentRunner) {
                            if (_containingCompositeTask.t_isBusy()) {
                                parentRunner.processCompletedSubnet(
                                        _caseIDForNet,
                                        _containingCompositeTask,
                                        _net.getInternalDataDocument());
                                if (_caseIDForNet == null) {
                                    System.out.println(
                                            "YNetRunner::completeTask() finished local task: " +
                                            atomicTask + " composite task: " +
                                            _containingCompositeTask +
                                            " caseid for decomposed net: " +
                                            _caseIDForNet);
                                }
                            }
                        }
                    }
                } else if (_engine != null && _containingCompositeTask != null) {
                    _engine.finishCase(_caseIDForNet);
                }
            }
            continueIfPossible();
            _busyTasks.remove(atomicTask);
            notify();
        }
        return taskExited;
    }


    public synchronized void cancel() {
        _cancelling = true;
        _workItemRepository.cancelSubnet(_caseIDForNet);

        Collection netElements = _net.getNetElements().values();
        Iterator iterator = netElements.iterator();
        while (iterator.hasNext()) {
            YExternalNetElement netElement = (YExternalNetElement) iterator.next();
            if (netElement instanceof YTask) {
                YTask task = ((YTask) netElement);
                if (task.t_isBusy()) {
                    task.cancel();
                }
            } else if (((YCondition) netElement).containsIdentifier()) {
                ((YCondition) netElement).removeAll();
            }
        }
        _enabledTasks = new HashSet();
        _busyTasks = new HashSet();
        notify();
    }


    public synchronized boolean suspendWorkItem(YIdentifier caseID, String taskID) {
        YAtomicTask task = (YAtomicTask) _net.getNetElement(taskID);
        return task.t_rollBackToFired(caseID);
    }


    //###############################################################################
    //                              accessors
    //###############################################################################
    public YExternalNetElement getNetElement(String id) {
        return _net.getNetElement(id);
    }


    public YIdentifier getCaseID() {
        return _caseIDForNet;
    }


    public boolean isCompleted() {
        if (_net.getOutputCondition().containsIdentifier()) {
            return true;
        } else {
            return isEmpty();
        }
    }


    public boolean isEmpty() {
        Iterator elements = _net.getNetElements().values().iterator();
        while (elements.hasNext()) {
            YExternalNetElement element = (YExternalNetElement) elements.next();
            if (element instanceof YCondition) {
                if (((YCondition) element).containsIdentifier()) {
                    return false;
                }
            } else {
                if (((YTask) element).t_isBusy()) {
                    return false;
                }
            }
        }
        return true;
    }


    protected Set getBusyTasks() {
        return _busyTasks;
    }


    protected Set getEnabledTasks() {
        return _enabledTasks;
    }


    public boolean isAddEnabled(String taskID, YIdentifier childID) {
        YAtomicTask task = (YAtomicTask) _net.getNetElement(taskID);
        return task.t_addEnabled(childID);
    }
}

/*
    private List updateEnabledTasks(YTask task) {
        List newEnabledTasks = new Vector();
        Iterator presetConditions = task.getPresetElements().iterator();
        while (presetConditions.hasNext()) {
            YCondition condition = (YCondition) presetConditions.next();
            Iterator possiblyEnabledTasks = condition.getPostsetElements().iterator();
            while (possiblyEnabledTasks.hasNext()) {
                YTask possiblyEnabledTask = (YTask) possiblyEnabledTasks.next();
                if (possiblyEnabledTask.t_enabled()) {
                    newEnabledTasks.add(possiblyEnabledTask);
                }
            }
        }
        Iterator postsetConditions = task.getPostsetElements().iterator();
        while (postsetConditions.hasNext()) {
            YCondition condition = (YCondition) postsetConditions.next();
            Iterator possiblyEnabledTasks = condition.getPostsetElements().iterator();
            while (possiblyEnabledTasks.hasNext()) {
                YTask possiblyEnabledTask = (YTask) possiblyEnabledTasks.next();
                if (possiblyEnabledTask.t_enabled()) {
                    newEnabledTasks.add(possiblyEnabledTask);
                }
            }
        }
        Iterator tasks = _enabledTasks.iterator();
        while (tasks.hasNext()) {
            YTask nextTask = (YTask) tasks.next();
            if (nextTask.t_enabled()) {
                newEnabledTasks.add(nextTask);
            }
        }
        return newEnabledTasks;
    }
*/
