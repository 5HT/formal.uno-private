package au.edu.qut.yawl.util;

import java.util.Iterator;
import java.util.List;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 30/04/2003
 * Time: 10:28:42
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YMessagePrinter {
    public static void printMessages(List messages){
        Iterator iter = messages.iterator();
        while(iter.hasNext()){
            Object o = null;
            try{
                o = iter.next();
                YVerificationMessage vm = (YVerificationMessage) o;
                System.out.println(vm.getStatus() + ":" + vm.getMessage());
            }catch(ClassCastException cce){
                System.out.println("About to throw exception over this object = " + o.getClass().getName());
                cce.printStackTrace();
            }
        }
    }


    public static String getMessageString(List messages){
        StringBuffer stringBuffer = new StringBuffer();
        Iterator iter = messages.iterator();
        while(iter.hasNext()){
            YVerificationMessage message = (YVerificationMessage)iter.next();
            stringBuffer.append("\n" + message.getStatus() + ":" + message.getMessage());
        }
        return stringBuffer.toString();
    }
}
