package au.edu.qut.yawl.elements;

import au.edu.qut.yawl.util.YVerificationMessage;

import java.util.List;
import java.util.Vector;


/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 22/04/2003
 * Time: 13:45:29
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public final class YOutputCondition extends YCondition{


    public YOutputCondition(String id, String label, YNet container){
        super(id, label, container);

    }


    public YOutputCondition(String id, YNet container){
        super(id, container);
    }


    public List verify(){
        List messages = new Vector();
/*        if(_postset.size() > 0 || _preset.size() > 0){
            if(this._postset.size() != 0){
                messages.add(new YVerificationMessage(this, this
                        + " postset must be empty: " + _postset.values()));
            }
            messages.addAll(verifyPreset());
        }
        else*/{
            if(getPostsetElements().size() != 0){
                messages.add(new YVerificationMessage(this, this
                        + " postset must be empty: "+ getPostsetElements(), YVerificationMessage._errorStatus));
            }
            messages.addAll(verifyPresetFlows());
        }
        return messages;
    }


/*    public synchronized void add(YIdentifier identifier){
        _bag.addIdentifier(identifier);
/*        YNetRunner netRunner = YWorkItemRepository.getInstance().getNetRunner(identifier);
        if(netRunner != null){
            netRunner.completeWorkItemInTask()
        }* /
    }*/


    public Object clone() throws CloneNotSupportedException {
        YNet copyContainer = _net.getCloneContainer();
        if(copyContainer.getNetElements().containsKey(this.getID())){
            return copyContainer.getNetElement(this.getID());
        }
        YOutputCondition copy = (YOutputCondition) super.clone();
        copy._net.setOutputCondition((YOutputCondition)copy);
        return copy;
    }
}
