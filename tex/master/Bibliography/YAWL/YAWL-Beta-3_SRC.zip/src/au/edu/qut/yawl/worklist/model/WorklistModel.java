package au.edu.qut.yawl.worklist.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 27/01/2004
 * Time: 18:56:15
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class WorklistModel {
    private Map _workItems = new HashMap();
    private Map _taskInformations = new HashMap();
    private Map _itemIDToDataMap = new HashMap();
    private Map _specificationData = new HashMap();


    public void updateWorkItems(List items) {
        for (int i = 0; i < items.size(); i++) {
            WorkItemRecord workItemRecord = (WorkItemRecord) items.get(i);
            String caseID = workItemRecord.getCaseID();
            String taskID = workItemRecord.getTaskID();
            _workItems.put(workItemRecord.getID(), workItemRecord);
        }
    }


    public WorkItemRecord getWorkItem(String workItemID) {
        return (WorkItemRecord) _workItems.get(workItemID);
    }


    public TaskInformation getTaskInformation(String specificationID, String taskID) {
        return (TaskInformation) _taskInformations.get(specificationID + taskID);
    }


    public void setTaskInformation(String specificationID, String taskID, TaskInformation taskInfo) {
        _taskInformations.put(specificationID + taskID, taskInfo);
    }


    public void setDataForWorkItemID(String workItemID, String data){
        _itemIDToDataMap.put(workItemID, data);
    }


    public String getDataForWorkItemID(String workItemID) {
        return (String)_itemIDToDataMap.get(workItemID);
    }

    public void unsaveWorkItem(String workItemID) {
        _itemIDToDataMap.remove(workItemID);
    }


    public void setSpecificationData(SpecificationData specData){
        if(! _specificationData.containsKey(specData.getID())){
            _specificationData.put(specData.getID(), specData);
        }
    }


    /**
     * Gets a data object describing the specification.  This is cached in
     * the worklist application to reduce unecessary communication
     * between messaging teirs, and to improve performance.
     * @param specID
     * @return
     */
    public SpecificationData getSpecificationData(String specID){
        return (SpecificationData) _specificationData.get(specID);
    }


    public void addWorkItem(WorkItemRecord itemRecord) {
        _workItems.put(itemRecord.getID(), itemRecord);
    }
}
