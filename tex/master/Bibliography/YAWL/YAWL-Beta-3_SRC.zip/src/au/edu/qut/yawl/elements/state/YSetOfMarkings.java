package au.edu.qut.yawl.elements.state;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 19/06/2003
 * Time: 15:22:56
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class YSetOfMarkings {
    private Set _markings = new HashSet();


    public void addMarking(YMarking marking){
        _markings.add(marking);
    }


    public boolean contains(YMarking marking){
        return _markings.contains(marking);
    }


    public Set getMarkings(){
        return _markings;
    }

    public int size() {
        return _markings.size();
    }

    public YMarking removeAMarking() {
        if(_markings.size() > 0){
            YMarking marking = (YMarking) _markings.iterator().next();
            _markings.remove(marking);
            return marking;
        }
        return null;
    }

    public boolean containsEquivalentMarkingTo(YSetOfMarkings possibleFutureMarkingSet) {
        Set possibleMarkings = possibleFutureMarkingSet.getMarkings();
        for (Iterator iterator = possibleMarkings.iterator(); iterator.hasNext();) {
            YMarking marking = (YMarking) iterator.next();
            for(Iterator thisSetOfMarkings = _markings.iterator(); thisSetOfMarkings.hasNext();) {
                YMarking thisSetsMarking = (YMarking) thisSetOfMarkings.next();
                if(marking.equivalentTo(thisSetsMarking)){
                    return true;
                }
            }
        }
        return false;
    }
}
