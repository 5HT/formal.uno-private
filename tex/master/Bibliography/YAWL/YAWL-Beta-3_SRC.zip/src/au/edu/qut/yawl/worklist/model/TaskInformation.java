package au.edu.qut.yawl.worklist.model;



/**
 * Copyright � 2003 Queensland University of Technology. All rights reserved.
 * @author Lachlan Aldred
 * Date: 26/02/2004
 * Time: 14:54:10
 * This file remains the property of the YAWL team at the Queensland University of 
 * Technology (Wil van der Aalst, Arthur ter Hofstede, Lachlan Aldred, Lindsay Bradford,
 * and Marlon Dumas).
 * You do not have permission to use, view, execute or modify the source outside the terms
 * of the YAWL SOFTWARE LICENCE.
 * For more information about the YAWL SOFTWARE LICENCE refer to the 'downloads' section under
 * http://www.citi.qut.edu.au/yawl.
 */
public class TaskInformation {
    private YParametersSchema _paramSchema;
    private String _taskID;
    private String _specificationID;
    private String _taskDocumentation;
    private String _taskName;
    private String _wsdlLocation;
    private String _operationName;



    public TaskInformation(YParametersSchema paramSchema, String taskID,
                           String specificationID, String taskName, String taskDocumentation) {
        this._paramSchema = paramSchema;
        this._taskID = taskID;
        this._taskName = taskName;
        this._specificationID = specificationID;
        this._taskDocumentation = taskDocumentation;
    }


    public YParametersSchema getParamSchema() {
        return _paramSchema;
    }


    public String getTaskID() {
        return _taskID;
    }


    public String getSpecificationID() {
        return _specificationID;
    }


    public String getTaskDocumentation() {
        return _taskDocumentation;
    }


    public String getTaskName() {
        return _taskName;
    }


    public String getWSDLLocation() {
        return _wsdlLocation;
    }


    public String getOperationName() {
        return _operationName;
    }


    public void setWsdlLocation(String wsdlLocation) {
        this._wsdlLocation = wsdlLocation;
    }


    public void setOperationName(String operationName) {
        this._operationName = operationName;
    }
}
